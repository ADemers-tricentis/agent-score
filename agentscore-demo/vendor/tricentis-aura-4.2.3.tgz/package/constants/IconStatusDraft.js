import IconMaterialSymbolsDraftOrders from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDraftOrders.mjs";
/** React component for the SVG icon to use to represent status draft. */
const IconStatusDraft = IconMaterialSymbolsDraftOrders;
export default IconStatusDraft;
//# sourceMappingURL=IconStatusDraft.js.map