import IconMaterialSymbolsTaskAlt from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsTaskAlt.mjs";
/** React component for the SVG icon to use to represent status passed. */
const IconStatusPassed = IconMaterialSymbolsTaskAlt;
export default IconStatusPassed;
//# sourceMappingURL=IconStatusPassed.js.map