import IconMaterialSymbolsBlock from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsBlock.mjs";
/**
 * React component for the SVG icon to use to represent status not applicable.
 */
const IconStatusNotApplicable = IconMaterialSymbolsBlock;
export default IconStatusNotApplicable;
//# sourceMappingURL=IconStatusNotApplicable.js.map