/**
 * The Tricentis
 * [Material UI X Pro plan](https://mui.com/x/introduction/licensing/#pro-plan)
 * license key to
 * [install in a project](https://mui.com/x/introduction/licensing/#license-key-installation)
 * to use [Material UI X](https://mui.com/x) commercial features.
 */
const muiXLicenseKey = "bb9077055c02fce9b2fbf0fbe1f4ea4cTz0xMjAxMjAsRT0xNzk1NTY0ODAwMDAwLFM9cHJvLExNPXBlcnBldHVhbCxQVj1RMy0yMDI0LEtWPTI=";
export default muiXLicenseKey;
//# sourceMappingURL=muiXLicenseKey.js.map