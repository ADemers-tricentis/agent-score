import IconMaterialSymbolsCircle from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCircle.mjs";
/** React component for the SVG icon to use to represent status active. */
const IconStatusActive = IconMaterialSymbolsCircle;
export default IconStatusActive;
//# sourceMappingURL=IconStatusActive.js.map