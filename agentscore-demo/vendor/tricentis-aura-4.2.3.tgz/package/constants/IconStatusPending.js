import IconMaterialSymbolsSchedule from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsSchedule.mjs";
/** React component for the SVG icon to use to represent status pending. */
const IconStatusPending = IconMaterialSymbolsSchedule;
export default IconStatusPending;
//# sourceMappingURL=IconStatusPending.js.map