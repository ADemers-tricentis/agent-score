const themeOptionsTreeView = {
    components: {
        MuiTreeItem: {
            styleOverrides: {
                content: ({ theme }) => ({
                    "&:hover": {
                        backgroundColor: theme.vars.palette.action.hover,
                        color: theme.vars.palette.text.primary,
                    },
                    [`&[data-selected]`]: {
                        backgroundColor: theme.vars.palette.action.selected,
                        "&:hover, &.Mui-hovered": {
                            backgroundColor: theme.vars.palette.aura.activeHover,
                        },
                        [`&[data-focused]`]: {
                            backgroundColor: theme.vars.palette.aura.activeHover,
                        },
                    },
                }),
            },
        }
    },
};
export default themeOptionsTreeView;
//# sourceMappingURL=themeOptionsTreeView.js.map