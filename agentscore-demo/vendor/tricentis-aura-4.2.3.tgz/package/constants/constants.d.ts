/**
 * Variant options for product icon mark components.
 *
 * - `brand`: Shows only the product icon/symbol
 * - `product`: Shows the product icon/symbol
 */
export type ProductIconMarkVariant = "brand" | "product";
