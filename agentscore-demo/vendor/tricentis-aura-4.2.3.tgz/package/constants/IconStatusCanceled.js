import IconMaterialSymbolsBlock from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsBlock.mjs";
/** React component for the SVG icon to use to represent status canceled. */
const IconStatusCanceled = IconMaterialSymbolsBlock;
export default IconStatusCanceled;
//# sourceMappingURL=IconStatusCanceled.js.map