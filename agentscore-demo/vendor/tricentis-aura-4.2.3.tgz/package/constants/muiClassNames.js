/**
 * Custom state classes available in MUI.
 * MUI ClassNames as the constants are not exported from MUI.
 * @see https://mui.com/material-ui/customization/how-to-customize/#overriding-styles-with-class-names
 */
const MuiClassNames = Object.freeze({
    disabled: "Mui-disabled",
    selected: "Mui-selected",
    hovered: "Mui-hovered",
    focused: "Mui-focused",
    error: "Mui-error",
    success: "Mui-success",
    focusVisible: "Mui-focusVisible",
});
export default MuiClassNames;
//# sourceMappingURL=muiClassNames.js.map