import { gridClasses } from "@mui/x-data-grid-pro";
import MuiClassNames from "./muiClassNames.js";
/**
 * Aura Material UI theme options object extension to support the
 * [MUI X](https://mui.com/x)
 * [Data Grid Pro](https://mui.com/x/api/data-grid/data-grid-pro).
 *
 * It uses the Material UI experimental
 * [CSS theme variables](https://mui.com/material-ui/experimental-api/css-theme-variables)
 * system, which requires using from `@mui/material/styles` the function
 * `extendTheme` to create the theme (extending from
 * `@tricentis/aura/constants/themeOptions.js` the Aura Material UI theme
 * options object), and the React component `ThemeProvider` to provide the
 * theme for the entire app.
 * @example
 * How to setup a themed app:
 *
 * ```tsx
 * import ScopedCssBaseline from "@mui/material/ScopedCssBaseline";
 * import {
 *   ThemeProvider,
 *   extendTheme,
 * } from "@mui/material/styles";
 * import { LicenseInfo } from "@mui/x-license";
 * import muiXLicenseKey from "@tricentis/aura/constants/muiXLicenseKey.js";
 * import themeOptions from "@tricentis/aura/constants/themeOptions.js";
 * import themeOptionsDataGrid from "@tricentis/aura/constants/themeOptionsDataGrid.js";
 *
 * // Set the MUI X Data Grid Pro license key:
 * // https://mui.com/x/introduction/licensing/#how-to-install-the-key
 * LicenseInfo.setLicenseKey(muiXLicenseKey);
 *
 * const theme = extendTheme(themeOptions, themeOptionsDataGrid);
 * const app = (
 *   <ThemeProvider theme={theme}>
 *     <ScopedCssBaseline>Your app…</ScopedCssBaseline>
 *   </ThemeProvider>
 * );
 * ```
 */
const themeOptionsDataGrid = {
    mixins: {
        MuiDataGrid: {
            // In dark mode, background.paper and aura.surface.raised resolve to the
            // same value. Using background.paper here for MUI compatibility.
            containerBackground: "var(--mui-palette-background-paper)",
            pinnedBackground: "var(--mui-palette-background-paper)",
        },
    },
    palette: {
        DataGrid: {
            // In dark mode, background.paper and aura.surface.raised resolve to the
            // same value. Using background.paper here for MUI compatibility.
            bg: "var(--mui-palette-background-paper)",
            headerBg: "var(--mui-palette-background-paper)",
            pinnedBg: "var(--mui-palette-background-paper)",
        },
    },
    components: {
        MuiDataGrid: {
            defaultProps: {
                // Filter/columns panel placement. MUI GridPanel defaults to
                // placement "bottom-end" (right). Override so panel opens on the left.
                // @see https://github.com/mui/mui-x/blob/master/packages/x-data-grid/src/components/panel/GridPanel.tsx
                slotProps: {
                    basePopper: {
                        placement: "bottom-start",
                    },
                },
                // The constants COMPACT_DENSITY_FACTOR and COMFORTABLE_DENSITY_FACTOR
                // are no longer exported by MUI X Data Grid.
                //
                // These density factors are taken from the MUI X Data Grid source code
                //
                // MUI X Data Grid: - compact: 0.7 - standard: 1 - comfortable: 1.3
                //
                // @see https://github.com/mui/mui-x/blob/4891eafe516f698fbe3689ba6a3a6c78ed069e85/packages/grid/x-data-grid/src/hooks/features/density/useGridDensity.tsx#L13-L14
                // @see https://github.com/mui/mui-x/issues/7251
                getRowHeight({ densityFactor }) {
                    switch (densityFactor) {
                        case 0.7: // compact
                            return 40;
                        case 1.3: // comfortable
                            return 56;
                        default: // standard (1)
                            return 48;
                    }
                },
            },
            styleOverrides: {
                root: ({ theme }) => ({
                    border: "none",
                    [`& .${gridClasses["filler--pinnedLeft"]}`]: {
                        borderRight: "none",
                    },
                    [`& .${gridClasses["filler--pinnedRight"]}`]: {
                        borderLeft: "none",
                    },
                    [`& .${gridClasses["container--top"]} [role=row]`]: {
                        backgroundColor: theme.vars.palette.background.paper,
                    },
                    [`& .${gridClasses.virtualScrollerContent}`]: {
                        [`& .${gridClasses.row}`]: {
                            [`&:hover, &.${MuiClassNames.hovered}`]: {
                                backgroundColor: theme.vars.palette.action.hover,
                                [`& .${gridClasses["cell--pinnedLeft"]}`]: {
                                    backgroundColor: theme.vars.palette.action.hover,
                                },
                                [`& .${gridClasses["cell--pinnedRight"]}`]: {
                                    backgroundColor: theme.vars.palette.action.hover,
                                },
                            },
                            [`&.${MuiClassNames.selected}`]: {
                                backgroundColor: theme.vars.palette.action.selected,
                                [`&:hover, &.${MuiClassNames.hovered}`]: {
                                    backgroundColor: theme.vars.palette.aura.activeHover,
                                    [`& .${gridClasses["cell--pinnedLeft"]}`]: {
                                        backgroundColor: theme.vars.palette.aura.activeHover,
                                    },
                                    [`& .${gridClasses["cell--pinnedRight"]}`]: {
                                        backgroundColor: theme.vars.palette.aura.activeHover,
                                    },
                                },
                                [`& .${gridClasses["cell--pinnedLeft"]}`]: {
                                    backgroundColor: theme.vars.palette.action.selected,
                                },
                                [`& .${gridClasses["cell--pinnedRight"]}`]: {
                                    backgroundColor: theme.vars.palette.action.selected,
                                },
                            },
                        },
                    },
                }),
                cell: ({ theme }) => ({
                    [`&.${gridClasses["cell--editing"]}`]: {
                        outlineOffset: -1,
                        outlineWidth: 1,
                        outlineStyle: "solid",
                        outlineColor: theme.vars.palette.info.light,
                        "&:focus-within": {
                            outlineColor: theme.vars.palette.info.main,
                        },
                    },
                }),
                row: ({ theme }) => ({
                    [`&.${MuiClassNames.selected}`]: {
                        backgroundColor: theme.vars.palette.action.selected,
                        [`&:hover, &.${MuiClassNames.hovered}`]: {
                            backgroundColor: theme.vars.palette.aura.activeHover,
                        },
                    },
                }),
                columnSeparator: ({ theme }) => ({
                    color: theme.vars.palette.divider,
                }),
                panelWrapper: ({ theme }) => ({
                    borderRadius: theme.aura.borderRadius.sm,
                }),
            },
        },
    },
};
export default themeOptionsDataGrid;
//# sourceMappingURL=themeOptionsDataGrid.js.map