import IconMaterialSymbolsDoneAll from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDoneAll.mjs";
/** React component for the SVG icon to use to represent status ready. */
const IconStatusReady = IconMaterialSymbolsDoneAll;
export default IconStatusReady;
//# sourceMappingURL=IconStatusReady.js.map