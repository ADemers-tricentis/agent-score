import { jsx as _jsx } from "react/jsx-runtime";
import { autocompleteClasses } from "@mui/material/Autocomplete";
import { listItemButtonClasses } from "@mui/material/ListItemButton";
import { toggleButtonClasses } from "@mui/material/ToggleButton";
import IconMaterialSymbolsCancel from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCancel.mjs";
import DARK_MODE_OVERLAYS from "../utils/private/createDarkModeOverlays.js";
import muiClassNames from "./muiClassNames.js";
// CSS color values used in the theme. They are defined as constants here and
// then referenced throughout the theme to make it easy to track all the colors
// used, and to improve bundle size by avoiding duplicate color values.
const COLOR_541313 = "#541313";
const COLOR_FBEAEA = "#FBEAEA";
const HSLA_210_60_47_1 = "hsla(210, 60%, 47%, 1)";
const HSLA_0_0_100_1 = "hsla(0, 0%, 100%, 1)";
const HSLA_210_71_68_1 = "hsla(210, 71%, 68%, 1)";
const HSLA_210_90_80_1 = "hsla(210, 90%, 80%, 1)";
const HSLA_0_0_70_1 = "hsla(0, 0%, 70%, 1)";
const HSLA_210_100_30_1 = "hsla(210, 100%, 30%, 1)";
const HSLA_210_100_90_1 = "hsla(210, 100%, 90%, 1)";
const HSLA_0_0_98_1 = "hsla(0, 0%, 98%, 1)";
const HSLA_240_5_65_1 = "hsla(240, 5%, 65%, 1)";
const HSLA_240_5_34_1 = "hsla(240, 5%, 34%, 1)";
const HSLA_240_5_84_1 = "hsla(240, 5%, 84%, 1)";
const HSLA_240_6_90_1 = "hsla(240, 6%, 90%, 1)";
const HSLA_240_5_26_1 = "hsla(240, 5%, 26%, 1)";
const HSLA_125_43_36_1 = "hsla(125, 43%, 36%, 1)";
const HSLA_21_90_48_1 = "hsla(21, 90%, 48%, 1)";
const HSLA_0_86_70_1 = "hsla(0, 86%, 70%, 1)";
const HSLA_0_80_60_1 = "hsla(0, 80%, 60%, 1)";
const HSLA_0_0_0_1 = "hsla(0, 0%, 0%, 1)";
const HSLA_240_4_46_1 = "hsla(240, 4%, 46%, 1)";
const HSLA_240_5_96_1 = "hsla(240, 5%, 96%, 1)";
const HSLA_210_70_39_1 = "hsla(210, 70%, 39%, 1)";
const HSLA_0_65_51_1 = "hsla(0, 65%, 51%, 1)";
const HSLA_122_50_35_1 = "hsla(122, 50%, 35%, 1)";
const HSLA_122_38_58_1 = "hsla(122, 38%, 58%, 1)";
const HSLA_23_80_45_1 = "hsla(23, 80%, 45%, 1)";
const HSLA_26_100_61_1 = "hsla(26, 100%, 61%, 1)";
const HSLA_0_71_97_1 = "hsla(0, 71%, 97%, 1)";
const HSLA_0_67_15_1 = "hsla(0, 67%, 15%, 1)";
const HSLA_210_100_97_1 = "hsla(210, 100%, 97%, 1)";
const HSLA_210_100_14_1 = "hsla(210, 100%, 14%, 1)";
const HSLA_122_41_97_1 = "hsla(122, 41%, 97%, 1)";
const HSLA_122_45_10_1 = "hsla(122, 45%, 10%, 1)";
const HSLA_33_100_96_1 = "hsla(33, 100%, 96%, 1)";
const HSLA_23_67_15_1 = "hsla(23, 67%, 15%, 1)";
const HSLA_240_10_4_1 = "hsla(240, 10%, 4%, 1)";
const HSLA_240_6_10_1 = "hsla(240, 6%, 10%, 1)";
const HSLA_240_4_16_1 = "hsl(240, 3.70%, 15.90%)";
/** Dark mode navigation background color constant. */
const NAVIGATION_DARK_BG_COLOR = HSLA_240_10_4_1;
/** Light mode navigation background color constant. */
const NAVIGATION_LIGHT_BG_COLOR = HSLA_0_0_100_1; // white
/** Light mode tooltip background color constant. */
const TOOLTIP_LIGHT_BG_COLOR = HSLA_240_5_34_1;
/** Light mode tooltip text color constant. */
const TOOLTIP_LIGHT_TEXT_COLOR = HSLA_0_0_100_1; // white
/** Dark mode tooltip background color constant. */
const TOOLTIP_DARK_BG_COLOR = HSLA_0_0_70_1;
/** Dark mode tooltip text color constant. */
const TOOLTIP_DARK_TEXT_COLOR = HSLA_0_0_0_1; // black
// =============================================================================
// Dark Mode Surface Tiers
// Discrete semantic tokens replacing MUI's opacity-based overlay system.
// Progression: 4% → 10% → 16% → 16% (overlay = modal)
// =============================================================================
/** Dark mode base surface - page background (darkest) */
const SURFACE_DARK_BASE = HSLA_240_10_4_1; // 4% lightness
/** Dark mode raised surface - Card, Accordion, Paper */
const SURFACE_DARK_RAISED = HSLA_240_6_10_1; // 10% lightness
/** Dark mode overlay - Menu, Popover, Autocomplete, Tooltip, Snackbar */
const SURFACE_DARK_OVERLAY = HSLA_240_4_16_1; // 16% lightness
/** Dark mode modal - Dialog, Drawer (backdrop provides differentiation) */
const SURFACE_DARK_MODAL = HSLA_240_4_16_1; // 16% lightness
/**
 * Aura Material UI theme options object.
 *
 * It uses the Material UI
 * [CSS theme variables](https://mui.com/material-ui/customization/css-theme-variables/)
 * system, which requires using from `@mui/material/styles` the function
 * `extendTheme` to create the theme, and the React component `ThemeProvider`
 * to provide the theme for the entire app.
 * @example
 * How to setup a themed app:
 *
 * ```tsx
 * import ScopedCssBaseline from "@mui/material/ScopedCssBaseline";
 * import {
 *   ThemeProvider,
 *   extendTheme,
 * } from "@mui/material/styles";
 * import themeOptions from "@tricentis/aura/constants/themeOptions.js";
 *
 * const theme = extendTheme(themeOptions);
 * const app = (
 *   <ThemeProvider theme={theme}>
 *     <ScopedCssBaseline>Your app…</ScopedCssBaseline>
 *   </ThemeProvider>
 * );
```
 */
const themeOptions = {
    // Custom.
    aura: {
        borderRadius: {
            none: 0,
            xs: 4,
            sm: 6,
            md: 8,
            lg: 10,
            circular: 9999,
        },
    },
    constants: {
        appBar: {
            height: {
                xs: 48,
                sm: 48,
                md: 48,
                lg: 48,
                xl: 48,
            },
        },
        breadcrumbs: {
            breadcrumbsHeight: 40,
            height: {
                xs: 40,
                sm: 40,
                md: 40,
                lg: 40,
                xl: 40,
            },
        },
        defaultContentLayout: {
            spacing: {
                marginBottom: 3,
                marginLeft: 3,
                marginRight: 3,
                marginTop: 3,
                paddingBottom: 3,
                paddingLeft: 3,
                paddingRight: 3,
                paddingTop: 3,
            },
            getMX() {
                return this.spacing.marginTop + this.spacing.marginBottom;
            },
            getPX() {
                return this.spacing.paddingTop + this.spacing.paddingBottom;
            },
            getMY() {
                return this.spacing.marginRight + this.spacing.marginLeft;
            },
            getPY() {
                return this.spacing.paddingRight + this.spacing.paddingLeft;
            },
        },
    },
    colorSchemes: {
        light: {
            palette: {
                AppBar: {
                    defaultBg: NAVIGATION_LIGHT_BG_COLOR,
                    darkBg: NAVIGATION_DARK_BG_COLOR,
                    darkColor: NAVIGATION_DARK_BG_COLOR,
                },
                /* Alert palette options for the light color scheme */
                Alert: {
                    errorColor: HSLA_0_65_51_1,
                    infoColor: HSLA_210_60_47_1,
                    successColor: HSLA_122_50_35_1,
                    warningColor: HSLA_23_80_45_1,
                    errorFilledBg: HSLA_0_65_51_1,
                    infoFilledBg: HSLA_210_60_47_1,
                    successFilledBg: HSLA_122_50_35_1,
                    warningFilledBg: HSLA_23_80_45_1,
                    errorFilledColor: HSLA_0_65_51_1,
                    infoFilledColor: HSLA_210_60_47_1,
                    successFilledColor: HSLA_122_50_35_1,
                    warningFilledColor: HSLA_23_80_45_1,
                    errorStandardBg: HSLA_0_71_97_1,
                    infoStandardBg: HSLA_210_100_97_1,
                    successStandardBg: HSLA_122_41_97_1,
                    warningStandardBg: HSLA_33_100_96_1,
                    errorIconColor: HSLA_0_65_51_1,
                    infoIconColor: HSLA_210_60_47_1,
                    successIconColor: HSLA_122_50_35_1,
                    warningIconColor: HSLA_23_80_45_1,
                },
                primary: {
                    main: HSLA_210_60_47_1,
                    light: HSLA_210_70_39_1,
                    dark: HSLA_210_70_39_1,
                    contrastText: HSLA_0_0_100_1,
                },
                secondary: {
                    main: HSLA_240_5_34_1,
                    light: "hsla(240, 4%, 46%, 1)",
                    dark: "hsla(240, 4%, 16%, 1)",
                    contrastText: HSLA_0_0_100_1,
                },
                error: {
                    main: "hsla(0, 65%, 51%, 1)",
                    light: HSLA_0_80_60_1,
                    dark: "hsla(0, 66%, 42%, 1)",
                    contrastText: HSLA_0_0_100_1,
                },
                warning: {
                    main: "hsla(23, 80%, 45%, 1)",
                    light: "hsla(25, 95%, 53%, 1)",
                    dark: "hsla(17, 88%, 40%, 1)",
                    contrastText: HSLA_0_0_100_1,
                },
                info: {
                    main: HSLA_210_60_47_1,
                    light: "hsla(207, 98%, 48%, 1)",
                    dark: HSLA_210_100_30_1,
                    contrastText: HSLA_0_0_100_1,
                },
                success: {
                    main: "hsla(122, 50%, 35%, 1)",
                    light: "hsla(124, 39%, 49%, 1)",
                    dark: "hsla(124, 40%, 29%, 1)",
                    contrastText: HSLA_0_0_100_1,
                },
                text: {
                    primary: HSLA_0_0_0_1,
                    secondary: HSLA_240_4_46_1,
                    disabled: "hsla(240, 5%, 65%, 1)",
                },
                divider: HSLA_240_5_84_1,
                TableCell: {
                    border: HSLA_240_5_84_1,
                },
                background: {
                    default: HSLA_0_0_100_1,
                    paper: HSLA_0_0_100_1,
                },
                action: {
                    active: HSLA_240_5_34_1,
                    hover: HSLA_0_0_98_1,
                    selected: "hsla(210, 100%, 95%, 1)",
                    disabled: HSLA_240_5_65_1,
                    disabledBackground: HSLA_240_6_90_1,
                    activatedOpacity: 0.12,
                    selectedOpacity: 0.08,
                },
                aura: {
                    backgroundContrast: HSLA_0_0_0_1, // black
                    navigationBackground: HSLA_0_0_100_1,
                    brand: HSLA_210_100_30_1,
                    brandInverted: HSLA_0_0_100_1,
                    workspace: HSLA_240_6_90_1,
                    activeHover: "hsla(213, 100%, 98%, 1)",
                    backgroundActiveDisabled: HSLA_210_100_90_1,
                    backgroundDefault: HSLA_240_5_96_1,
                    // Light mode uses same color for all tiers - shadows provide depth
                    surface: {
                        base: HSLA_240_5_96_1,
                        raised: HSLA_0_0_100_1,
                        overlay: HSLA_0_0_100_1,
                        modal: HSLA_0_0_100_1,
                    },
                },
                tooltip: {
                    bg: TOOLTIP_LIGHT_BG_COLOR,
                    text: TOOLTIP_LIGHT_TEXT_COLOR,
                    error: {
                        bg: COLOR_FBEAEA,
                        text: COLOR_541313,
                    },
                },
            },
        },
        dark: {
            palette: {
                AppBar: {
                    defaultBg: NAVIGATION_DARK_BG_COLOR,
                    darkBg: NAVIGATION_DARK_BG_COLOR,
                    darkColor: NAVIGATION_DARK_BG_COLOR,
                },
                /* Alert palette options for the dark color scheme */
                Alert: {
                    errorColor: HSLA_0_80_60_1,
                    infoColor: HSLA_210_90_80_1,
                    successColor: HSLA_122_38_58_1,
                    warningColor: HSLA_26_100_61_1,
                    errorFilledBg: HSLA_0_80_60_1,
                    infoFilledBg: HSLA_210_90_80_1,
                    successFilledBg: HSLA_122_38_58_1,
                    warningFilledBg: HSLA_26_100_61_1,
                    errorFilledColor: HSLA_0_80_60_1,
                    infoFilledColor: HSLA_210_90_80_1,
                    successFilledColor: HSLA_122_38_58_1,
                    warningFilledColor: HSLA_26_100_61_1,
                    errorStandardBg: HSLA_0_67_15_1,
                    infoStandardBg: HSLA_210_100_14_1,
                    successStandardBg: HSLA_122_45_10_1,
                    warningStandardBg: HSLA_23_67_15_1,
                    errorIconColor: HSLA_0_80_60_1,
                    infoIconColor: HSLA_210_90_80_1,
                    successIconColor: HSLA_122_38_58_1,
                    warningIconColor: HSLA_26_100_61_1,
                },
                primary: {
                    main: HSLA_210_71_68_1,
                    light: HSLA_210_90_80_1,
                    dark: HSLA_210_90_80_1,
                    contrastText: HSLA_0_0_0_1,
                },
                secondary: {
                    main: "hsla(240, 5%, 84%, 1)",
                    light: "hsla(240, 5%, 65%, 1)",
                    dark: HSLA_240_5_96_1,
                    contrastText: HSLA_0_0_0_1,
                },
                error: {
                    main: HSLA_0_80_60_1,
                    light: "hsla(0, 85%, 82%, 1)",
                    dark: HSLA_0_86_70_1,
                    contrastText: HSLA_0_0_0_1,
                },
                info: {
                    main: "hsla(207, 100%, 73%, 1)",
                    light: "hsla(209, 100%, 86%, 1)",
                    dark: "hsla(207, 100%, 59%, 1)",
                    contrastText: HSLA_0_0_0_1,
                },
                warning: {
                    main: "hsla(26, 100%, 61%, 1)",
                    light: "hsla(31, 97%, 72%, 1)",
                    dark: HSLA_21_90_48_1,
                    contrastText: HSLA_0_0_0_1,
                },
                success: {
                    main: "hsla(122, 38%, 58%, 1)",
                    light: "hsla(123, 43%, 73%, 1)",
                    dark: HSLA_125_43_36_1,
                    contrastText: HSLA_0_0_0_1,
                },
                divider: HSLA_240_5_34_1,
                TableCell: {
                    border: HSLA_240_5_34_1,
                },
                background: {
                    default: SURFACE_DARK_BASE,
                    paper: SURFACE_DARK_RAISED,
                },
                text: {
                    primary: HSLA_0_0_100_1,
                    secondary: "hsla(240, 5%, 84%, 1)",
                    disabled: HSLA_240_4_46_1,
                },
                action: {
                    active: HSLA_0_0_70_1,
                    hover: "hsla(240, 4%, 16%, 1)",
                    selected: "hsla(214, 72%, 23%, 1)",
                    disabled: HSLA_240_5_34_1,
                    disabledBackground: HSLA_240_5_26_1,
                    selectedOpacity: 1,
                    activatedOpacity: 1,
                },
                aura: {
                    backgroundContrast: HSLA_0_0_100_1, // white
                    navigationBackground: NAVIGATION_DARK_BG_COLOR,
                    brand: HSLA_0_0_100_1,
                    brandInverted: HSLA_210_100_30_1,
                    workspace: HSLA_240_5_26_1,
                    activeHover: "hsla(216, 71%, 15%, 1)",
                    backgroundActiveDisabled: HSLA_210_100_30_1,
                    backgroundDefault: SURFACE_DARK_BASE,
                    // Semantic surface tiers
                    surface: {
                        base: SURFACE_DARK_BASE,
                        raised: SURFACE_DARK_RAISED,
                        overlay: SURFACE_DARK_OVERLAY,
                        modal: SURFACE_DARK_MODAL,
                    },
                },
                tooltip: {
                    bg: TOOLTIP_DARK_BG_COLOR,
                    text: TOOLTIP_DARK_TEXT_COLOR,
                    error: {
                        bg: COLOR_FBEAEA,
                        text: COLOR_541313,
                    },
                },
            },
            // Custom overlays using discrete surface tokens at known elevations.
            // See src/utils/private/createDarkModeOverlays.ts for the math.
            overlays: DARK_MODE_OVERLAYS,
        },
    },
    typography: {
        fontFamily: "Inter",
        h1: {
            fontWeight: 300,
            fontSize: "1.75rem",
            lineHeight: "2.25rem",
            letterSpacing: "0.03125rem",
        },
        h2: {
            fontWeight: 300,
            fontSize: "1.5625rem",
            lineHeight: "2rem",
            letterSpacing: "0.025rem",
        },
        h3: {
            fontWeight: 400,
            fontSize: "1.375rem",
            lineHeight: " 1.75rem",
            letterSpacing: "0.07125rem",
        },
        h4: {
            fontWeight: 400,
            fontSize: "1.25rem",
            lineHeight: " 1.75rem",
            letterSpacing: "0.00625rem",
        },
        h5: {
            fontWeight: 400,
            fontSize: "1.125rem",
            lineHeight: "1.5rem",
            letterSpacing: "0.025rem",
        },
        h6: {
            fontWeight: 500,
            fontSize: "1rem",
            lineHeight: "1.5rem",
            letterSpacing: "0.025rem",
        },
        subtitle1: {
            fontWeight: 400,
            fontSize: "0.875rem",
            lineHeight: "1.25rem",
            letterSpacing: "0.009375rem",
        },
        subtitle2: {
            fontWeight: 500,
            fontSize: "0.75rem",
            lineHeight: "1.25rem",
            letterSpacing: "0.00625rem",
        },
        body1: {
            fontWeight: 400,
            fontSize: "0.875rem",
            lineHeight: "1.25rem",
            letterSpacing: "0.03125rem",
        },
        body2: {
            fontWeight: 400,
            fontSize: "0.875rem",
            lineHeight: "1.25rem",
            letterSpacing: "0.03125rem",
        },
        caption: {
            fontWeight: 400,
            fontSize: "0.75rem",
            lineHeight: "1.25rem",
            letterSpacing: "0.025rem",
        },
        overline: {
            fontWeight: 400,
            fontSize: "0.6875rem",
            lineHeight: "1rem",
            letterSpacing: "0.09375rem",
        },
        // Custom.
        tooltip: {
            fontWeight: 500,
            fontSize: "0.75rem",
            lineHeight: "1rem",
            letterSpacing: 0,
        },
        button: {
            textTransform: "none",
        },
    },
    components: {
        MuiAlert: {
            styleOverrides: {
                root: ({ ownerState, theme }) => ownerState.variant !== "filled"
                    ? {
                        border: `1px solid ${theme.vars.palette[ownerState.color ?? ownerState.severity ?? "success"].main}`,
                        color: theme.vars.palette.text.primary,
                        borderRadius: theme.aura.borderRadius.md,
                    }
                    : {},
            },
        },
        MuiAppBar: {
            defaultProps: {
                color: "transparent",
            },
            styleOverrides: {
                root: ({ theme }) => ({
                    /**
                     * Sets the background color of the AppBar on the Inverted-L layout.
                     * Overrides the default background color of the AppBar set by its
                     * defaultProps.
                     */
                    backgroundColor: theme.vars.palette.AppBar.defaultBg,
                    borderBottom: `1px solid ${theme.vars.palette.divider}`,
                    boxShadow: "none",
                    color: theme.vars.palette.text.primary,
                    gap: theme.spacing(2),
                    height: theme.constants.appBar.height.xs,
                    paddingLeft: theme.spacing(2),
                    paddingRight: theme.spacing(2),
                    paddingTop: theme.spacing(1),
                    paddingBottom: theme.spacing(1),
                    "& > .MuiToolbar-root": {
                        display: "flex",
                        flexDirection: "row",
                        justifyContent: "space-between",
                        width: "100%",
                        [theme.breakpoints.up("xs")]: {
                            minHeight: theme.spacing(4),
                            paddingLeft: 0,
                            paddingRight: 0,
                        },
                        "& > .MuiBox-root": {
                            alignItems: "center",
                            boxSizing: "border-box",
                            display: "flex",
                            flexDirection: "row",
                            gap: theme.spacing(3),
                            height: "100%",
                        },
                    },
                }),
            },
        },
        MuiButton: {
            defaultProps: {
                disableElevation: true,
                disableFocusRipple: true,
            },
            styleOverrides: {
                root: ({ theme, ownerState }) => {
                    const paletteKey = (ownerState.color ?? "primary");
                    const paletteEntry = paletteKey in theme.vars.palette
                        ? theme.vars.palette[paletteKey]
                        : undefined;
                    const hasMain = (value) => typeof value === "object" &&
                        value !== null &&
                        "main" in value &&
                        typeof value.main === "string";
                    const paletteMain = hasMain(paletteEntry)
                        ? paletteEntry.main
                        : theme.vars.palette.primary.main;
                    return {
                        borderRadius: theme.aura.borderRadius.xs,
                        paddingLeft: theme.spacing(1),
                        paddingRight: theme.spacing(1),
                        paddingTop: theme.spacing(0.5),
                        paddingBottom: theme.spacing(0.5),
                        ...(ownerState.variant === "outlined" && {
                            backgroundColor: theme.vars.palette.aura.backgroundDefault,
                            color: paletteMain,
                            border: "none",
                            "&:hover, &.Mui-hovered": {
                                backgroundColor: theme.vars.palette.action.hover,
                            },
                            "&.Mui-disabled": {
                                border: "none",
                                color: theme.vars.palette.text.disabled,
                                backgroundColor: theme.vars.palette.action.disabledBackground,
                            },
                        }),
                        ...(ownerState.color === "secondary" &&
                            theme.palette.mode == "light" &&
                            ownerState.variant !== "text" && {
                            backgroundColor: theme.vars.palette.aura.backgroundDefault,
                            color: theme.vars.palette.secondary.main,
                            "&:hover, &.Mui-hovered": {
                                backgroundColor: theme.vars.palette.action.hover,
                            },
                            "&:focus, &.Mui-focused": {
                                color: theme.vars.palette.primary.main,
                                backgroundColor: theme.vars.palette.action.selected,
                            },
                            "&.Mui-disabled": {
                                border: "none",
                                color: theme.vars.palette.text.disabled,
                                backgroundColor: theme.vars.palette.action.disabledBackground,
                            },
                        }),
                    };
                },
                sizeSmall: {
                    minHeight: 32,
                },
                sizeMedium: {
                    minHeight: 36,
                },
            },
        },
        MuiBreadcrumbs: {
            styleOverrides: {
                root: ({ theme }) => ({
                    display: "flex",
                    alignItems: "center",
                    marginInline: theme.spacing(2.5),
                    borderBottom: `1px solid ${theme.vars.palette.divider}`,
                    paddingBlock: theme.spacing(0.5),
                }),
                li: ({ theme }) => ({
                    display: "flex",
                    alignItems: "center",
                    "&:last-child": {
                        color: theme.vars.palette.text.primary,
                    },
                }),
            },
        },
        MuiChip: {
            defaultProps: {
                deleteIcon: _jsx(IconMaterialSymbolsCancel, {}),
            },
            styleOverrides: {
                deleteIcon: {
                    color: "inherit",
                    opacity: 0.7,
                    "&:hover": {
                        color: "inherit",
                        opacity: 1,
                    },
                },
            },
        },
        MuiDivider: {
            styleOverrides: {
                vertical: {
                    borderRightWidth: "2px",
                    "&::before, &::after": {
                        borderLeftWidth: "2px",
                    },
                },
            },
        },
        MuiIconButton: {
            styleOverrides: {
                sizeSmall: {
                    padding: 4,
                },
            },
        },
        MuiSnackbar: {
            defaultProps: {
                autoHideDuration: 10_000,
            },
        },
        MuiSnackbarContent: {
            styleOverrides: {
                root: ({ theme }) => ({
                    backgroundImage: "none",
                    backgroundColor: theme.vars.palette.aura.surface.overlay,
                }),
            },
        },
        MuiTooltip: {
            styleOverrides: {
                tooltip: ({ theme }) => ({
                    ...theme.typography.tooltip,
                    backgroundColor: theme.vars.palette.tooltip.bg,
                    color: theme.vars.palette.tooltip.text,
                }),
                arrow: ({ theme }) => ({
                    color: theme.vars.palette.tooltip.bg,
                }),
            },
        },
        MuiTypography: {
            defaultProps: {
                variantMapping: {
                    tooltip: "span",
                },
            },
        },
        MuiButtonGroup: {
            defaultProps: {
                disableElevation: true,
            },
        },
        MuiAccordion: {
            styleOverrides: {
                root: ({ theme }) => ({
                    backgroundColor: theme.vars.palette.background.paper,
                }),
            },
        },
        MuiAccordionDetails: {
            styleOverrides: {
                root: ({ theme }) => ({
                    ".Mui-disabled &": {
                        color: theme.vars.palette.text.disabled,
                    },
                }),
            },
        },
        MuiCardActions: {
            styleOverrides: {
                root: ({ theme }) => ({
                    padding: `${theme.spacing(3)} ${theme.spacing(2.5)}`,
                }),
            },
        },
        MuiCardContent: {
            styleOverrides: {
                root: ({ theme }) => ({
                    padding: theme.spacing(3),
                    color: theme.vars.palette.text.secondary,
                }),
            },
        },
        MuiCardHeader: {
            styleOverrides: {
                root: ({ theme }) => ({
                    padding: theme.spacing(3),
                }),
            },
        },
        MuiCard: {
            styleOverrides: {
                root: ({ theme }) => ({
                    borderRadius: theme.aura.borderRadius.md,
                }),
            },
        },
        MuiDialogTitle: { defaultProps: { typography: "h3" } },
        MuiDialogContent: {
            styleOverrides: {
                root: ({ theme }) => ({
                    padding: `${theme.spacing(0)} ${theme.spacing(3)}`,
                    color: theme.vars.palette.text.primary,
                }),
            },
        },
        MuiDialogContentText: {
            styleOverrides: {
                root: ({ theme }) => ({
                    color: theme.vars.palette.text.primary,
                }),
            },
        },
        MuiDialogActions: {
            styleOverrides: {
                root: ({ theme }) => ({
                    padding: `${theme.spacing(2)} ${theme.spacing(3)}`,
                }),
            },
        },
        MuiDialog: {
            styleOverrides: {
                paper: ({ theme }) => ({
                    borderRadius: theme.aura.borderRadius.lg,
                }),
            },
        },
        MuiAccordionSummary: {
            styleOverrides: {
                root: ({ theme }) => ({
                    flexDirection: "row-reverse",
                    gap: theme.spacing(1),
                    transition: "all 150ms linear",
                }),
                expanded: ({ theme }) => ({
                    minHeight: "auto",
                    marginBottom: theme.spacing(1),
                    "&.MuiAccordionSummary-content": {
                        marginBlock: theme.spacing(1.5),
                    },
                }),
                disabled: ({ theme }) => ({
                    opacity: 1,
                    "& .MuiTypography-root": {
                        color: theme.vars.palette.text.disabled,
                    },
                    "& .MuiAccordionSummary-expandIconWrapper": {
                        color: theme.vars.palette.text.disabled,
                    },
                }),
                expandIconWrapper: {
                    transform: "rotate(-90deg)",
                    "&.Mui-expanded": {
                        transform: "rotate(0deg)",
                    },
                },
            },
        },
        MuiTab: {
            styleOverrides: {
                root: ({ theme }) => ({
                    minHeight: 40,
                    padding: theme.spacing(1),
                    "&:hover": {
                        backgroundColor: theme.vars.palette.action.hover,
                        borderRadius: theme.aura.borderRadius.xs,
                    },
                }),
            },
        },
        MuiTabs: {
            styleOverrides: {
                root: ({ theme }) => ({
                    minHeight: 40,
                    backgroundColor: theme.vars.palette.background.paper,
                }),
            },
        },
        MuiOutlinedInput: {
            styleOverrides: {
                notchedOutline: ({ theme }) => ({
                    borderColor: theme.vars.palette.divider,
                }),
            },
        },
        MuiButtonBase: {
            styleOverrides: {
                root: ({ theme }) => ({
                    "&.MuiMenuItem-root": {
                        "&.MuiMultiSectionDigitalClockSection-item": {
                            // Set the background, color of a selected time picker item.
                            "&.Mui-selected": {
                                backgroundColor: theme.vars.palette.action.selected,
                                color: theme.vars.palette.primary.main,
                                "&:hover, &.Mui-hovered": {
                                    backgroundColor: theme.vars.palette.aura.activeHover,
                                },
                                "&:focus-visible": {
                                    backgroundColor: theme.vars.palette.action.selected,
                                },
                            },
                            "&:hover": {
                                backgroundColor: theme.vars.palette.action.hover,
                                color: theme.vars.palette.text.primary,
                            },
                        },
                    },
                    // Set the background, color of a selected date.
                    "&.MuiPickersDay-root": {
                        "&.Mui-selected": {
                            backgroundColor: theme.vars.palette.action.selected,
                            color: theme.vars.palette.primary.main,
                            "&:hover, &.Mui-hovered": {
                                backgroundColor: theme.vars.palette.aura.activeHover,
                            },
                            "&:focus": {
                                backgroundColor: theme.vars.palette.action.selected,
                            },
                            "&:focus-visible": {
                                backgroundColor: theme.vars.palette.action.selected,
                            },
                        },
                        "&:hover": {
                            backgroundColor: theme.vars.palette.action.hover,
                            color: theme.vars.palette.text.primary,
                        },
                    },
                }),
            },
        },
        MuiToggleButton: {
            styleOverrides: {
                root: ({ theme }) => ({
                    ":hover": {
                        backgroundColor: theme.vars.palette.action.hover,
                        borderLeft: `1px solid ${theme.vars.palette.divider}`,
                    },
                    [`&.${toggleButtonClasses.selected}`]: {
                        backgroundColor: theme.vars.palette.action.selected,
                        borderLeft: `1px solid ${theme.vars.palette.divider}`,
                        color: theme.vars.palette.primary.main,
                        "&:hover, &.Mui-hovered": {
                            backgroundColor: theme.vars.palette.aura.activeHover,
                        },
                    },
                }),
            },
        },
        MuiListItemButton: {
            styleOverrides: {
                root: ({ theme }) => ({
                    [`&.${listItemButtonClasses.selected}`]: {
                        backgroundColor: theme.vars.palette.action.selected,
                        color: theme.vars.palette.primary.main,
                        "&:hover, &.Mui-hovered": {
                            backgroundColor: theme.vars.palette.aura.activeHover,
                        },
                    },
                }),
            },
        },
        MuiAutocomplete: {
            defaultProps: {
                slotProps: {
                    // Set elevation to 8 so autocomplete dropdown uses overlay surface
                    paper: { elevation: 8 },
                },
            },
            styleOverrides: {
                listbox: ({ theme }) => ({
                    borderRadius: theme.aura.borderRadius.sm,
                    [`& .${autocompleteClasses.option}`]: {
                        "&:hover": {
                            backgroundColor: theme.vars.palette.action.hover,
                        },
                    },
                    [`& .${autocompleteClasses.option}[aria-selected="true"]`]: {
                        backgroundColor: theme.vars.palette.action.selected,
                        [`&.${autocompleteClasses.focused}`]: {
                            backgroundColor: theme.vars.palette.action.selected,
                            "&:hover, &.Mui-hovered": {
                                backgroundColor: theme.vars.palette.aura.activeHover,
                            },
                        },
                    },
                }),
            },
        },
        MuiPaper: {
            styleOverrides: {
                root: ({ theme }) => ({
                    [`&.${autocompleteClasses.paper}`]: {
                        borderRadius: theme.aura.borderRadius.sm,
                    },
                }),
            },
        },
        MuiPopover: {
            styleOverrides: {
                paper: ({ theme }) => ({
                    borderRadius: theme.aura.borderRadius.sm,
                }),
            },
        },
        MuiMenu: {
            styleOverrides: {
                paper: ({ theme }) => ({
                    borderRadius: theme.aura.borderRadius.sm,
                }),
            },
        },
        MuiMenuItem: {
            styleOverrides: {
                root: ({ theme }) => ({
                    borderRadius: theme.aura.borderRadius.sm,
                    marginRight: theme.spacing(1),
                    marginLeft: theme.spacing(1),
                    "&.Mui-selected": {
                        color: theme.vars.palette.primary.light,
                        backgroundColor: theme.vars.palette.action.selected,
                        "&:hover": {
                            color: theme.vars.palette.primary.main,
                            backgroundColor: theme.vars.palette.aura.activeHover,
                        },
                        [`&:focus-visible, &.${muiClassNames.focusVisible}`]: {
                            backgroundColor: theme.vars.palette.action.selected,
                        },
                    },
                }),
            },
        },
        MuiDrawer: {
            styleOverrides: {
                paper: ({ theme, ownerState }) => {
                    const borderRadius = theme.aura.borderRadius.lg;
                    switch (ownerState.anchor) {
                        case "right":
                            return {
                                borderTopLeftRadius: borderRadius,
                                borderBottomLeftRadius: borderRadius,
                            };
                        case "left":
                            return {
                                borderTopRightRadius: borderRadius,
                                borderBottomRightRadius: borderRadius,
                            };
                        case "top":
                            return {
                                borderBottomLeftRadius: borderRadius,
                                borderBottomRightRadius: borderRadius,
                            };
                        case "bottom":
                            return {
                                borderTopLeftRadius: borderRadius,
                                borderTopRightRadius: borderRadius,
                            };
                        default:
                            return {};
                    }
                },
            },
        },
    },
};
export default themeOptions;
//# sourceMappingURL=themeOptions.js.map