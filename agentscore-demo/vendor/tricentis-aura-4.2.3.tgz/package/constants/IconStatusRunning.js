import IconMaterialSymbolsAutorenew from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAutorenew.mjs";
/** React component for the SVG icon to use to represent status running. */
const IconStatusRunning = IconMaterialSymbolsAutorenew;
export default IconStatusRunning;
//# sourceMappingURL=IconStatusRunning.js.map