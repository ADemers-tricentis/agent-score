import IconMaterialSymbolsCancel from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCancel.mjs";
/** React component for the SVG icon to use to represent status failed. */
const IconStatusFailed = IconMaterialSymbolsCancel;
export default IconStatusFailed;
//# sourceMappingURL=IconStatusFailed.js.map