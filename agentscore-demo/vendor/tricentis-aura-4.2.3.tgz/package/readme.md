# Tricentis Aura UI

The Tricentis Aura UI library for [React](https://react.dev); a [Material UI](https://mui.com/material-ui) theme, components, constants, and utilities for building Tricentis products.

- [Confluence](https://tricentis.atlassian.net/wiki/spaces/DS/overview)
- [Storybook (v3)](https://silver-broccoli-97498d4f.pages.github.io/v3)
- [Storybook (latest)](https://silver-broccoli-97498d4f.pages.github.io/latest/) currently version
- [GitHub](https://github.com/Tricentis-UX/aura-ui)
- [Tricentis MUI Icons](https://github.com/Tricentis-UX/mui-icons) React components implementing the [Google font](https://fonts.google.com/icons?icon.style=Rounded) symbols.
- [Figma](https://www.figma.com/files/team/1081138824573078528)
- [JIRA](https://tricentis.atlassian.net/jira/software/c/projects/UXDESIGN/boards/132)
- [Slack](https://tricentis.slack.com/archives/C01FWBM5N13)

## Installation

To install Tricentis Aura UI in an existing Node.js and React project:

1. [Install Node.js and npm](https://docs.npmjs.com/downloading-and-installing-node-js-and-npm) versions according to the [_**Requirements**_](#requirements).
2. Follow [these instructions](https://dev.azure.com/tricentis/cloud/_artifacts/feed/TricentisEnterpriseCloud/connect/npm) to configure your [user `.npmrc` file](https://docs.npmjs.com/cli/v10/configuring-npm/npmrc#per-user-config-file) to be able to install private `@tricentis` scoped npm packages. To only use the Tricentis npm registry for `@tricentis` scoped packages, use the prefix:

   ```diff
   - registry=https://pkgs.dev.azure.com/tricentis/_packaging/TricentisEnterpriseCloud/npm/registry/
   + @tricentis:registry=https://pkgs.dev.azure.com/tricentis/_packaging/TricentisEnterpriseCloud/npm/registry/
     always-auth=true
   ```

3. Install the private npm package `@tricentis/aura` using the project’s chosen npm package manager CLI. Using [npm](https://docs.npmjs.com/cli):

   ```sh
   npm install @tricentis/aura
   ```

4. [Install Material UI and Emotion](https://mui.com/material-ui/getting-started/installation). Ignore instructions to install the default Material UI theme font `Roboto`, as the Aura theme instead uses the font [`Inter`](https://rsms.me/inter).

5. Setup the Aura Material UI theme and the scoped baseline styles:

```tsx
/// <reference types="@mui/material/themeCssVarsAugmentation" />
import ScopedCssBaseline from "@mui/material/ScopedCssBaseline";
import { ThemeProvider, extendTheme } from "@mui/material/styles";
import themeOptions from "@tricentis/aura/constants/themeOptions.js";

const theme = extendTheme(themeOptions);
const app = (
  <ThemeProvider theme={theme}>
    <ScopedCssBaseline>Your app…</ScopedCssBaseline>
  </ThemeProvider>
);
```

The Aura theme uses the Material UI [CSS theme variables](https://mui.com/material-ui/customization/css-theme-variables/usage/) system, which requires using from `@mui/material/styles` the function `extendTheme` to create the theme, and the React component `ThemeProvider` to provide the theme for the entire app.

Aura uses the [Triple‑Slash Directives](https://www.typescriptlang.org/docs/handbook/triple-slash-directives.html#-reference-types-) to augment the Material UI theme type definitions with the CSS theme variables system.

```tsx
/// <reference types="@mui/material/themeCssVarsAugmentation" />
```

Use the scoped instead of global baseline styles to avoid interfering with HTML outside the app that’s managed by third party scripts (e.g. chat clients) or browser extensions.

6. Specify these CSS `font-family` web fonts used by the Aura Material UI theme:
   - `Inter`: Use the [latest release](https://github.com/rsms/inter/releases) (>= [v4](https://github.com/rsms/inter/discussions/463)), and reference via CSS `@font-face` the separate variable weight font `.woff2` files for CSS `font-style` `normal` and `italic`.

   For example, see in this repo [`.storybook/public/fonts.css`](./.storybook/public/fonts.css).

   Avoid third party CDNs such as [Google Fonts](https://fonts.google.com), as:
   - They usually don’t allow the font version to be specified.
   - Performance problems.
   - Privacy issues.

### MUI X installation

#### MUI X Data Grid Pro

Optionally, these extra installation steps allow use of the [MUI X](https://mui.com/x) [Data Grid Pro](https://mui.com/x/api/data-grid/data-grid-pro):

1. Install [`@mui/x-data-grid-pro`](https://npm.im/@mui/x-data-grid-pro) v8 and [`@mui/x-license`](https://npm.im/@mui/x-license) v8, by running:

   ```sh
   npm install @mui/x-data-grid-pro@8 @mui/x-license@8
   ```

2. Import the [MUI X Pro plan](https://mui.com/x/introduction/licensing/#pro-plan) license key `muiXLicenseKey` from `@tricentis/aura/constants/muiXLicenseKey.js` and follow the [license key installation instructions](https://mui.com/x/introduction/licensing/#how-to-install-the-key).

3. Also extend the Material UI theme with `themeOptionsDataGrid` from `@tricentis/aura/constants/themeOptionsDataGrid.js`.

```tsx
import ScopedCssBaseline from "@mui/material/ScopedCssBaseline";
import { ThemeProvider, extendTheme } from "@mui/material/styles";
import { LicenseInfo } from "@mui/x-license";
import muiXLicenseKey from "@tricentis/aura/constants/muiXLicenseKey.js";
import themeOptions from "@tricentis/aura/constants/themeOptions.js";
import themeOptionsDataGrid from "@tricentis/aura/constants/themeOptionsDataGrid.js";

// Set the MUI X Data Grid Pro license key:
// https://mui.com/x/introduction/licensing/#how-to-install-the-key
LicenseInfo.setLicenseKey(muiXLicenseKey);

const theme = extendTheme(themeOptions, themeOptionsDataGrid);
const app = (
  <ThemeProvider theme={theme}>
    <ScopedCssBaseline>Your app…</ScopedCssBaseline>
  </ThemeProvider>
);
```

#### MUI X Date and Time Pickers Pro

Optionally, these extra installation steps allow use of the [MUI X Date and Time Pickers Pro](https://mui.com/x/api/date-pickers/time-picker/):

1. Install [`@mui/x-date-pickers-pro`](https://www.npmjs.com/package/@mui/x-date-pickers-pro) v8 and [`@mui/x-license`](https://npm.im/@mui/x-license) v8, by running:

   ```sh
   npm install @mui/x-date-pickers-pro@8 @mui/x-license@8
   ```

2. Import the [MUI X Pro plan](https://mui.com/x/introduction/licensing/#pro-plan) license key `muiXLicenseKey` from `@tricentis/aura/constants/muiXLicenseKey.js` and follow the [license key installation instructions](https://mui.com/x/introduction/licensing/#how-to-install-the-key).

Before trying to render any component, you have to make sure that there is a `LocalizationProvider` upper in the React tree. Aura uses `AdapterDayjs` which is based on [dayjs](https://day.js.org/) and makes it accessible to all the Date and Time Pickers component using React context.

The general recommendation is to declare the `LocalizationProvider` once, wrapping your entire application. Then, you don't need to repeat the boilerplate code for every Date and Time Picker in your application.

```tsx
// Other imports…
import { LocalizationProvider } from "@mui/x-date-pickers-pro";
import { AdapterDayjs } from "@mui/x-date-pickers-pro/AdapterDayjs";

const app = (
  <ThemeProvider theme={theme}>
    <ScopedCssBaseline>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        Your app…
      </LocalizationProvider>
    </ScopedCssBaseline>
  </ThemeProvider>
);
```

#### MUI X Tree View Pro

Optionally, these extra installation steps allow use of the [MUI X Tree View Pro](https://mui.com/x/api/tree-view/rich-tree-view-pro):

1. Install [`@mui/x-tree-view-pro`](https://www.npmjs.com/package/@mui/x-tree-view-pro) v8 and [`@mui/x-license`](https://npm.im/@mui/x-license) v8, by running:

   ```sh
   npm install @mui/x-tree-view-pro@8 @mui/x-license@8
   ```

2. Import the [MUI X Pro plan](https://mui.com/x/introduction/licensing/#pro-plan) license key `muiXLicenseKey` from `@tricentis/aura/constants/muiXLicenseKey.js` and follow the [license key installation instructions](https://mui.com/x/introduction/licensing/#how-to-install-the-key).

3. Also extend the Material UI theme with `themeOptionsTreeView` from `@tricentis/aura/constants/themeOptionsTreeView.js`.

```tsx
import ScopedCssBaseline from "@mui/material/ScopedCssBaseline";
import { ThemeProvider, extendTheme } from "@mui/material/styles";
import { LicenseInfo } from "@mui/x-license";
import muiXLicenseKey from "@tricentis/aura/constants/muiXLicenseKey.js";
import themeOptions from "@tricentis/aura/constants/themeOptions.js";
import themeOptionsTreeView from "@tricentis/aura/constants/themeOptionsTreeView.js";

// Set the MUI X Tree View Pro license key:
// https://mui.com/x/introduction/licensing/#how-to-install-the-key
LicenseInfo.setLicenseKey(muiXLicenseKey);

const theme = extendTheme(themeOptions, themeOptionsTreeView);
const app = (
  <ThemeProvider theme={theme}>
    <ScopedCssBaseline>Your app…</ScopedCssBaseline>
  </ThemeProvider>
);
```

## Exports

The npm package `@tricentis/aura` features [optimal JavaScript module design](https://jaydenseric.com/blog/optimal-javascript-module-design). It doesn’t have a main index module, so use deep imports (using the file extension `.js`) from the ECMAScript modules that are exported via the [`package.json`](./package.json) field [`exports`](https://nodejs.org/api/packages.html#exports):

- `components/`: React component modules.
- `constants/`: Constant modules.
- `utils/`: Utility modules.

## Requirements

Supported runtime environments:

- [Node.js](https://nodejs.org) versions `^20.19.0 || >=22.12.0`.
- Browsers matching the [Browserslist](https://browsersl.ist) query [`> 0.5%, not OperaMini all, not dead`](https://browsersl.ist/#q=%3E+0.5%25%2C+not+OperaMini+all%2C+not+dead).

Supported TypeScript versions: v5+.

Supported React versions: `^18.0.0` or `^19.0.0`.

Supported Material-UI versions: `@mui/material` `^7.3.4` (required).

> [!WARNING]
>
> While this package has correct [ESM for Node.js and TypeScript](https://www.typescriptlang.org/docs/handbook/modules/theory.html#module-format-detection), the [Material UI dependencies don’t](https://github.com/mui/material-ui/issues/30671). Until this is fixed upstream, instead of the correct TypeScript config of [`compilerOptions.module`](https://www.typescriptlang.org/tsconfig#module) set to [`"nodenext"`](https://www.typescriptlang.org/docs/handbook/modules/reference.html#node16-nodenext), projects must set [`"preserve"`](https://www.typescriptlang.org/docs/handbook/modules/reference.html#preserve), and must use a bundler (e.g. [esbuild](https://esbuild.github.io) or [webpack](https://webpack.js.org)) to consume this package as Node.js and browsers can’t run it directly. Bundlers have to be specially configured to be able to resolve the non standard ESM dependencies.

## Contributing

See the [contributing guidelines](/contributing.md) to learn about the setup, code conventions, and more.

## Scripts

These CLI scripts are used to install, build, serve, and quality check the project.

### Install script

To install dependencies:

```sh
pnpm install
```

### Prepack script

To build artifacts so the repo can be used as an installed package:

```sh
node --run prepack
```

This [npm life cycle script](https://docs.npmjs.com/cli/v10/using-npm/scripts#life-cycle-scripts) is automatically used by the npm CLI in certain situations and isn’t for manual use (instead see [**_Build scripts_**](#build-scripts)). It allows the `@tricentis/aura` package to be installed in a project via a [Git repo URL](https://docs.npmjs.com/cli/v9/using-npm/package-spec#git-urls); useful for testing forks or PR branches.

### Build scripts

To build the directories `components`, `constants`, and `utils`:

```sh
node --run build
```

To also watch source files for changes and automatically rebuild:

```sh
node --run build-watch
```

### Storybook scripts

To build [Storybook](https://storybook.js.org) for production in the directory `storybook-static`:

```sh
node --run storybook-build
```

To build [Storybook](https://storybook.js.org) for development in the directory `node_modules/.cache` and serve it on a free port, watching source files for changes to automatically rebuild and serve:

```sh
node --run storybook-dev
```

Additional Storybook CLI command [`dev`](https://storybook.js.org/docs/react/api/cli-options#dev) options can be specified after appending `--`; e.g. to serve Storybook on port `3003`:

```sh
node --run storybook-dev -- -p 3003
```

### Check script

> [!IMPORTANT]
>
> Prior, run a build script (see [**_Build scripts_**](#build-scripts)).

> [!WARNING]
>
> This script uses [`node --run`](https://nodejs.org/docs/latest/api/cli.html#--run) which is not available in older Node.js versions.

To run all quality checks:

```sh
node --run check
```

### Prettier script

To check formatting with [Prettier](https://prettier.io):

```sh
node --run prettier
```

### ESLint script

To lint with [ESLint](https://eslint.org):

```sh
node --run eslint
```

### Type check script

To type check with [TypeScript](https://typescriptlang.org):

```sh
node --run type-check
```

### Find unused exports script

To find unused exports with [`find-unused-exports`](https://npm.im/find-unused-exports):

```sh
node --run find-unused-exports
```

### Test script

> [!IMPORTANT]
>
> Prior, run a build script (see [**_Build scripts_**](#build-scripts)).

To test:

```sh
node --run test
```

## Changelog

[Learn about the latest improvements](/changelog.md).
