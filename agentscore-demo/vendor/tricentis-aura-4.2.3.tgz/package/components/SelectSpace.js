import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import Box from "@mui/material/Box";
import Button, {} from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import Popover from "@mui/material/Popover";
import { styled } from "@mui/material/styles";
import Typography from "@mui/material/Typography";
import IconMaterialSymbolsError from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsError.mjs";
import IconMaterialSymbolsKeyboardArrowDown from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsKeyboardArrowDown.mjs";
import { useCallback, useEffect, useLayoutEffect, useRef, useState, } from "react";
import Tooltip from "./Tooltip.js";
/**
 * Used to display a list of spaces and switch between them.
 * @param props Props.
 * @returns React node.
 */
export default function SelectSpace({ value, options, onChange, sx, items, mainButtonProps, disabled, onClick, error, visibleItems = 8, showMoreText = "Show more", ...args }) {
    const containerRef = useRef(null);
    const mainButtonTextRef = useRef(null);
    const [selectedOption, setSelectedOption] = useState(value);
    const [menuOpened, setMenuOpened] = useState(false);
    const selectedOptionText = selectedOption?.name || "";
    useEffect(() => {
        setSelectedOption(value);
    }, [value]);
    const onMainButtonClick = useCallback(() => {
        setMenuOpened(!menuOpened);
    }, [menuOpened]);
    return (_jsxs(SelectContainer, { ...args, sx: sx, ref: containerRef, className: error ? "MuiSelectSpace-error" : "", children: [_jsxs(MainButton, { onClick: onMainButtonClick, endIcon: _jsx(ArrowDropDownIconContainer, { children: _jsx(IconMaterialSymbolsKeyboardArrowDown, {}) }), disabled: disabled, ...mainButtonProps, children: [_jsx(MainButtonText, { ref: mainButtonTextRef, children: selectedOptionText }), error ? (_jsx(Tooltip, { variant: "error", title: error, arrow: true, placement: "right", children: _jsx(IconMaterialSymbolsError, { color: "error" }) })) : null] }), _jsx(SelectSpaceMenu, { options: options, items: items, opened: menuOpened, onMenuOpened: setMenuOpened, onSelectOption: setSelectedOption, container: containerRef.current, onChange: onChange, onClick: onClick, visibleItems: visibleItems, showMoreText: showMoreText })] }));
}
/**
 * Button used by SelectSpace.
 * @param props Props.
 * @returns React node.
 */
function SelectSpaceButton({ onClick, item, autoFocus, }) {
    const onClickButton = useCallback(() => {
        onClick(item);
    }, [onClick, item]);
    return (_jsx(SpaceItemButton, { variant: "text", value: item.name, onClick: onClickButton, autoFocus: autoFocus, children: _jsx(Typography, { variant: "body2", noWrap: true, children: item.name }) }, item.id));
}
/**
 * Menu to display elements.
 * @param props Props.
 * @returns React node.
 */
function SelectSpaceMenu({ options, items, container, opened, onMenuOpened, onSelectOption, onChange, onClick, visibleItems, showMoreText, }) {
    const [width, setWidth] = useState("auto");
    const [expanded, setExpanded] = useState(false);
    const onCloseMenu = useCallback(() => {
        onMenuOpened(!opened);
    }, [opened, onMenuOpened]);
    const onClickMenuOption = useCallback((opt) => {
        onMenuOpened(!opened);
        onSelectOption(opt);
        onChange?.(opt);
    }, [opened, onChange, onMenuOpened, onSelectOption]);
    const onClickMenuItem = useCallback((item) => {
        onMenuOpened(!opened);
        onClick?.(item);
    }, [opened, onMenuOpened, onClick]);
    useLayoutEffect(() => {
        setWidth(container?.offsetWidth || "auto");
    }, [container]);
    return (_jsxs(Popover, { open: opened, anchorEl: container, onClose: onCloseMenu, sx: { "& .MuiPaper-root": { minWidth: 100, width } }, anchorOrigin: {
            vertical: "bottom",
            horizontal: "center",
        }, transformOrigin: {
            vertical: "top",
            horizontal: "center",
        }, children: [_jsxs(SpaceOptionsWrapper, { role: "menu", sx: { maxHeight: 36 * (visibleItems + 1) }, children: [options
                        .slice(0, expanded ? options.length : visibleItems)
                        .map((option, i) => (_jsx(SelectSpaceButton, { item: option, onClick: onClickMenuOption, autoFocus: i === 0 }, option.id))), !expanded && options.length > visibleItems ? (_jsx(ShowMoreButton, { onClick: () => {
                            setExpanded(true);
                        }, children: _jsx(Typography, { variant: "inherit", noWrap: true, children: showMoreText }) }, "show-more-button")) : null] }), items && items.length > 0 ? (_jsxs(_Fragment, { children: [_jsx(Divider, { tabIndex: -1 }, "menu-divider"), _jsx(SpaceOptionsWrapper, { role: "menu", children: items.map((item) => (_jsx(SelectSpaceButton, { item: item, onClick: onClickMenuItem }, item.id))) })] })) : null] }));
}
const SelectContainer = styled(Box)({
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
});
const ArrowDropDownIconContainer = styled("div")({
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
});
const MainButton = styled(Button)(({ theme }) => ({
    justifyContent: "space-between",
    alignItems: "center",
    background: theme.vars.palette.aura.backgroundDefault,
    color: theme.vars.palette.secondary.main,
    height: 32,
    width: "100%",
    textTransform: "none",
    paddingBlock: 4,
    paddingLeft: theme.spacing(1),
    paddingRight: theme.spacing(1),
    ...theme.typography.body2,
    "& > .MuiButton-endIcon": {
        color: theme.vars.palette.action.active,
    },
    "&:hover": {
        background: theme.vars.palette.action.hover,
        "& > .MuiButton-endIcon": {
            color: theme.vars.palette.secondary.main,
        },
    },
    "&:active, &:focus-visible": {
        background: theme.vars.palette.action.hover,
    },
    "&:disabled": {
        background: theme.vars.palette.action.disabledBackground,
        color: theme.vars.palette.action.disabled,
    },
    ".MuiSelector-error &": {
        outlineColor: theme.vars.palette.error.light,
        outlineStyle: "solid",
        outlineWidth: 1,
        outlineOffset: -1,
    },
}));
const MainButtonText = styled("span")(({ theme }) => ({
    ...theme.typography.body2,
    flexGrow: 1,
    textAlign: "left",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
}));
const SpaceOptionsWrapper = styled(Box)(({ theme }) => ({
    overflow: "auto",
    display: "flex",
    alignItems: "flex-start",
    flexDirection: "column",
    paddingBlock: theme.spacing(1),
    "& > .MuiButtonBase-root": {
        width: "100%",
        borderRadius: 0,
    },
    "& > .MuiButtonBase-root p": {
        width: "100%",
        textAlign: "left",
    },
}));
const SpaceItemButton = styled(Button)(({ theme }) => ({
    textTransform: "none",
    color: theme.vars.palette.text.primary,
    "&:hover": {
        background: theme.vars.palette.action.hover,
    },
    ...theme.typography.body2,
    paddingInline: theme.spacing(2),
}));
const ShowMoreButton = styled(Button)(({ theme }) => ({
    textTransform: "none",
    color: theme.vars.palette.primary.main,
    ...theme.typography.body2,
    paddingInline: theme.spacing(2),
}));
//# sourceMappingURL=SelectSpace.js.map