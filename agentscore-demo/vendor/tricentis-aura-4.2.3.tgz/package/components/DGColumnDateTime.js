import { jsx as _jsx } from "react/jsx-runtime";
import { styled } from "@mui/material/styles";
/**
 * React component for rendering a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) cell that has
 * a datetime value, with a consistent format in the HTML element
 * [`time`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/time). A
 * falsy cell value causes the cell to render empty. For use with the grid
 * column definition option
 * [`renderCell`](https://mui.com/x/api/data-grid/grid-col-def/#properties).
 *
 * - [Usage guidelines](https://tricentisgmbh.sharepoint.com/:w:/r/sites/Technology/UX/Design%20System/Guidelines%20%26%20Patterns/Component%20Usage%20Guidelines/Date%20and%20Time%20Format.docx?d=w051263084dba4a43b8d102ec3affb9bb&csf=1&web=1&e=jbWvbA)
 * @param props Props.
 * @returns React node.
 */
export default function DGColumnDateTime({ format = "YYYY-MM-DD HH:mm:ss", formatFunction, value, }) {
    if (!value)
        return null;
    let isoDate;
    try {
        isoDate = new Date(value).toISOString();
    }
    catch {
        isoDate = "Invalid Date";
    }
    return (_jsx(DGColumnDateTimeContainer, { dateTime: isoDate, children: formatFunction ? formatFunction(value, format) : String(value) }));
}
const DGColumnDateTimeContainer = styled("time")({
    fontFeatureSettings: "'tnum' on, 'lnum' on",
});
//# sourceMappingURL=DGColumnDateTime.js.map