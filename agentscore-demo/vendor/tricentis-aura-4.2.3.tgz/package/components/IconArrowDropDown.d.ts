/**
 * React component for an SVG icon of a triangle pointing bottom right.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsArrowDropDown` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowDropDown.mjs`.
 */
declare const IconArrowDropDown: import("@mui/material/OverridableComponent.js").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconArrowDropDown;
