import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of view list with an outlined style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsViewList` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsViewList.mjs`.
 */
const IconViewListOutlined = createSvgIcon(_jsx("path", { d: "M8.40786 19.2H20.502C20.587 19.2 20.665 19.1616 20.7359 19.0846C20.8067 19.0077 20.8421 18.9231 20.8421 18.8308V15.69H8.40786V19.2ZM3.15787 8.31002H6.75001V4.79998H3.49799C3.41296 4.79998 3.33501 4.83844 3.26414 4.91536C3.1933 4.9923 3.15787 5.07693 3.15787 5.16925V8.31002ZM3.15787 13.92H6.75001V10.11H3.15787V13.92ZM3.49799 19.2H6.75001V15.69H3.15787V18.8308C3.15787 18.9231 3.1933 19.0077 3.26414 19.0846C3.33501 19.1616 3.41296 19.2 3.49799 19.2ZM8.40786 13.92H20.8421V10.11H8.40786V13.92ZM8.40786 8.31002H20.8421V5.16925C20.8421 5.07693 20.8067 4.9923 20.7359 4.91536C20.665 4.83844 20.587 4.79998 20.502 4.79998H8.40786V8.31002ZM3.49799 21C2.93968 21 2.46711 20.79 2.08026 20.37C1.69342 19.95 1.5 19.4369 1.5 18.8308V5.16925C1.5 4.56309 1.69342 4.05 2.08026 3.63C2.46711 3.21 2.93968 3 3.49799 3H20.502C21.0603 3 21.5329 3.21 21.9197 3.63C22.3066 4.05 22.5 4.56309 22.5 5.16925V18.8308C22.5 19.4369 22.3066 19.95 21.9197 20.37C21.5329 20.79 21.0603 21 20.502 21H3.49799Z", fill: "currentColor" }), "IconViewListOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconViewListOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsViewList` instead.");
}
export default IconViewListOutlined;
//# sourceMappingURL=IconViewListOutlined.js.map