import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of an avatar with two dots on top of a bench
 * with an outlined style.
 */
const IconAgentTeamOutlined = createSvgIcon(_jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M5.394 5.798c.263.263.58.394.952.394s.69-.131.952-.394c.263-.263.394-.58.394-.952s-.131-.689-.394-.952a1.297 1.297 0 0 0-.952-.394c-.372 0-.689.131-.952.394S5 4.474 5 4.846s.131.69.394.952ZM9 7.671v.521h5.692v-.52c0-.49-.264-.89-.791-1.203C13.373 6.156 12.688 6 11.846 6c-.842 0-1.527.156-2.055.47C9.264 6.781 9 7.182 9 7.67Zm1.894-2.873c.263.263.58.394.952.394s.69-.131.952-.394c.263-.263.394-.58.394-.952s-.131-.689-.394-.952a1.297 1.297 0 0 0-.952-.394c-.372 0-.689.131-.952.394s-.394.58-.394.952.131.69.394.952Zm5.5 1c.263.263.58.394.952.394s.69-.131.952-.394c.263-.263.394-.58.394-.952s-.131-.689-.394-.952a1.297 1.297 0 0 0-.952-.394c-.372 0-.689.131-.952.394s-.394.58-.394.952.131.69.394.952ZM3 10.8h18v1.4h-3.3v2.3H19a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h1.3v-2.3H7.7v2.3H9a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h1.3v-2.3H3v-1.4Zm2 5.1h4a.6.6 0 0 1 .6.6v3a.6.6 0 0 1-.6.6H5a.6.6 0 0 1-.6-.6v-3a.6.6 0 0 1 .6-.6Zm10 0h4a.6.6 0 0 1 .6.6v3a.6.6 0 0 1-.6.6h-4a.6.6 0 0 1-.6-.6v-3a.6.6 0 0 1 .6-.6Z", fill: "currentColor" }), "IconAgentTeamOutlined");
export default IconAgentTeamOutlined;
//# sourceMappingURL=IconAgentTeamOutlined.js.map