/**
 * React component for an SVG icon of forward-pointing arrow.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsArrowForward` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowForward.mjs`.
 */
declare const IconArrowForwardOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconArrowForwardOutlined;
