import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of an arrow in a circular motion moving
 * backward with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsUndo` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsUndo.mjs`.
 */
const IconUndoOutlined = createSvgIcon(_jsx("path", { d: "M7.20193 18.5V17H14.3789C15.4224 17 16.3205 16.6554 17.0731 15.9663C17.8256 15.2772 18.2019 14.4262 18.2019 13.4134C18.2019 12.4006 17.8256 11.5513 17.0731 10.8654C16.3205 10.1795 15.4224 9.8365 14.3789 9.8365H7.35762L10.1403 12.6192L9.08652 13.673L4.5 9.08652L9.08652 4.5L10.1403 5.55383L7.35762 8.33655H14.3789C15.8417 8.33655 17.0945 8.82468 18.1375 9.80095C19.1804 10.7772 19.7019 11.9814 19.7019 13.4134C19.7019 14.8455 19.1804 16.0512 18.1375 17.0307C17.0945 18.0102 15.8417 18.5 14.3789 18.5H7.20193Z", fill: "currentColor" }), "IconUndoOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconUndoOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsUndo` instead.");
}
export default IconUndoOutlined;
//# sourceMappingURL=IconUndoOutlined.js.map