/**
 * React component for an SVG icon of an autorenew symbol with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAutorenew` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAutorenew.mjs`.
 */
declare const IconAutoRenewOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAutoRenewOutlined;
