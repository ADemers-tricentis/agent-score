import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of an arrow with a dot, using an outline
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsStep` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsStep.mjs`.
 */
const IconStepOutlined = createSvgIcon(_jsx("path", { d: "M18.8461 14.9519C18.0667 14.9519 17.4119 14.6852 16.8817 14.1519C16.3516 13.6186 16.0865 12.9622 16.0865 12.1827C16.0865 11.4032 16.3516 10.7468 16.8817 10.2135C17.4119 9.68013 18.0667 9.41348 18.8461 9.41348C19.6192 9.41348 20.2724 9.68013 20.8057 10.2135C21.3391 10.7468 21.6057 11.4032 21.6057 12.1827C21.6057 12.9622 21.3391 13.6186 20.8057 14.1519C20.2724 14.6852 19.6192 14.9519 18.8461 14.9519ZM9.16347 16.8557L8.10964 15.7962L10.9443 12.9327H2.38464V11.4327H10.9539L8.10964 8.56345L9.16347 7.5L13.8269 12.1827L9.16347 16.8557Z", fill: "currentColor" }), "IconStepOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconStepOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsStep` instead.");
}
export default IconStepOutlined;
//# sourceMappingURL=IconStepOutlined.js.map