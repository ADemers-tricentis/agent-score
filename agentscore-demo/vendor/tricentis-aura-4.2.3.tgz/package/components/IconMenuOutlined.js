import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a menu or navigation with an outlined
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsMenu` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsMenu.mjs`.
 */
const IconMenuOutlined = createSvgIcon(_jsx("path", { d: "M3.5 17.6346V16.1346H20.5V17.6346H3.5ZM3.5 12.7499V11.25H20.5V12.7499H3.5ZM3.5 7.86533V6.36536H20.5V7.86533H3.5Z", fill: "currentColor" }), "IconMenuOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconMenuOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsMenu` instead.");
}
export default IconMenuOutlined;
//# sourceMappingURL=IconMenuOutlined.js.map