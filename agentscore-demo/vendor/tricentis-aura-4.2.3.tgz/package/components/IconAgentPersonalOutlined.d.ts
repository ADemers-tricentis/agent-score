/**
 * React component for an SVG icon of an avatar in a square on top of a bench
 * with an outlined style.
 */
declare const IconAgentPersonalOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAgentPersonalOutlined;
