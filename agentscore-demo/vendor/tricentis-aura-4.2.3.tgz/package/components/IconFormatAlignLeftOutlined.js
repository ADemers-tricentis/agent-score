import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of left-aligned text or element with outlined
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFormatAlignLeft` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFormatAlignLeft.mjs`.
 */
const IconFormatAlignLeftOutlined = createSvgIcon(_jsx("path", { d: "M3.5 20.5V19H20.5V20.5H3.5ZM3.5 16.625V15.125H14.5V16.625H3.5ZM3.5 12.75V11.25H20.5V12.75H3.5ZM3.5 8.87498V7.375H14.5V8.87498H3.5ZM3.5 4.99998V3.5H20.5V4.99998H3.5Z", fill: "currentColor" }), "IconFormatAlignLeftOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconFormatAlignLeftOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFormatAlignLeft` instead.");
}
export default IconFormatAlignLeftOutlined;
//# sourceMappingURL=IconFormatAlignLeftOutlined.js.map