import { type BoxProps } from "@mui/material/Box";
import type { ReactNode } from "react";
/**
 * React component for drawer main content. Intended for use as a child of the
 * Aura React component `DrawerContainer`; it should be the only child that flex
 * grows, filling the available space between the top and bottom drawer
 * components.
 * @param props Props.
 * @returns React node.
 */
export default function DrawerContent(props: BoxProps & {
    /** Drawer main content. */
    children?: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
