/**
 * React component for an SVG icon of a calendar with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDateRange` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDateRange.mjs`.
 */
declare const IconCalendarOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCalendarOutlined;
