/**
 * React component for an SVG icon of five vertically stacked boxes.  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDensitySmall` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDensitySmall.mjs`.
 */
declare const IconDensityCompactOutlined: import("@mui/material/OverridableComponent.js").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDensityCompactOutlined;
