import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of an autorenew symbol with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAutorenew` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAutorenew.mjs`.
 */
const IconAutoRenewOutlined = createSvgIcon(_jsx("path", { d: "M5.16733 15.6269C4.86476 15.0641 4.63624 14.483 4.48176 13.8837C4.32727 13.2843 4.25003 12.6731 4.25003 12.05C4.25003 9.8872 5.00259 8.0465 6.50771 6.52792C8.01284 5.00933 9.84361 4.25004 12 4.25004H12.7808L10.9308 2.40002L11.9846 1.34619L15.6384 5.00002L11.9846 8.65384L10.9308 7.60002L12.7808 5.74999H12C10.2628 5.74999 8.78686 6.36153 7.57211 7.58462C6.35736 8.8077 5.74998 10.2962 5.74998 12.05C5.74998 12.4641 5.79517 12.8779 5.88556 13.2914C5.97594 13.7048 6.11151 14.1083 6.29228 14.5019L5.16733 15.6269ZM12.0154 22.6538L8.36158 19L12.0154 15.3462L13.0692 16.4L11.2192 18.25H12C13.7372 18.25 15.2132 17.6385 16.4279 16.4154C17.6427 15.1923 18.25 13.7039 18.25 11.95C18.25 11.5359 18.2048 11.1221 18.1145 10.7087C18.0241 10.2952 17.8885 9.89169 17.7077 9.49809L18.8327 8.37312C19.1352 8.93593 19.3638 9.51702 19.5183 10.1164C19.6727 10.7157 19.75 11.327 19.75 11.95C19.75 14.1128 18.9974 15.9535 17.4923 17.4721C15.9872 18.9907 14.1564 19.75 12 19.75H11.2192L13.0692 21.6L12.0154 22.6538Z", fill: "currentColor" }), "IconAutoRenewOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconAutoRenewOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsAutorenew` instead.");
}
export default IconAutoRenewOutlined;
//# sourceMappingURL=IconAutoRenewOutlined.js.map