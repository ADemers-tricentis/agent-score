import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a testcase container with
 * outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsSelect` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsSelect.mjs`.
 */
const IconSelectOutlined = createSvgIcon(_jsx("path", { d: "M5.6155 18.8845V20.5C5.17117 20.5 4.79083 20.3418 4.4745 20.0255C4.15817 19.7092 4 19.3288 4 18.8845H5.6155ZM4 16.6538V15.0385H5.6155V16.6538H4ZM4 12.8077V11.1923H5.6155V12.8077H4ZM4 8.9615V7.34625H5.6155V8.9615H4ZM5.6155 5.1155H4C4 4.67117 4.15817 4.29083 4.4745 3.9745C4.79083 3.65817 5.17117 3.5 5.6155 3.5V5.1155ZM7.84625 20.5V18.8845H9.4615V20.5H7.84625ZM7.84625 5.1155V3.5H9.4615V5.1155H7.84625ZM11.6923 20.5V18.8845H13.3077V20.5H11.6923ZM11.6923 5.1155V3.5H13.3077V5.1155H11.6923ZM15.5385 20.5V18.8845H17.1538V20.5H15.5385ZM15.5385 5.1155V3.5H17.1538V5.1155H15.5385ZM19.3845 18.8845H21C21 19.3288 20.8418 19.7092 20.5255 20.0255C20.2092 20.3418 19.8288 20.5 19.3845 20.5V18.8845ZM19.3845 16.6538V15.0385H21V16.6538H19.3845ZM19.3845 12.8077V11.1923H21V12.8077H19.3845ZM19.3845 8.9615V7.34625H21V8.9615H19.3845ZM19.3845 5.1155V3.5C19.8288 3.5 20.2092 3.65817 20.5255 3.9745C20.8418 4.29083 21 4.67117 21 5.1155H19.3845Z", fill: "currentColor" }), "IconSelectOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconSelectOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsSelect` instead.");
}
export default IconSelectOutlined;
//# sourceMappingURL=IconSelectOutlined.js.map