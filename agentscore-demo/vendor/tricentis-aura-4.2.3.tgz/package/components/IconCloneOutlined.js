import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a custom-built clone, playlist symbol
 * with outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFileCopy` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFileCopy.mjs`.
 */
const IconCloneOutlined = createSvgIcon(_jsxs(_Fragment, { children: [_jsx("path", { d: "M19.1923 22.5H8.8077C8.30257 22.5 7.875 22.325 7.525 21.975C7.175 21.625 7 21.1974 7 20.6923V7.30775C7 6.80262 7.175 6.37505 7.525 6.02505C7.875 5.67505 8.30257 5.50005 8.8077 5.50005H15.75L21 10.75V20.6923C21 21.1974 20.825 21.625 20.475 21.975C20.125 22.325 19.6974 22.5 19.1923 22.5ZM15 11.5V7.00002H8.8077C8.73077 7.00002 8.66024 7.03207 8.59613 7.09617C8.53203 7.16029 8.49997 7.23082 8.49997 7.30775V20.6923C8.49997 20.7692 8.53203 20.8398 8.59613 20.9039C8.66024 20.968 8.73077 21 8.8077 21H19.1923C19.2692 21 19.3397 20.968 19.4038 20.9039C19.4679 20.8398 19.5 20.7692 19.5 20.6923V11.5H15Z", fill: "currentColor" }), _jsx("path", { d: "M4.8077 1.5C4.30257 1.5 3.875 1.675 3.525 2.025C3.175 2.375 3 2.80257 3 3.3077V16.5H4.49998V3.3077C4.49998 3.23077 4.53202 3.16024 4.59612 3.09612C4.66024 3.03202 4.73077 2.99998 4.8077 2.99998H15V1.50002L4.8077 1.5Z", fill: "currentColor" })] }), "IconCloneOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconCloneOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFileCopy` instead.");
}
export default IconCloneOutlined;
//# sourceMappingURL=IconCloneOutlined.js.map