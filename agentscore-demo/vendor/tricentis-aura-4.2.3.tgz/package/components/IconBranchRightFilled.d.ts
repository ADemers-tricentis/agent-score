/**
 * React component for an SVG icon of an arrow pointing down and turning to
 * the right.
 */
declare const IconBranchRightFilled: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconBranchRightFilled;
