import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a flash on or activated state with an
 * outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFlashOn` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFlashOn.mjs`.
 */
const IconFlashOnOutlined = createSvgIcon(_jsx("path", { d: "M10.9279 16.1386L14.5318 10.9327H11.4414L13.2779 4.53855H8.12021V12.5386H10.9279V16.1386ZM9.42791 20.9615V14.0385H6.62024V3.03857H15.2644L13.4279 9.43278H17.3798L9.42791 20.9615Z", fill: "currentColor" }), "IconFlashOnOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconFlashOnOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFlashOn` instead.");
}
export default IconFlashOnOutlined;
//# sourceMappingURL=IconFlashOnOutlined.js.map