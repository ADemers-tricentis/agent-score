/**
 * React component for an SVG icon of a vertical ellipsis with an outlined
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsMoreVert` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsMoreVert.mjs`.
 */
declare const IconEllipsisVertical: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconEllipsisVertical;
