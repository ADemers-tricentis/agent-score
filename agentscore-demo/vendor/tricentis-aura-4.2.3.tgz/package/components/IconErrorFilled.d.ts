/**
 * React component for an SVG icon of a exclamation mark (!) centered in a cirle
 * with a filled style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsError` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsError.mjs`.
 */
declare const IconErrorFilled: import("@mui/material/OverridableComponent.js").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconErrorFilled;
