/**
 * React component for an SVG icon of a custom Tosca business parameter
 * container symbol used in Tosca Cloud with an outlined style.
 */
declare const IconBusinessParameterContainerOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconBusinessParameterContainerOutlined;
