/**
 * React component for an SVG icon of four squares nested in another square
 * like a dice representing a custom-built API simulation, components, data
 * grid cell or header with outlined style.
 */
declare const IconComponentsOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconComponentsOutlined;
