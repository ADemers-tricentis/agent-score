/** React component for an SVG icon of a paper with a table and a cog. */
declare const IconFileTableAdvancedOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconFileTableAdvancedOutlined;
