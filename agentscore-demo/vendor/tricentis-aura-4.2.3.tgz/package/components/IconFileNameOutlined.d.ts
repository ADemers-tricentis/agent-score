/**
 * React component for an SVG icon of a custom-built filename symbol with an
 * outlined style.
 */
declare const IconFileNameOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconFileNameOutlined;
