import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { styled } from "@mui/material/styles";
/**
 * React component for the Tricentis Testim product mark.
 * @param props Props.
 * @returns React node.
 */
export default function ProductMarkTestim({ sx, }) {
    return (_jsxs(Svg, { viewBox: "0 0 24 24", className: "ProductMarkTestim", "data-testid": "ProductMarkTestim", sx: sx, children: [_jsx("path", { className: "ProductMarkTestim-background", d: "M0 4a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v16a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4Z" }), _jsx("path", { className: "ProductMarkTestim-text", d: "M14.815 16.64c-.986 0-1.798-.314-2.435-.943-.63-.63-.944-1.428-.944-2.397 0-.952.319-1.743.956-2.372.646-.629 1.454-.943 2.423-.943.467 0 .905.08 1.313.242a3.23 3.23 0 0 1 1.097.701c.323.306.573.701.752 1.186.178.484.26 1.033.242 1.645H13.31c.034.348.187.641.46.88.271.229.654.344 1.147.344.28 0 .535-.056.765-.166.23-.119.382-.264.459-.434h2.014c-.204.672-.612 1.216-1.224 1.633-.612.416-1.317.624-2.116.624Zm-.051-5.125c-.366 0-.672.093-.918.28-.238.187-.4.434-.485.74h2.729c-.094-.349-.268-.604-.523-.765a1.386 1.386 0 0 0-.803-.255ZM7.59 16.5V9.386H5.282V7.448h6.681v1.938H9.63V16.5H7.59Z" })] }));
}
const Svg = styled("svg")(({ theme }) => ({
    "&.ProductMarkTestim": {
        "& .ProductMarkTestim-background": {
            fill: theme.vars.palette.aura.brand,
        },
        "& .ProductMarkTestim-text": {
            fill: theme.vars.palette.aura.brandInverted,
        },
    },
}));
//# sourceMappingURL=ProductMarkTestim.js.map