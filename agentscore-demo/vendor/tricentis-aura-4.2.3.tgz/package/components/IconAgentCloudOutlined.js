import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of a cloud on top of a bench with an outlined
 * style.
 */
const IconAgentCloudOutlined = createSvgIcon(_jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M6.835 9.343a2.77 2.77 0 0 0 2.025.828h6.802c.698 0 1.291-.245 1.78-.733a2.423 2.423 0 0 0 .733-1.78 2.44 2.44 0 0 0-.66-1.71 2.428 2.428 0 0 0-1.63-.802 3.77 3.77 0 0 0-1.286-2.347 3.686 3.686 0 0 0-2.512-.949c-.847 0-1.597.244-2.25.732a3.647 3.647 0 0 0-1.336 1.914 2.544 2.544 0 0 0-1.785.907A2.852 2.852 0 0 0 6 7.333c0 .789.278 1.459.835 2.01Zm8.804-.5H8.86c-.426 0-.788-.149-1.086-.447a1.479 1.479 0 0 1-.447-1.086c0-.408.136-.759.407-1.052.27-.294.61-.454 1.018-.48l.782-.042.19-.663a2.61 2.61 0 0 1 .879-1.367 2.283 2.283 0 0 1 1.484-.529c.646 0 1.205.217 1.68.65.474.434.742.969.806 1.605l.08.995h.986c.33 0 .615.119.852.356.238.238.357.522.357.852 0 .33-.12.615-.357.852a1.163 1.163 0 0 1-.852.356ZM3 11.45h18v1.4h-3.3v2.3H19a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h1.3v-2.3H7.7v2.3H9a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h1.3v-2.3H3v-1.4Zm2 5.1h4a.6.6 0 0 1 .6.6v3a.6.6 0 0 1-.6.6H5a.6.6 0 0 1-.6-.6v-3a.6.6 0 0 1 .6-.6Zm10 0h4a.6.6 0 0 1 .6.6v3a.6.6 0 0 1-.6.6h-4a.6.6 0 0 1-.6-.6v-3a.6.6 0 0 1 .6-.6Z", fill: "currentColor" }), "IconAgentCloudOutlined");
export default IconAgentCloudOutlined;
//# sourceMappingURL=IconAgentCloudOutlined.js.map