import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of exiting fullscreen with an outlined
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFullscreenExit` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFullscreenExit.mjs`.
 */
const IconFullScreenExitOutlined = createSvgIcon(_jsx("path", { d: "M6.70681 20.5V17.2884H3.49524V15.7884H8.20676V20.5H6.70681ZM15.7933 20.5V15.7884H20.5048V17.2884H17.2932V20.5H15.7933ZM3.49524 8.21153V6.71158H6.70681V3.5H8.20676V8.21153H3.49524ZM15.7933 8.21153V3.5H17.2932V6.71158H20.5048V8.21153H15.7933Z", fill: "currentColor" }), "IconFullScreenExitOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconFullScreenExitOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFullscreenExit` instead.");
}
export default IconFullScreenExitOutlined;
//# sourceMappingURL=IconFullScreenExitOutlined.js.map