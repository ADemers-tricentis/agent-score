import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a stopwatch with some part of it filled.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsClockLoader40` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsClockLoader40.mjs`.
 */
const IconProgressOutlined = createSvgIcon(_jsx("path", { d: "M12.0017 21.5C10.6877 21.5 9.45271 21.2506 8.29658 20.752C7.14043 20.2533 6.13475 19.5765 5.27953 18.7217C4.4243 17.8669 3.74724 16.8616 3.24836 15.706C2.74947 14.5504 2.50003 13.3156 2.50003 12.0017C2.50003 10.6877 2.74936 9.45268 3.24803 8.29655C3.7467 7.1404 4.42345 6.13472 5.27828 5.2795C6.13313 4.42427 7.13837 3.74721 8.29401 3.24833C9.44962 2.74944 10.6844 2.5 11.9983 2.5C13.3123 2.5 14.5473 2.74933 15.7034 3.248C16.8596 3.74667 17.8653 4.42342 18.7205 5.27825C19.5757 6.1331 20.2528 7.13834 20.7517 8.29398C21.2505 9.44959 21.5 10.6844 21.5 11.9983C21.5 13.3122 21.2506 14.5473 20.752 15.7034C20.2533 16.8596 19.5766 17.8652 18.7217 18.7205C17.8669 19.5757 16.8616 20.2527 15.706 20.7516C14.5504 21.2505 13.3156 21.5 12.0017 21.5ZM12 20C13.0667 20 14.0901 19.7984 15.0702 19.3952C16.0503 18.992 16.9154 18.4159 17.6654 17.667L12 12V3.99998C9.76667 3.99998 7.87501 4.77498 6.32501 6.32498C4.77501 7.87498 4.00001 9.76664 4.00001 12C4.00001 14.2333 4.77501 16.125 6.32501 17.675C7.87501 19.225 9.76667 20 12 20Z", fill: "currentColor" }), "IconProgressOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconProgressOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsClockLoader40` instead.");
}
export default IconProgressOutlined;
//# sourceMappingURL=IconProgressOutlined.js.map