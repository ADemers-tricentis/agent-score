/**
 * React component for an SVG icon of a trash or bin with three horizontally
 * stacked horizontal lines to its right in outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDeleteSweep` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDeleteSweep.mjs`.
 */
declare const IconDeleteSweepOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDeleteSweepOutlined;
