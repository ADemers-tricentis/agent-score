/**
 * React component for an SVG icon of a custom-built clone, playlist symbol
 * with outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFileCopy` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFileCopy.mjs`.
 */
declare const IconCloneOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCloneOutlined;
