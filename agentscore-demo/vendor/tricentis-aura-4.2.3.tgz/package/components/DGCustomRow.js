import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { GridRow, } from "@mui/x-data-grid-pro";
import { useCallback, useState } from "react";
import DGContextMenu from "./private/DGContextMenu.js";
/**
 * React component for a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) row that has a
 * context menu.
 * @param props Props.
 * @returns React node.
 */
export default function DGCustomRow({ contextMenu, onRightClickSelectedRow, ...props }) {
    const [contextMenuCoord, setContextMenuCoord] = useState(null);
    const onContextMenu = useCallback((event) => {
        event.preventDefault();
        onRightClickSelectedRow?.(props.row);
        setContextMenuCoord(contextMenuCoord === null
            ? {
                mouseX: event.clientX - 2,
                mouseY: event.clientY - 4,
            }
            : null);
    }, [contextMenuCoord, onRightClickSelectedRow, props.row]);
    const handleClose = useCallback(() => {
        setContextMenuCoord(null);
    }, []);
    const handleClick = useCallback((callback) => {
        callback(props.row);
        handleClose();
    }, [handleClose, props.row]);
    return (_jsxs(_Fragment, { children: [_jsx(GridRow, { onContextMenu: onContextMenu, ...props }), contextMenu && contextMenuCoord && (_jsx(DGContextMenu, { contextMenu: contextMenu, contextMenuCoord: contextMenuCoord, handleClick: handleClick, handleClose: handleClose }))] }));
}
//# sourceMappingURL=DGCustomRow.js.map