import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a plug pointing upwards crossed by a
 * single line.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsPowerOff` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsPowerOff.mjs`.
 */
const IconPowerPlugOffOutlined = createSvgIcon(_jsx("path", { d: "M10.7526 18.6957V16.2861L7.87382 13.4074V9.1426C7.87382 8.85828 7.9378 8.58817 8.06574 8.33229C8.19368 8.0764 8.3856 7.87738 8.64148 7.73522L9.83562 8.92936H9.32385C9.2812 8.92936 9.24197 8.95068 9.20614 8.99333C9.17089 9.03598 9.15326 9.08573 9.15326 9.1426V12.853L12.032 15.7317V17.4163H13.0982V15.7317L13.9725 14.8574L3.69434 4.6006L4.61127 3.705L20.3057 19.3994L19.3887 20.295L14.8894 15.7743L14.3776 16.2861V18.6957H10.7526ZM16.7019 13.3861L15.9769 12.661V9.1426C15.9769 9.08573 15.9485 9.02887 15.8916 8.97201C15.8347 8.91514 15.7779 8.88671 15.721 8.88671H12.2026L9.729 6.41314V4.19545H11.0084V7.60727H14.1217V4.19545H15.4012V8.24699L14.7614 7.60727H15.721C16.1475 7.60727 16.51 7.75654 16.8085 8.05508C17.1071 8.35361 17.2563 8.71612 17.2563 9.1426V12.853L16.7019 13.3861Z", fill: "currentColor" }), "IconPowerPlugOffOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconPowerPlugOffOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsPowerOff` instead.");
}
export default IconPowerPlugOffOutlined;
//# sourceMappingURL=IconPowerPlugOffOutlined.js.map