/**
 * React component for an SVG icon of a checkbox in an indeterminate
 * state with filled style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsIndeterminateCheckBox` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsIndeterminateCheckBox.mjs`.
 */
declare const IconCheckBoxIndeterminateFilled: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCheckBoxIndeterminateFilled;
