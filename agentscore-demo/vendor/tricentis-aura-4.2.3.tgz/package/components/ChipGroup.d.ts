import type { ChipProps } from "@mui/material/Chip";
import type { SxProps, Theme } from "@mui/material/styles";
import { type ReactNode } from "react";
/**
 * React component for grouping chips within a container thats dimensions are
 * observed to replace overflowing chips with a plus button that opens a menu
 * containing the hidden chips.
 * @param props Props.
 * @returns React node.
 */
export default function ChipGroup({ children, chips, multiline, plusSx, sx, }: {
    /** Content to display after the chips. */
    children?: ReactNode;
    /**
     * List of [Material UI](https://mui.com/material-ui) component
     * [`Chip`](https://mui.com/material-ui/api/chip) props for the grouped chips.
     */
    chips: Array<ChipProps>;
    /**
     * Should chips that overflow the container width wrap onto multiple lines
     * that fit within the container height.
     */
    multiline?: boolean;
    /**
     * [Material UI theme aware custom styles](https://mui.com/system/getting-started/the-sx-prop)
     * for the [Material UI](https://mui.com/material-ui) component
     * [`Chip`](https://mui.com/material-ui/api/chip) plus button that opens the
     * hidden chips menu.
     */
    plusSx?: SxProps<Theme>;
    /**
     * [Material UI theme aware custom styles](https://mui.com/system/getting-started/the-sx-prop)
     * for the [Material UI](https://mui.com/material-ui) component
     * [`Box`](https://mui.com/material-ui/api/box) container element.
     */
    sx?: SxProps<Theme>;
}): import("react/jsx-runtime").JSX.Element;
