/**
 * React component for an SVG icon of a checkmark in a circle with outline
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCheckCircle` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCheckCircle.mjs`.
 */
declare const IconCheckCircleOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCheckCircleOutlined;
