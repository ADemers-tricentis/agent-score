/**
 * React component for an SVG icon of a folder with an arrow pointing to the
 * right.
 */
declare const IconFileMoveRightOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconFileMoveRightOutlined;
