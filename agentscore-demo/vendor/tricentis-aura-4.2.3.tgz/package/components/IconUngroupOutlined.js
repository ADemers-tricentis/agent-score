import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of an ungroup symbol with outline style.
 */
const IconUngroupOutlined = createSvgIcon(_jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M1 1H4V4H1V1ZM17 1V4H14V1H17ZM1 14V17H4L4 14H1ZM2.59998 5.00012V13.0001H3.99998V5.00012H2.59998ZM5 4.0001V2.6001H13V4.0001H5ZM14 5.00012V7.50012H15.4V5.00012H14ZM7.5 15.4001V14.0001H5L5 15.4001H7.5ZM10 7H7V10H10V7ZM23 7V10H20V7H23ZM20 23H23V20H20V23ZM8.59998 11V19H9.99998V11H8.59998ZM11 9.99998V8.59998H19V9.99998H11ZM20 11V19H21.4V11H20ZM19 21.4V20H11V21.4H19ZM7 20L7 23H10V20H7Z", fill: "currentColor" }), "IconUngroupOutlined");
export default IconUngroupOutlined;
//# sourceMappingURL=IconUngroupOutlined.js.map