import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { styled } from "@mui/material/styles";
/**
 * React component for the Tricentis Tosca product mark.
 * @param props Props.
 * @returns React node.
 */
export default function ProductMarkTosca({ sx, }) {
    return (_jsxs(Svg, { viewBox: "0 0 24 24", className: "ProductMarkTosca", "data-testid": "ProductMarkTosca", sx: sx, children: [_jsx("path", { className: "ProductMarkTosca-background", d: "M0 4a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v16a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4Z" }), _jsx("path", { className: "ProductMarkTosca-text", d: "M17.198 15.684c-.655.638-1.445.956-2.372.956-.926 0-1.717-.319-2.371-.956-.655-.646-.982-1.436-.982-2.371 0-.936.327-1.722.982-2.36a3.253 3.253 0 0 1 2.371-.968c.927 0 1.717.323 2.372.969.654.637.982 1.423.982 2.358 0 .936-.328 1.726-.982 2.372Zm-3.392-1.262c.272.28.612.42 1.02.42.408 0 .744-.14 1.008-.42.272-.28.408-.65.408-1.11 0-.458-.136-.828-.408-1.109-.264-.28-.6-.42-1.008-.42-.408 0-.748.14-1.02.42-.263.28-.395.65-.395 1.11 0 .458.132.828.395 1.109ZM7.64 16.5V9.386H5.332V7.448h6.681v1.938H9.68V16.5H7.64Z" })] }));
}
const Svg = styled("svg")(({ theme }) => ({
    "&.ProductMarkTosca": {
        "& .ProductMarkTosca-background": {
            fill: theme.vars.palette.aura.brand,
        },
        "& .ProductMarkTosca-text": {
            fill: theme.vars.palette.aura.brandInverted,
        },
    },
}));
//# sourceMappingURL=ProductMarkTosca.js.map