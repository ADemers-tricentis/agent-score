import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a strikethrough with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsStrikethrough` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsStrikethrough.mjs`.
 */
const IconStrikethroughOutlined = createSvgIcon(_jsx("path", { d: "M12.15 19.6924C10.9731 19.6924 9.93143 19.3591 9.02503 18.6924C8.11861 18.0257 7.45515 17.1129 7.03465 15.954L8.63845 15.2636C8.91665 16.0444 9.35448 16.6867 9.95192 17.1905C10.5494 17.6944 11.2923 17.9463 12.1808 17.9463C12.9577 17.9463 13.6744 17.7508 14.3308 17.3597C14.9872 16.9687 15.3154 16.3488 15.3154 15.5001C15.3154 15.1232 15.2555 14.7969 15.1356 14.5213C15.0157 14.2456 14.8462 13.9886 14.627 13.7501H16.6769C16.7987 13.9706 16.8933 14.2257 16.9606 14.5155C17.0279 14.8052 17.0615 15.1334 17.0615 15.5001C17.0615 16.8373 16.5747 17.8703 15.601 18.5991C14.6272 19.328 13.4769 19.6924 12.15 19.6924ZM2.25 11.7501V10.2501H21.75V11.7501H2.25ZM12.05 4.19629C13.0474 4.19629 13.9122 4.42706 14.6442 4.88859C15.3763 5.35012 15.9673 6.05909 16.4173 7.01549L14.8231 7.73086C14.6218 7.26035 14.2978 6.84464 13.851 6.48374C13.4042 6.12284 12.8141 5.94239 12.0808 5.94239C11.2243 5.94239 10.5391 6.16227 10.025 6.60204C9.51086 7.04179 9.26407 7.59116 9.2846 8.25014H7.53848C7.50129 7.16424 7.89777 6.21712 8.7279 5.40879C9.55802 4.60046 10.6654 4.19629 12.05 4.19629Z", fill: "currentColor" }), "IconStrikethroughOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconStrikethroughOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsStrikethrough` instead.");
}
export default IconStrikethroughOutlined;
//# sourceMappingURL=IconStrikethroughOutlined.js.map