/**
 * React component for an SVG icon of a circle with a triangle at the
 * center representing a play cirlce with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsPlayCircle` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsPlayCircle.mjs`.
 */
declare const IconCirclePlayOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCirclePlayOutlined;
