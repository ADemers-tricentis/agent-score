/**
 * React component for an SVG icon used in Neoload that represents a
 * distribution constant with an outlined style.
 */
declare const IconDistributionConstantOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDistributionConstantOutlined;
