import { type IconButtonProps } from "@mui/material/IconButton";
/**
 * React component for a drawer close icon button. Renders a small secondary
 * `IconButton` with a close icon. The parent controls layout and positioning.
 * @param props Props.
 * @returns React node.
 */
export default function DrawerCloser({ onClose, ...props }: Omit<IconButtonProps, "onClick"> & {
    /** Callback invoked when the close icon button is clicked. */
    onClose?: IconButtonProps["onClick"];
}): import("react/jsx-runtime").JSX.Element;
