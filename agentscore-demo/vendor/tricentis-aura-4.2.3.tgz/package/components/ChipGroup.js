import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import Box from "@mui/material/Box";
import Chip from "@mui/material/Chip";
import Menu, {} from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import { styled } from "@mui/material/styles";
import { debounce } from "@mui/material/utils";
import { useCallback, useEffect, useMemo, useRef, useState, } from "react";
import isArray from "../utils/private/isArray.js";
/** Gap between chips, in pixels. */
const CHIPS_GAP = 8;
// TODO: Refactor to reduce complexity and fix bugs.
/**
 * React component for grouping chips within a container thats dimensions are
 * observed to replace overflowing chips with a plus button that opens a menu
 * containing the hidden chips.
 * @param props Props.
 * @returns React node.
 */
export default function ChipGroup({ children, chips, multiline, plusSx, sx = [], }) {
    const [chipsVisibleCount, setChipsVisibleCount] = useState(0);
    const [menuOpen, setMenuOpen] = useState(false);
    const containerElementRef = useRef(null);
    const plusChipRef = useRef(null);
    const chipsRefs = useRef([]);
    /** Updates the state for how many chips are visible. */
    const updateChipsVisibleCount = useCallback(() => {
        const containerElement = containerElementRef.current;
        if (containerElement) {
            const chipElements = chipsRefs.current;
            const chipPlusWidth = plusChipRef.current?.offsetWidth ??
                // Fallback assumed width.
                40;
            let chipsVisibleCount = 0;
            if (chipElements.length) {
                let availableWidth = containerElement.offsetWidth - chipPlusWidth;
                let availableHeight = 0;
                // TODO: Fix a bug where if the prop `multiline` is false and the
                // container has a height large enough to fit multiple lines of chips,
                // the chips can horizontally overflow the container without the correct
                // number of chips being hidden in the menu.
                for (const [index, chip] of chipElements.entries()) {
                    if (!chip)
                        continue;
                    const { width: chipWidth, height: chipHeight } = chip.getBoundingClientRect();
                    if (index === 0)
                        availableHeight = containerElement.offsetHeight - chipHeight;
                    if (availableWidth >= chipWidth + CHIPS_GAP) {
                        availableWidth -= chipWidth + CHIPS_GAP;
                        chipsVisibleCount++;
                    }
                    else if (availableHeight >= chipHeight &&
                        availableHeight >= chipPlusWidth) {
                        availableWidth =
                            containerElement.offsetWidth -
                                chipPlusWidth -
                                (chipWidth + CHIPS_GAP);
                        if (availableWidth < chipPlusWidth)
                            break;
                        availableHeight -= chipHeight + CHIPS_GAP;
                        chipsVisibleCount++;
                    }
                    else
                        break;
                }
            }
            setChipsVisibleCount(chipsVisibleCount);
        }
    }, []);
    const onClickPlusChip = useCallback((event) => {
        event.stopPropagation();
        setMenuOpen(true);
    }, []);
    const onCloseMenu = useCallback(() => {
        setMenuOpen(false);
    }, []);
    /** List of component `Chip` props for the visible chips. */
    const chipsVisible = useMemo(() => chips.slice(0, chipsVisibleCount), [chips, chipsVisibleCount]);
    /** List of component `Chip` props for the hidden chips. */
    const chipsHidden = useMemo(() => chips.slice(chipsVisibleCount), [chips, chipsVisibleCount]);
    useEffect(() => {
        const onResize = debounce(() => {
            updateChipsVisibleCount();
        }, 200);
        const resizeObserver = new ResizeObserver(onResize);
        resizeObserver.observe(
        // Because the effect callback runs after the initial mount render, the
        // container element ref is populated.
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        containerElementRef.current);
        return () => {
            onResize.clear();
            resizeObserver.disconnect();
        };
    }, [chips, updateChipsVisibleCount]);
    return (_jsxs(Box, { ref: containerElementRef, sx: [
            {
                width: 1,
                display: "flex",
                maxWidth: "100%",
                maxHeight: "100%",
                height: "100%",
                alignContent: "start",
                overflow: "hidden",
                position: "relative",
                alignItems: "center",
                boxSizing: "border-box",
                flex: "1 1 100%",
            },
            ...(isArray(sx) ? sx : [sx]),
        ], children: [_jsxs(ContainerVisible, { multiline: multiline, children: [chipsVisible.map((chipProps, index) => (_jsx(Chip, { size: "small", "data-chip-visible": true, ...chipProps }, index))), !!chipsHidden.length && (_jsxs(_Fragment, { children: [_jsx(Chip, { ref: plusChipRef, size: "small", label: `+${chipsHidden.length}`, onClick: onClickPlusChip, "data-chip-plus": true, sx: plusSx }), _jsx(Menu, { open: menuOpen, anchorEl: plusChipRef.current, onClose: onCloseMenu, children: chipsHidden.map((chipProps, index) => (_jsx(MenuItem, { disableRipple: true, children: _jsx(Chip, { size: "small", ...chipProps }) }, index))) })] }))] }), _jsx(ContainerHidden, { multiline: multiline, "aria-hidden": true, children: chips.map((chipProps, index) => (_jsx(Chip, { size: "small", ...chipProps, ref: (element) => {
                        // TODO: Ensure the refs list has extra items cleared if the
                        // number of chips becomes less in subsequent renders.
                        if (element)
                            chipsRefs.current[index] = element;
                        else
                            chipsRefs.current[index] = undefined;
                    } }, index))) }), children] }));
}
const ContainerVisible = styled(Box, {
    shouldForwardProp: (prop) => prop !== "multiline",
})(({ multiline, theme }) => ({
    alignContent: "center",
    display: "flex",
    alignItems: "center",
    boxSizing: "border-box",
    gap: CHIPS_GAP,
    height: "100%",
    flexDirection: "row",
    paddingRight: theme.spacing(1.5),
    flexWrap: multiline ? "wrap" : "nowrap",
}));
const ContainerHidden = styled(ContainerVisible)({
    alignContent: "start",
    position: "absolute",
    visibility: "hidden",
    pointerEvents: "none",
    inset: 0,
});
//# sourceMappingURL=ChipGroup.js.map