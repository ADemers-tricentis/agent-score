import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of a Tosca Commander Combo box control
 * link control
 */
const IconComboBoxOutlined = createSvgIcon(_jsx("path", { d: "M5.81 20.5C5.3 20.5 4.88 20.32 4.53 19.97C4.18 19.62 4 19.19 4 18.69V5.31C4 4.8 4.18 4.38 4.53 4.03C4.88 3.68 5.31 3.5 5.81 3.5H19.19C19.7 3.5 20.12 3.68 20.47 4.03C20.82 4.38 21 4.81 21 5.31V18.69C21 19.2 20.82 19.62 20.47 19.97C20.12 20.32 19.69 20.5 19.19 20.5H5.81ZM5.81 19H19.19C19.27 19 19.34 18.97 19.4 18.9C19.46 18.84 19.5 18.77 19.5 18.69V5.31C19.5 5.23 19.47 5.16 19.4 5.1C19.34 5.04 19.27 5 19.19 5H5.81C5.73 5 5.66 5.03 5.6 5.1C5.54 5.16 5.5 5.23 5.5 5.31V18.69C5.5 18.77 5.53 18.84 5.6 18.9C5.66 18.96 5.73 19 5.81 19ZM12.5 11.7L8.1 7.3H16.9L12.5 11.7ZM8.1 14.2H16.9V12.7H8.1V14.2ZM8.1 16.7H16.9V15.2H8.1V16.7Z", fill: "currentColor" }), "IconComboBoxOutlined");
export default IconComboBoxOutlined;
//# sourceMappingURL=IconComboBoxOutlined.js.map