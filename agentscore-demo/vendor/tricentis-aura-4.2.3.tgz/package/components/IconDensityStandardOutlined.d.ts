/**
 * React component for an SVG icon of three vertically stacked boxes.  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDensityMedium` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDensityMedium.mjs`.
 */
declare const IconDensityStandardOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDensityStandardOutlined;
