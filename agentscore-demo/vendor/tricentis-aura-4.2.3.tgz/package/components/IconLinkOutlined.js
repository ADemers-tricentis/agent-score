import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a link or connection with an outlined
 * style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsLink` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsLink.mjs`.
 */
const IconLinkOutlined = createSvgIcon(_jsx("path", { d: "M10.8077 16.5385H7.03845C5.78282 16.5385 4.7125 16.0961 3.8275 15.2112C2.9425 14.3263 2.5 13.2561 2.5 12.0006C2.5 10.7452 2.9425 9.67479 3.8275 8.78954C4.7125 7.90429 5.78282 7.46167 7.03845 7.46167H10.8077V8.96162H7.03845C6.1987 8.96162 5.48235 9.2581 4.8894 9.85105C4.29645 10.444 3.99998 11.1603 3.99998 12.0001C3.99998 12.8398 4.29645 13.5562 4.8894 14.1491C5.48235 14.7421 6.1987 15.0386 7.03845 15.0386H10.8077V16.5385ZM8.25 12.7501V11.2501H15.75V12.7501H8.25ZM13.1923 16.5385V15.0386H16.9615C17.8013 15.0386 18.5176 14.7421 19.1106 14.1491C19.7035 13.5562 20 12.8398 20 12.0001C20 11.1603 19.7035 10.444 19.1106 9.85105C18.5176 9.2581 17.8013 8.96162 16.9615 8.96162H13.1923V7.46167H16.9615C18.2171 7.46167 19.2875 7.90411 20.1725 8.789C21.0575 9.67388 21.5 10.7441 21.5 11.9995C21.5 13.255 21.0575 14.3254 20.1725 15.2106C19.2875 16.0959 18.2171 16.5385 16.9615 16.5385H13.1923Z", fill: "currentColor" }), "IconLinkOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconLinkOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsLink` instead.");
}
export default IconLinkOutlined;
//# sourceMappingURL=IconLinkOutlined.js.map