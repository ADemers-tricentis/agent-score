import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a + (plus or addition) symbol with
 * outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAdd` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAdd.mjs`.
 */
const IconAddOutlined = createSvgIcon(_jsx("path", { d: "M11.25 12.75H5.50003V11.25H11.25V5.5H12.75V11.25H18.5V12.75H12.75V18.5H11.25V12.75Z", fill: "currentColor" }), "IconAddOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconAddOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsAdd` instead.");
}
export default IconAddOutlined;
//# sourceMappingURL=IconAddOutlined.js.map