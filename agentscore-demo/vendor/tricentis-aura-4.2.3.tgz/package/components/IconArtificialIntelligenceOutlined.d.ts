/**
 * React component for an SVG icon of artificial intelligence with outline
 * style.
 */
declare const IconArtificialIntelligenceOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconArtificialIntelligenceOutlined;
