import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of an open folder.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFolderOpen` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFolderOpen.mjs`.
 */
const IconFolderOpenOutlined = createSvgIcon(_jsx("path", { d: "M3.37982 20.3099C2.89392 20.3099 2.48078 20.1164 2.1404 19.7293C1.80001 19.3423 1.62982 18.8725 1.62982 18.3199V5.74557C1.62982 5.19304 1.80963 4.7123 2.16925 4.30336C2.52886 3.89441 2.95162 3.68994 3.43752 3.68994H9.51445L11.1298 5.52686H18.8221C19.2695 5.52686 19.6554 5.69124 19.9797 6.01999C20.3041 6.34875 20.4919 6.75294 20.5432 7.23258H10.5163L8.901 5.39566H3.43752C3.34777 5.39566 3.27405 5.42847 3.21635 5.49408C3.15865 5.55968 3.1298 5.6435 3.1298 5.74557V18.2543C3.1298 18.3345 3.14743 18.4001 3.1827 18.4511C3.21795 18.5022 3.26442 18.5459 3.32212 18.5824L5.7125 9.50691H22.3702L19.8913 18.8972C19.7772 19.3244 19.5634 19.6666 19.25 19.924C18.9365 20.1813 18.5888 20.3099 18.2067 20.3099H3.37982ZM4.89322 18.6042H18.399L20.3433 11.2126H6.83747L4.89322 18.6042Z", fill: "currentColor" }), "IconFolderOpenOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconFolderOpenOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFolderOpen` instead.");
}
export default IconFolderOpenOutlined;
//# sourceMappingURL=IconFolderOpenOutlined.js.map