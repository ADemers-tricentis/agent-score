import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { styled } from "@mui/material/styles";
/**
 * React component for the Tricentis qTest product mark.
 * @param props Props.
 * @returns React node.
 */
export default function ProductMarkQTest({ sx, }) {
    return (_jsxs(Svg, { viewBox: "0 0 24 24", className: "ProductMarkQTest", "data-testid": "ProductMarkQTest", sx: sx, children: [_jsx("path", { className: "ProductMarkQTest-background", d: "M0 4a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v16a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4Z" }), _jsx("path", { className: "ProductMarkQTest-text", d: "M14.408 16.5V9.386H12.1V7.448h6.68v1.938h-2.332V16.5h-2.04Zm-2.448 2.665h-1.926v-3.302c-.425.518-1.003.777-1.734.777-.825 0-1.526-.327-2.104-.982-.57-.654-.854-1.436-.854-2.345 0-.91.285-1.692.854-2.347.578-.654 1.28-.981 2.104-.981.73 0 1.309.259 1.734.777v-.637h1.925v9.04Zm-4.285-4.718c.272.298.625.447 1.058.447.434 0 .782-.15 1.046-.447.272-.297.408-.675.408-1.134 0-.46-.136-.838-.408-1.135-.264-.298-.612-.447-1.046-.447-.433 0-.786.15-1.058.447-.263.297-.395.675-.395 1.134 0 .46.132.838.395 1.135Z" })] }));
}
const Svg = styled("svg")(({ theme }) => ({
    "&.ProductMarkQTest": {
        "& .ProductMarkQTest-background": {
            fill: theme.vars.palette.aura.brand,
        },
        "& .ProductMarkQTest-text": {
            fill: theme.vars.palette.aura.brandInverted,
        },
    },
}));
//# sourceMappingURL=ProductMarkQTest.js.map