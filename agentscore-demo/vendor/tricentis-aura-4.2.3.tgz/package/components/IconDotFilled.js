import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of a small centered dot.  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCircle` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCircle.mjs`.
 */
const IconDotFilled = createSvgIcon(_jsx("path", { d: "M12 6C8.682 6 6 8.682 6 12C6 15.318 8.682 18 12 18C15.318 18 18 15.318 18 12C18 8.682 15.318 6 12 6Z", fill: "currentColor" }), "IconDotFilled");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconDotFilled` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsCircle` instead.");
}
export default IconDotFilled;
//# sourceMappingURL=IconDotFilled.js.map