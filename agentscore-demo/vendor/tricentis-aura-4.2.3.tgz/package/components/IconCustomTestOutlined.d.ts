/** React component for an SVG icon of custom test with an outlined style. */
declare const IconCustomTestOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCustomTestOutlined;
