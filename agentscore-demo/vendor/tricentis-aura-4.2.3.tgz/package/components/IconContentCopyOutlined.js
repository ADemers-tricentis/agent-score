import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a copy content symbol with outline style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsContentCopy` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsContentCopy.mjs`.
 */
const IconContentCopyOutlined = createSvgIcon(_jsx("path", { d: "M5.00311 2C4.44339 2 3.9696 2.19392 3.58176 2.58176C3.19392 2.9696 3 3.44338 3 4.00311L3 18.0675L4.66214 18.0675L4.66215 4.00311C4.66215 3.91788 4.69766 3.83974 4.76869 3.76869C4.83972 3.69766 4.91786 3.66214 5.00311 3.66214L15.7432 3.66215L15.7432 2L5.00311 2ZM8.88149 5.87837C8.32174 5.87837 7.84795 6.07229 7.46011 6.46013C7.07228 6.84797 6.87837 7.32176 6.87837 7.88148L6.87837 20.4969C6.87837 21.0566 7.07228 21.5304 7.4601 21.9182C7.84794 22.3061 8.32174 22.5 8.88148 22.5L18.1725 22.5C18.7323 22.5 19.2061 22.3061 19.5939 21.9182C19.9817 21.5304 20.1757 21.0566 20.1757 20.4969L20.1757 7.88149C20.1757 7.32176 19.9817 6.84797 19.5939 6.46014C19.2061 6.0723 18.7323 5.87837 18.1726 5.87837L8.88149 5.87837ZM8.88148 7.54049L18.1725 7.54049C18.2578 7.54049 18.3359 7.57602 18.407 7.64706C18.478 7.71809 18.5135 7.79623 18.5135 7.88148L18.5135 20.4969C18.5135 20.5821 18.478 20.6603 18.407 20.7313C18.3359 20.8023 18.2578 20.8379 18.1725 20.8379L8.88148 20.8379C8.79623 20.8379 8.71809 20.8023 8.64706 20.7313C8.57601 20.6603 8.54049 20.5821 8.54049 20.4969L8.54049 7.88148C8.54049 7.79623 8.57601 7.71809 8.64706 7.64706C8.71809 7.57601 8.79623 7.54049 8.88148 7.54049Z", fill: "currentColor" }), "IconContentCopyOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconContentCopyOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsContentCopy` instead.");
}
export default IconContentCopyOutlined;
//# sourceMappingURL=IconContentCopyOutlined.js.map