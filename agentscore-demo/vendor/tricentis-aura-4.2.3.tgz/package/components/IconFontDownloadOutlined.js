import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of letter A nested in a square with outline
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFontDownload` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFontDownload.mjs`.
 */
const IconFontDownloadOutlined = createSvgIcon(_jsx("path", { d: "M6.91925 17.7884H8.49998L9.58075 14.7577H14.4192L15.5 17.7884H17.0807L12.7423 6.09613H11.2577L6.91925 17.7884ZM10.0461 13.4115L11.95 8.03843H12.05L13.9538 13.4115H10.0461ZM4.3077 21.5C3.80257 21.5 3.375 21.325 3.025 20.975C2.675 20.625 2.5 20.1974 2.5 19.6923V4.3077C2.5 3.80257 2.675 3.375 3.025 3.025C3.375 2.675 3.80257 2.5 4.3077 2.5H19.6923C20.1974 2.5 20.625 2.675 20.975 3.025C21.325 3.375 21.5 3.80257 21.5 4.3077V19.6923C21.5 20.1974 21.325 20.625 20.975 20.975C20.625 21.325 20.1974 21.5 19.6923 21.5H4.3077ZM4.3077 20H19.6923C19.7692 20 19.8397 19.9679 19.9038 19.9038C19.9679 19.8397 20 19.7692 20 19.6923V4.3077C20 4.23077 19.9679 4.16024 19.9038 4.09613C19.8397 4.03203 19.7692 3.99998 19.6923 3.99998H4.3077C4.23077 3.99998 4.16024 4.03203 4.09613 4.09613C4.03202 4.16024 3.99998 4.23077 3.99998 4.3077V19.6923C3.99998 19.7692 4.03202 19.8397 4.09613 19.9038C4.16024 19.9679 4.23077 20 4.3077 20Z", fill: "currentColor" }), "IconFontDownloadOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconFontDownloadOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFontDownload` instead.");
}
export default IconFontDownloadOutlined;
//# sourceMappingURL=IconFontDownloadOutlined.js.map