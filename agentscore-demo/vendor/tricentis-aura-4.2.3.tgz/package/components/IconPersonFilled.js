import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a person avatar with a filled style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsPerson` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsPerson.mjs`.
 */
const IconPersonFilled = createSvgIcon(_jsx("path", { d: "M12 11.6923C11.0346 11.6923 10.21 11.3503 9.52598 10.6664C8.84201 9.98239 8.50003 9.15773 8.50003 8.19236C8.50003 7.22698 8.84201 6.4023 9.52598 5.71833C10.21 5.03437 11.0346 4.69238 12 4.69238C12.9654 4.69238 13.79 5.03437 14.474 5.71833C15.158 6.4023 15.5 7.22698 15.5 8.19236C15.5 9.15773 15.158 9.98239 14.474 10.6664C13.79 11.3503 12.9654 11.6923 12 11.6923ZM4.50003 17.7885V17.0846C4.50003 16.5949 4.63305 16.1414 4.89908 15.7241C5.1651 15.3068 5.52054 14.986 5.96541 14.7616C6.95387 14.277 7.95099 13.9135 8.95676 13.6712C9.96252 13.4289 10.9769 13.3078 12 13.3078C13.0231 13.3078 14.0375 13.4289 15.0433 13.6712C16.049 13.9135 17.0461 14.277 18.0346 14.7616C18.4795 14.986 18.8349 15.3068 19.1009 15.7241C19.367 16.1414 19.5 16.5949 19.5 17.0846V17.7885C19.5 18.2103 19.3522 18.5689 19.0567 18.8644C18.7612 19.1599 18.4026 19.3077 17.9808 19.3077H6.01923C5.59745 19.3077 5.23881 19.1599 4.94331 18.8644C4.64779 18.5689 4.50003 18.2103 4.50003 17.7885Z", fill: "currentColor" }), "IconPersonFilled");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconPersonFilled` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsPerson` instead.");
}
export default IconPersonFilled;
//# sourceMappingURL=IconPersonFilled.js.map