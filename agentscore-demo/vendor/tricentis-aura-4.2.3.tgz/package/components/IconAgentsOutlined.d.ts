/** React component for an SVG icon of boxes linked with a horizontal line. */
declare const IconAgentsOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAgentsOutlined;
