/**
 * React component for an SVG icon of cog with a checkmark and an arrow bending
 * in a circle.
 */
declare const IconExecutionsOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconExecutionsOutlined;
