/**
 * React component for an SVG icon of right-pointing arrow head, greater than,
 * right, wast or right chevron with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsChevronRight` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsChevronRight.mjs`.
 */
declare const IconChevronRightOutlined: import("@mui/material/OverridableComponent.js").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconChevronRightOutlined;
