/**
 * React component for an SVG icon of a computer monitor with a box at the
 * right side bottom corner with an outlined style.
 */
declare const IconAPICaptureOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAPICaptureOutlined;
