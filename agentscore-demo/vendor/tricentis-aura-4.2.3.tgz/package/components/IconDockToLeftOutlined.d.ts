/**
 * React component for an SVG icon of two uneven rectangles stacked horizontally
 * with an outlined style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDockToLeft` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDockToLeft.mjs`.
 */
declare const IconDockToLeftOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDockToLeftOutlined;
