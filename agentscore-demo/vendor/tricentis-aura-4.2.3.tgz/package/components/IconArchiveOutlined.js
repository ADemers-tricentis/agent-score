import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of archive, box, bin symbol
 * with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsInventory2` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsInventory2.mjs`.
 */
const IconArchiveOutlined = createSvgIcon(_jsx("path", { d: "M3.50003 20.1434V8.93301C3.23593 8.79739 3.00324 8.58738 2.80196 8.30298C2.60067 8.01858 2.50003 7.68611 2.50003 7.30558V4.85654C2.50003 4.33777 2.67503 3.89865 3.02503 3.53919C3.37503 3.17973 3.8026 3 4.30773 3H19.6923C20.1974 3 20.625 3.17973 20.975 3.53919C21.325 3.89865 21.5 4.33777 21.5 4.85654V7.30558C21.5 7.68611 21.3993 8.01858 21.1981 8.30298C20.9968 8.58738 20.7641 8.79739 20.5 8.93301V20.1434C20.5 20.6622 20.325 21.1013 19.975 21.4608C19.625 21.8203 19.1974 22 18.6923 22H5.30773C4.8026 22 4.37503 21.8203 4.02503 21.4608C3.67503 21.1013 3.50003 20.6622 3.50003 20.1434ZM5.00001 9.16212V20.1434C5.00001 20.2356 5.02886 20.3113 5.08656 20.3706C5.14426 20.4298 5.21798 20.4595 5.30773 20.4595H18.6923C18.782 20.4595 18.8558 20.4298 18.9135 20.3706C18.9712 20.3113 19 20.2356 19 20.1434V9.16212H5.00001ZM19.6923 7.62159C19.782 7.62159 19.8558 7.59197 19.9135 7.53273C19.9712 7.47347 20 7.39775 20 7.30558V4.85654C20 4.76436 19.9712 4.68865 19.9135 4.62939C19.8558 4.57013 19.782 4.5405 19.6923 4.5405H4.30773C4.21798 4.5405 4.14426 4.57013 4.08656 4.62939C4.02886 4.68865 4.00001 4.76436 4.00001 4.85654V7.30558C4.00001 7.39775 4.02886 7.47347 4.08656 7.53273C4.14426 7.59197 4.21798 7.62159 4.30773 7.62159H19.6923ZM9.19233 13.9812H14.8077V12.4407H9.19233V13.9812Z", fill: "currentColor" }), "IconArchiveOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconArchiveOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsInventory2` instead.");
}
export default IconArchiveOutlined;
//# sourceMappingURL=IconArchiveOutlined.js.map