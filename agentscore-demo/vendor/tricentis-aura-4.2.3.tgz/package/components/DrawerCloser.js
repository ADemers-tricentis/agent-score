import { jsx as _jsx } from "react/jsx-runtime";
import IconButton, {} from "@mui/material/IconButton";
import IconMaterialSymbolsClose from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsClose.mjs";
/**
 * React component for a drawer close icon button. Renders a small secondary
 * `IconButton` with a close icon. The parent controls layout and positioning.
 * @param props Props.
 * @returns React node.
 */
export default function DrawerCloser({ onClose, ...props }) {
    return (_jsx(IconButton, { color: "secondary", size: "small", "aria-label": "Close", onClick: onClose, ...props, children: _jsx(IconMaterialSymbolsClose, {}) }));
}
//# sourceMappingURL=DrawerCloser.js.map