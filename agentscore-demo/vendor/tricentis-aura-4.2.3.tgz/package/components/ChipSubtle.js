import { jsx as _jsx } from "react/jsx-runtime";
import Chip from "@mui/material/Chip";
import { forwardRef } from "react";
/**
 * React component for a customized Material UI component
 * [`Chip`](https://mui.com/material-ui/api/chip) based on the variant `outlined`.
 * Typically used to represent a status.
 * @param props Props.
 * @returns React node.
 */
const ChipSubtle = forwardRef(({ size = "small", ...props }, forwardedRef) => (_jsx(Chip, { ref: forwardedRef, ...props, size: size, variant: "outlined" })));
export default ChipSubtle;
//# sourceMappingURL=ChipSubtle.js.map