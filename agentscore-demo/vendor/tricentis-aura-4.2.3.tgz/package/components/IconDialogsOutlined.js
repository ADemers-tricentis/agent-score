import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a Tosca Commander Cell control  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDialogs` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDialogs.mjs`.
 */
const IconDialogsOutlined = createSvgIcon(_jsx("path", { d: "M9 15.5H16V8.5H9V15.5ZM5.8077 20.5C5.30257 20.5 4.875 20.325 4.525 19.975C4.175 19.625 4 19.1974 4 18.6923V5.3077C4 4.80257 4.175 4.375 4.525 4.025C4.875 3.675 5.30257 3.5 5.8077 3.5H19.1923C19.6974 3.5 20.125 3.675 20.475 4.025C20.825 4.375 21 4.80257 21 5.3077V18.6923C21 19.1974 20.825 19.625 20.475 19.975C20.125 20.325 19.6974 20.5 19.1923 20.5H5.8077ZM5.8077 19H19.1923C19.2692 19 19.3397 18.9679 19.4038 18.9038C19.4679 18.8397 19.5 18.7692 19.5 18.6923V5.3077C19.5 5.23077 19.4679 5.16024 19.4038 5.09613C19.3397 5.03203 19.2692 4.99998 19.1923 4.99998H5.8077C5.73077 4.99998 5.66024 5.03203 5.59612 5.09613C5.53202 5.16024 5.49997 5.23077 5.49997 5.3077V18.6923C5.49997 18.7692 5.53202 18.8397 5.59612 18.9038C5.66024 18.9679 5.73077 19 5.8077 19Z", fill: "currentColor" }), "IconDialogsOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconDialogsOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsDialogs` instead.");
}
export default IconDialogsOutlined;
//# sourceMappingURL=IconDialogsOutlined.js.map