import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of a conversion path with outline style
 */
const IconConversionPathOutlined = createSvgIcon(_jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M18.25 18.25V21.5H16.75V18.25H13.5V16.75H16.75V13.5H18.25V16.75H21.5V18.25H18.25ZM9.5 16.75H11.5V18.25H9.5C7.42893 18.25 5.75 16.5711 5.75 14.5C5.75 12.4289 7.42893 10.75 9.5 10.75H14.5C15.7426 10.75 16.75 9.74264 16.75 8.5C16.75 7.25736 15.7426 6.25 14.5 6.25H7.81253C7.41249 7.27434 6.41599 8 5.25 8C3.73122 8 2.5 6.76878 2.5 5.25C2.5 3.73122 3.73122 2.5 5.25 2.5C6.59803 2.5 7.71953 3.46994 7.95466 4.75H14.5C16.5711 4.75 18.25 6.42893 18.25 8.5C18.25 10.5711 16.5711 12.25 14.5 12.25H9.5C8.25736 12.25 7.25 13.2574 7.25 14.5C7.25 15.7426 8.25736 16.75 9.5 16.75ZM6.5 5.25C6.5 5.94036 5.94036 6.5 5.25 6.5C4.55964 6.5 4 5.94036 4 5.25C4 4.55964 4.55964 4 5.25 4C5.94036 4 6.5 4.55964 6.5 5.25Z", fill: "currentColor" }), "IconConversionPathOutlined");
export default IconConversionPathOutlined;
//# sourceMappingURL=IconConversionPathOutlined.js.map