import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/** React component for an SVG icon of a chevron down up with outlined style. */
const IconChevronDownUpOutlined = createSvgIcon(_jsx("path", { d: "M8.90002 19.6538L7.84619 18.6L12 14.4462L16.1538 18.6L15.1 19.6538L12 16.5538L8.90002 19.6538ZM12 9.55384L7.84619 5.40002L8.90002 4.34619L12 7.44619L15.1 4.34619L16.1538 5.40002L12 9.55384Z", fill: "currentColor" }), "IconChevronDownUpOutlined");
export default IconChevronDownUpOutlined;
//# sourceMappingURL=IconChevronDownUpOutlined.js.map