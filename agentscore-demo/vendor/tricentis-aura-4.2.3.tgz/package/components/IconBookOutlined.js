import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a book with outline outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsBook` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsBook.mjs`.
 */
const IconBookOutlined = createSvgIcon(_jsx("path", { d: "M6.3077 21.5C5.80257 21.5 5.375 21.325 5.025 20.975C4.675 20.625 4.5 20.1974 4.5 19.6923V4.3077C4.5 3.80257 4.675 3.375 5.025 3.025C5.375 2.675 5.80257 2.5 6.3077 2.5H17.6922C18.1974 2.5 18.625 2.675 18.975 3.025C19.325 3.375 19.5 3.80257 19.5 4.3077V19.6923C19.5 20.1974 19.325 20.625 18.975 20.975C18.625 21.325 18.1974 21.5 17.6922 21.5H6.3077ZM6.3077 20H17.6922C17.7692 20 17.8397 19.9679 17.9038 19.9038C17.9679 19.8397 18 19.7692 18 19.6923V4.3077C18 4.23077 17.9679 4.16024 17.9038 4.09613C17.8397 4.03203 17.7692 3.99998 17.6922 3.99998H16V10.5576L13.75 9.2115L11.5 10.5576V3.99998H6.3077C6.23077 3.99998 6.16024 4.03203 6.09612 4.09613C6.03202 4.16024 5.99997 4.23077 5.99997 4.3077V19.6923C5.99997 19.7692 6.03202 19.8397 6.09612 19.9038C6.16024 19.9679 6.23077 20 6.3077 20Z", fill: "currentColor" }), "IconBookOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconBookOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsBook` instead.");
}
export default IconBookOutlined;
//# sourceMappingURL=IconBookOutlined.js.map