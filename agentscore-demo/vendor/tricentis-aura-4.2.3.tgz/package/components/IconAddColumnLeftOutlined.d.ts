/** React component for an SVG icon of adding a table column to the left. */
declare const IconAddColumnLeftOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAddColumnLeftOutlined;
