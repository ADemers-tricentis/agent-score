/**
 * React component for an SVG icon of a Tosca Commander Checkbox control
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCheckBox` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCheckBox.mjs`.
 */
declare const IconCheckboxOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCheckboxOutlined;
