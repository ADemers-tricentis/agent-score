import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a star with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsStar` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsStar.mjs`.
 */
const IconStarOutlined = createSvgIcon(_jsx("path", { d: "M22 9.74L14.81 9.12L12 2.5L9.19 9.13L2 9.74L7.46 14.47L5.82 21.5L12 17.77L18.18 21.5L16.55 14.47L22 9.74ZM12 15.9L8.24 18.17L9.24 13.89L5.92 11.01L10.3 10.63L12 6.6L13.71 10.64L18.09 11.02L14.77 13.9L15.77 18.18L12 15.9Z", fill: "currentColor" }), "IconStarOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconStarOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsStar` instead.");
}
export default IconStarOutlined;
//# sourceMappingURL=IconStarOutlined.js.map