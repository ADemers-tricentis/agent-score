import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { styled } from "@mui/material/styles";
/**
 * React component for the Tricentis Neoload product mark.
 * @param props Props.
 * @returns React node.
 */
export default function ProductMarkNeoload({ sx, }) {
    return (_jsxs(Svg, { viewBox: "0 0 24 24", className: "ProductMarkNeoload", "data-testid": "ProductMarkNeoload", sx: sx, children: [_jsx("path", { className: "ProductMarkNeoload-background", d: "M0 4a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v16a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4Z" }), _jsx("path", { className: "ProductMarkNeoload-text", d: "M14.488 16.5V7.448h2.027v7.114h3.748V16.5h-5.775Zm-1.913 0H10.83l-4.412-5.597V16.5H4.39V7.448h1.747l4.398 5.597V7.448h2.04V16.5Z" })] }));
}
const Svg = styled("svg")(({ theme }) => ({
    "&.ProductMarkNeoload": {
        "& .ProductMarkNeoload-background": {
            fill: theme.vars.palette.aura.brand,
        },
        "& .ProductMarkNeoload-text": {
            fill: theme.vars.palette.aura.brandInverted,
        },
    },
}));
//# sourceMappingURL=ProductMarkNeoload.js.map