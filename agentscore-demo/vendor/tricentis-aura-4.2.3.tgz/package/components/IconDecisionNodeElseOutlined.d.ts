/**
 * React component for an SVG icon of a custom Tosca ELSE symbol representing an
 * ELSE condition in the Tosca Cloud with outlined style.
 */
declare const IconDecisionNodeElseOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDecisionNodeElseOutlined;
