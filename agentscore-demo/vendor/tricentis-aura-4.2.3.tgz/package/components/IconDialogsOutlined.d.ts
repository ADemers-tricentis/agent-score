/**
 * React component for an SVG icon of a Tosca Commander Cell control  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDialogs` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDialogs.mjs`.
 */
declare const IconDialogsOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDialogsOutlined;
