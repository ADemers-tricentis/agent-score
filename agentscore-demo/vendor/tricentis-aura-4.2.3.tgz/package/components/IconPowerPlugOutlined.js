import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a plug pointing upwards.  *
 * @deprecated This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsPower` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsPower.mjs`.
 */
const IconPowerPlugOutlined = createSvgIcon(_jsx("path", { d: "M11.3846 19H12.6154V17.0346L16 13.65V9.3077C16 9.23077 15.9679 9.16024 15.9038 9.09613C15.8397 9.03203 15.7692 8.99998 15.6922 8.99998H8.3077C8.23077 8.99998 8.16024 9.03203 8.09613 9.09613C8.03203 9.16024 7.99997 9.23077 7.99997 9.3077V13.65L11.3846 17.0346V19ZM9.88462 20.5V17.673L6.5 14.2884V9.3077C6.5 8.80898 6.67661 8.38303 7.02982 8.02983C7.38302 7.67661 7.80898 7.5 8.3077 7.5H9.42308L8.6731 8.25V3.5H10.1731V7.5H13.8269V3.5H15.3269V8.25L14.5769 7.5H15.6922C16.191 7.5 16.6169 7.67661 16.9701 8.02983C17.3233 8.38303 17.5 8.80898 17.5 9.3077V14.2884L14.1153 17.673V20.5H9.88462Z", fill: "currentColor" }), "IconPowerPlugOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconPowerPlugOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsPower` instead.");
}
export default IconPowerPlugOutlined;
//# sourceMappingURL=IconPowerPlugOutlined.js.map