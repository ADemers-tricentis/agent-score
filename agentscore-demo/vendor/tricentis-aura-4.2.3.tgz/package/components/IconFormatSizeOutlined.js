import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of adjusting or formatting text size with an
 * outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFormatSize` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFormatSize.mjs`.
 */
const IconFormatSizeOutlined = createSvgIcon(_jsx("path", { d: "M14.4135 19.5V6.62495H9.45196V4.5H21.5V6.62495H16.5384V19.5H14.4135ZM5.48081 19.5V11.5769H2.50003V9.45193H10.5769V11.5769H7.59613V19.5H5.48081Z", fill: "currentColor" }), "IconFormatSizeOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconFormatSizeOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFormatSize` instead.");
}
export default IconFormatSizeOutlined;
//# sourceMappingURL=IconFormatSizeOutlined.js.map