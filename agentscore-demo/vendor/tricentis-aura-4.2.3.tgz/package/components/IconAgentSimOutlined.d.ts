/**
 * React component for an SVG icon of a 3D isometric box on top of a bench with
 * an outlined style.
 */
declare const IconAgentSimOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAgentSimOutlined;
