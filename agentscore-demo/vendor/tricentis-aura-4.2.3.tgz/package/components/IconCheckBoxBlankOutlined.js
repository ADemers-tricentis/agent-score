import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of an unchecked checkbox, square, with
 * outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCheckBoxOutlineBlank` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCheckBoxOutlineBlank.mjs`.
 */
const IconCheckBoxBlankOutlined = createSvgIcon(_jsx("path", { d: "M5.3077 20.5C4.80257 20.5 4.375 20.325 4.025 19.975C3.675 19.625 3.5 19.1974 3.5 18.6923V5.3077C3.5 4.80257 3.675 4.375 4.025 4.025C4.375 3.675 4.80257 3.5 5.3077 3.5H18.6923C19.1974 3.5 19.625 3.675 19.975 4.025C20.325 4.375 20.5 4.80257 20.5 5.3077V18.6923C20.5 19.1974 20.325 19.625 19.975 19.975C19.625 20.325 19.1974 20.5 18.6923 20.5H5.3077ZM5.3077 19H18.6923C18.7692 19 18.8397 18.9679 18.9038 18.9038C18.9679 18.8397 19 18.7692 19 18.6923V5.3077C19 5.23077 18.9679 5.16024 18.9038 5.09613C18.8397 5.03203 18.7692 4.99998 18.6923 4.99998H5.3077C5.23077 4.99998 5.16024 5.03203 5.09612 5.09613C5.03202 5.16024 4.99997 5.23077 4.99997 5.3077V18.6923C4.99997 18.7692 5.03202 18.8397 5.09612 18.9038C5.16024 18.9679 5.23077 19 5.3077 19Z", fill: "currentColor" }), "IconCheckBoxBlankOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconCheckBoxBlankOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsCheckBoxOutlineBlank` instead.");
}
export default IconCheckBoxBlankOutlined;
//# sourceMappingURL=IconCheckBoxBlankOutlined.js.map