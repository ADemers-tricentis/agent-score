import { type SxProps, type Theme } from "@mui/material/styles";
/**
 * React component for the Tricentis brand mark.
 * @param props Props.
 * @returns React node.
 */
export default function BrandMark({ sx, }: {
    /**
     * [Material UI theme aware custom styles](https://mui.com/system/getting-started/the-sx-prop)
     * for the SVG element.
     */
    sx?: SxProps<Theme>;
}): import("react/jsx-runtime").JSX.Element;
