import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a completed task.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsTaskAlt` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsTaskAlt.mjs`.
 */
const IconTaskAltOutlined = createSvgIcon(_jsx("path", { d: "M12.0016 21.5C10.6877 21.5 9.45268 21.2506 8.29655 20.752C7.1404 20.2533 6.13472 19.5765 5.2795 18.7217C4.42427 17.8669 3.74721 16.8616 3.24833 15.706C2.74944 14.5504 2.5 13.3156 2.5 12.0017C2.5 10.6877 2.74937 9.45268 3.24812 8.29655C3.74688 7.1404 4.42375 6.13472 5.27875 5.2795C6.13375 4.42427 7.13917 3.74721 8.295 3.24833C9.45082 2.74944 10.6858 2.5 12 2.5C13.0534 2.5 14.0501 2.65833 14.99 2.975C15.93 3.29167 16.7923 3.73333 17.5769 4.3L16.4923 5.4096C15.8462 4.96473 15.1462 4.61858 14.3925 4.37113C13.6388 4.12369 12.8413 3.99998 12 3.99998C9.78331 3.99998 7.89581 4.77914 6.33748 6.33748C4.77914 7.89581 3.99998 9.78331 3.99998 12C3.99998 14.2166 4.77914 16.1041 6.33748 17.6625C7.89581 19.2208 9.78331 20 12 20C14.2166 20 16.1041 19.2208 17.6625 17.6625C19.2208 16.1041 20 14.2166 20 12C20 11.6487 19.9769 11.3013 19.9308 10.9577C19.8846 10.6142 19.8154 10.2802 19.7231 9.95573L20.9346 8.7346C21.1179 9.2487 21.258 9.77756 21.3548 10.3212C21.4516 10.8648 21.5 11.4244 21.5 12C21.5 13.3141 21.2506 14.5491 20.752 15.705C20.2533 16.8608 19.5765 17.8662 18.7217 18.7212C17.8669 19.5762 16.8616 20.2531 15.706 20.7518C14.5504 21.2506 13.3156 21.5 12.0016 21.5ZM10.5808 16.2538L6.67693 12.35L7.73075 11.2962L10.5808 14.1462L20.4461 4.2654L21.5 5.31923L10.5808 16.2538Z", fill: "currentColor" }), "IconTaskAltOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconTaskAltOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsTaskAlt` instead.");
}
export default IconTaskAltOutlined;
//# sourceMappingURL=IconTaskAltOutlined.js.map