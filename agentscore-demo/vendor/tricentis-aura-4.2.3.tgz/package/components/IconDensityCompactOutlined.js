import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of five vertically stacked boxes.  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDensitySmall` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDensitySmall.mjs`.
 */
const IconDensityCompactOutlined = createSvgIcon(_jsx("path", { d: "M3.79412 21C3.56912 21 3.38052 20.9319 3.22831 20.7956C3.0761 20.6594 3 20.4906 3 20.2892C3 20.0878 3.0761 19.919 3.22831 19.783C3.38052 19.647 3.56912 19.579 3.79412 19.579H20.2059C20.4309 19.579 20.6195 19.6471 20.7717 19.7833C20.9239 19.9196 21 20.0884 21 20.2898C21 20.4912 20.9239 20.6599 20.7717 20.7959C20.6195 20.932 20.4309 21 20.2059 21H3.79412ZM3.79412 15.4706C3.56912 15.4706 3.38052 15.4025 3.22831 15.2663C3.0761 15.13 3 14.9612 3 14.7598C3 14.5584 3.0761 14.3897 3.22831 14.2537C3.38052 14.1176 3.56912 14.0496 3.79412 14.0496H20.2059C20.4309 14.0496 20.6195 14.1177 20.7717 14.254C20.9239 14.3902 21 14.559 21 14.7604C21 14.9618 20.9239 15.1306 20.7717 15.2666C20.6195 15.4026 20.4309 15.4706 20.2059 15.4706H3.79412ZM3.79412 9.95039C3.56912 9.95039 3.38052 9.88226 3.22831 9.74601C3.0761 9.60978 3 9.44096 3 9.23955C3 9.03816 3.0761 8.86944 3.22831 8.73342C3.38052 8.59739 3.56912 8.52938 3.79412 8.52938H20.2059C20.4309 8.52938 20.6195 8.59749 20.7717 8.73373C20.9239 8.86997 21 9.03879 21 9.24019C21 9.4416 20.9239 9.61032 20.7717 9.74635C20.6195 9.88237 20.4309 9.95039 20.2059 9.95039H3.79412ZM3.79412 4.42103C3.56912 4.42103 3.38052 4.35291 3.22831 4.21666C3.0761 4.08043 3 3.91161 3 3.7102C3 3.5088 3.0761 3.34009 3.22831 3.20406C3.38052 3.06802 3.56912 3 3.79412 3H20.2059C20.4309 3 20.6195 3.06812 20.7717 3.20437C20.9239 3.34062 21 3.50944 21 3.71084C21 3.91225 20.9239 4.08097 20.7717 4.21699C20.6195 4.35302 20.4309 4.42103 20.2059 4.42103H3.79412Z", fill: "currentColor" }), "IconDensityCompactOutlined");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconDensityCompactOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsDensitySmall` instead.");
}
export default IconDensityCompactOutlined;
//# sourceMappingURL=IconDensityCompactOutlined.js.map