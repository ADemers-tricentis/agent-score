import { jsx as _jsx } from "react/jsx-runtime";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import isArray from "../utils/private/isArray.js";
/**
 * React component for a tab panel that can be used with the
 * [Material UI](https://mui.com/material-ui) component
 * [`Tabs`](https://mui.com/material-ui/api/tabs).
 * @param props Props.
 * @returns React node.
 */
export default function TabPanel({ children, index, sx = [], tabIdFn, value, ...props }) {
    return (_jsx("div", { role: "tabpanel", hidden: value !== index, id: tabIdFn ? tabIdFn(index) : `tabpanel-${index}`, ...props, children: value === index && (_jsx(Box, { sx: [{ p: 1 }, ...(isArray(sx) ? sx : [sx])], children: _jsx(Typography, { component: "div", children: children }) })) }));
}
//# sourceMappingURL=TabPanel.js.map