import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { styled } from "@mui/material/styles";
/**
 * React component for the Tricentis TTM4Jira product mark.
 * @param props Props.
 * @returns React node.
 */
export default function ProductMarkTTM4Jira({ sx, }) {
    return (_jsxs(Svg, { viewBox: "0 0 24 24", className: "ProductMarkTTM4Jira", "data-testid": "ProductMarkTTM4Jira", sx: sx, children: [_jsx("path", { className: "ProductMarkTTM4Jira-background", d: "M0 4a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v16a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4Z" }), _jsx("path", { className: "ProductMarkTTM4Jira-text", d: "M11.008 4.48h1.74L15.4 8.152l2.676-3.672h1.74V13h-1.92V7.756l-2.485 3.432-2.495-3.444V13h-1.909V4.48ZM5.723 13V6.304H3.551V4.48H9.84v1.824H7.643V13h-1.92Zm10.381 7.14c-.437 0-.808-.174-1.114-.52a1.829 1.829 0 0 1-.452-1.242c0-.482.15-.896.452-1.242.306-.347.677-.52 1.114-.52.387 0 .693.137.918.412v-.338h1.019v3.375h-1.02v-.337c-.224.274-.53.412-.917.412Zm-.331-1.162c.144.158.33.237.56.237.23 0 .414-.079.554-.236a.856.856 0 0 0 .216-.601.856.856 0 0 0-.216-.601.703.703 0 0 0-.554-.236.724.724 0 0 0-.56.236.873.873 0 0 0-.21.6c0 .244.07.444.21.602Zm-3.772 1.087V16.69h1.02v.506a.783.783 0 0 1 .303-.384.829.829 0 0 1 .5-.162c.117 0 .227.013.33.04v1.033a1.393 1.393 0 0 0-.452-.081.61.61 0 0 0-.506.23c-.117.148-.175.346-.175.593v1.6H12Zm-1.487-3.834a.62.62 0 0 1-.446-.182.617.617 0 0 1-.189-.452c0-.176.063-.324.19-.446a.61.61 0 0 1 .445-.189.6.6 0 0 1 .452.19c.126.12.189.27.189.445a.617.617 0 0 1-.19.452.614.614 0 0 1-.451.182Zm-.507 3.834V16.69h1.02v3.375h-1.02Zm-2.531.081c-.44 0-.81-.123-1.107-.371-.297-.252-.445-.623-.445-1.114h1.06c0 .158.045.28.135.365a.53.53 0 0 0 .357.121.52.52 0 0 0 .351-.121.42.42 0 0 0 .142-.338v-3.415h1.073v3.483c0 .459-.148.805-.445 1.04-.297.233-.67.35-1.12.35Z" })] }));
}
const Svg = styled("svg")(({ theme }) => ({
    "&.ProductMarkTTM4Jira": {
        "& .ProductMarkTTM4Jira-background": {
            fill: theme.vars.palette.aura.brand,
        },
        "& .ProductMarkTTM4Jira-text": {
            fill: theme.vars.palette.aura.brandInverted,
        },
    },
}));
//# sourceMappingURL=ProductMarkTTM4Jira.js.map