import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a folder crossed by a single line.  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFolderOff` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFolderOff.mjs`.
 */
const IconFolderOffOutlined = createSvgIcon(_jsx("path", { d: "M21.6577 17.7788L20.3346 16.4558V7.58851C20.3346 7.49876 20.3058 7.42504 20.2481 7.36734C20.1904 7.30964 20.1166 7.28079 20.0269 7.28079H11.1846L9.18461 5.28079L7.68464 3.78081H9.82306L11.8231 5.78081H20.0269C20.532 5.78081 20.9596 5.95581 21.3096 6.30581C21.6596 6.65581 21.8346 7.08338 21.8346 7.58851V16.9731C21.8346 17.1243 21.8211 17.2679 21.7942 17.4038C21.7673 17.5397 21.7218 17.6647 21.6577 17.7788ZM20.9731 22.0423L17.7116 18.7808H4.64234C4.13721 18.7808 3.70964 18.6058 3.35964 18.2558C3.00964 17.9058 2.83464 17.4782 2.83464 16.9731V5.58851C2.83464 5.08338 3.00964 4.65581 3.35964 4.30581C3.70964 3.95581 4.13721 3.78081 4.64234 3.78081H4.83464L6.33461 5.28079H4.64234C4.55259 5.28079 4.47886 5.30964 4.42116 5.36734C4.36346 5.42504 4.33461 5.49876 4.33461 5.58851V16.9731C4.33461 17.0628 4.36346 17.1365 4.42116 17.1942C4.47886 17.2519 4.55259 17.2808 4.64234 17.2808H16.2116L1.95776 3.01156L3.01159 1.95776L22.0423 20.9885L20.9731 22.0423Z", fill: "currentColor" }), "IconFolderOffOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconFolderOffOutlined` is deprecated and will be removed in v4.00. Use `IconMaterialSymbolsFolderOff` instead.");
}
export default IconFolderOffOutlined;
//# sourceMappingURL=IconFolderOffOutlined.js.map