import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a half-star with a filled style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsStarHalf` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsStarHalf.mjs`.
 */
const IconStarHalfFilled = createSvgIcon(_jsx("path", { d: "M22 9.74L14.81 9.12L12 2.5L9.19 9.13L2 9.74L7.46 14.47L5.82 21.5L12 17.77L18.18 21.5L16.55 14.47L22 9.74ZM12 15.9V6.6L13.71 10.64L18.09 11.02L14.77 13.9L15.77 18.18L12 15.9Z", fill: "currentColor" }), "IconStarHalfFilled");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconStarHalfFilled` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsStarHalf` instead.");
}
export default IconStarHalfFilled;
//# sourceMappingURL=IconStarHalfFilled.js.map