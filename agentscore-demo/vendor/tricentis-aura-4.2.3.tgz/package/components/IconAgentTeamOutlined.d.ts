/**
 * React component for an SVG icon of an avatar with two dots on top of a bench
 * with an outlined style.
 */
declare const IconAgentTeamOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAgentTeamOutlined;
