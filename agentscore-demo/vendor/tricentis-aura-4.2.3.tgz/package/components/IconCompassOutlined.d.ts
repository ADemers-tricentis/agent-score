/**
 * React component for an SVG icon of a compass with an outlined style  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsExplore` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsExplore.mjs`.
 */
declare const IconCompassOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCompassOutlined;
