import { type BoxProps } from "@mui/material/Box";
import type { ReactNode } from "react";
/**
 * React component for a drawer header. Intended for use as a child of the Aura
 * React component `DrawerContainer`.
 * @param props Props.
 * @returns React node.
 */
export default function DrawerHeader({ heading, ...props }: BoxProps & {
    /** Heading text. */
    heading?: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
