/**
 * React component for an SVG icon featuring three vertical outlined bars of
 * varying heights, symbolizing cellular data strength.
 */
declare const IconCellularDataOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCellularDataOutlined;
