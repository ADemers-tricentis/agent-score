import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon used in Neoload that represents distribution
 * ramp up with an outlined style.
 */
const IconDistributionRampUpOutlined = createSvgIcon(_jsxs(_Fragment, { children: [_jsx("path", { stroke: "currentColor", strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "1.4", fill: "none", d: "M19.5 6.5 17 4m2.5 2.5L17 9m2.5-2.5h-8v8h-7" }), _jsx("path", { stroke: "currentColor", strokeLinecap: "round", strokeWidth: "1.4", d: "M4 20h16" })] }), "IconDistributionRampUpOutlined");
export default IconDistributionRampUpOutlined;
//# sourceMappingURL=IconDistributionRampUpOutlined.js.map