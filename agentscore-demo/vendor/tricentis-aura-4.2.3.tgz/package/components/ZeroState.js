import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Typography, {} from "@mui/material/Typography";
import isArray from "../utils/private/isArray.js";
/**
 * React component for placeholder content when there is no content to display
 * yet.
 * @param props Props.
 * @returns React node.
 */
export default function ZeroState({ illustration, title, children, actions, containerSx = [], titleProps = { variant: "h4", component: "h2" }, }) {
    return (_jsxs(Paper, { elevation: 0, sx: [
            {
                display: "flex",
                flexDirection: "column",
                margin: "0 auto",
                maxWidth: "432px",
                gap: (theme) => theme.spacing(4),
            },
            ...(isArray(containerSx) ? containerSx : [containerSx]),
        ], children: [!!illustration && (_jsx(Box, { sx: {
                    display: "flex",
                    justifyContent: "center",
                }, children: illustration })), _jsxs(Box, { sx: {
                    display: "flex",
                    flexDirection: "column",
                    gap: (theme) => theme.spacing(1.5),
                }, children: [_jsx(Typography, { ...titleProps, fontWeight: "medium", children: title }), _jsx(Box, { typography: "body1", children: children })] }), !!actions && (_jsx(Box, { sx: {
                    display: "flex",
                    flexWrap: "wrap",
                    alignItems: "center",
                    gap: 2,
                }, children: actions }))] }));
}
//# sourceMappingURL=ZeroState.js.map