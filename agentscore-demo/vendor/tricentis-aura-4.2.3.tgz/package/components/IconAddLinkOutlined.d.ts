/**
 * React component for an SVG icon of adding a link.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAddLink` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAddLink.mjs`.
 */
declare const IconAddLinkOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAddLinkOutlined;
