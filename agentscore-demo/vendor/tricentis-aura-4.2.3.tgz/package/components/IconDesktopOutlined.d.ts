/**
 * React component for an SVG icon of a desktop with an outlined style.
 */
declare const IconDesktopOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDesktopOutlined;
