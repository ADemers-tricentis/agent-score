import { jsx as _jsx } from "react/jsx-runtime";
import { filledInputClasses } from "@mui/material/FilledInput";
import IconButton, {} from "@mui/material/IconButton";
import InputAdornment, { inputAdornmentClasses, } from "@mui/material/InputAdornment";
import { inputBaseClasses } from "@mui/material/InputBase";
import { inputLabelClasses } from "@mui/material/InputLabel";
import { outlinedInputClasses } from "@mui/material/OutlinedInput";
import TextField, {} from "@mui/material/TextField";
import Tooltip from "@mui/material/Tooltip";
import { useForkRef } from "@mui/material/utils";
import { useCallback, useEffect, useRef, useState, } from "react";
import isArray from "../utils/private/isArray.js";
/**
 * React component for a collapsible [Material UI](https://mui.com/material-ui)
 * {@linkcode TextField} that when collapsed, has its input disabled and width
 * reduced to crop off the input and only display a start positioned input
 * adornment icon button for toggling the collapsed state. The collapsed state
 * toggles with smooth CSS transitions.
 * @param props Props.
 * @returns React node.
 */
export default function TextFieldCollapsible({ defaultCollapsed = true, disabled, icon, IconButtonProps, inputFocusDelay = 0, slotProps, inputRef, onBlur, size = "small", tooltipTitle, sx = [], ...textFieldProps }) {
    const [collapsed, setCollapsed] = useState(defaultCollapsed);
    const inputRefLocal = useRef(null);
    const inputRefCallback = useForkRef(inputRefLocal, inputRef);
    const onClickInputAdornmentIconButton = useCallback((event) => {
        if (collapsed)
            setCollapsed(false);
        else if (inputRefLocal.current?.value)
            inputRefLocal.current.focus();
        else
            setCollapsed(true);
        IconButtonProps?.onClick?.(event);
    }, [IconButtonProps, collapsed]);
    const onBlurTextField = useCallback((event) => {
        const { currentTarget: { value }, } = event;
        setTimeout(() => {
            if (!value && !collapsed)
                setCollapsed(true);
        }, 250);
        onBlur?.(event);
    }, [collapsed, onBlur]);
    useEffect(() => {
        let timeout = null;
        if (!collapsed)
            timeout = setTimeout(() => {
                inputRefLocal.current?.focus();
            }, inputFocusDelay);
        return () => {
            if (timeout)
                clearTimeout(timeout);
        };
    }, [collapsed, inputFocusDelay]);
    return (_jsx(TextField, { ...textFieldProps, size: size, disabled: collapsed || disabled, onBlur: onBlurTextField, slotProps: {
            ...slotProps,
            input: {
                ...(typeof slotProps?.input === "function" ? {} : slotProps?.input),
                startAdornment: (_jsx(InputAdornment, { position: "start", children: _jsx(Tooltip, { title: tooltipTitle, arrow: true, placement: "bottom", children: _jsx(IconButton, { size: size, ...IconButtonProps, onClick: onClickInputAdornmentIconButton, children: icon }) }) })),
            },
        }, inputRef: inputRefCallback, sx: [
            {
                // All variations.
                [`& .${inputBaseClasses.adornedStart}`]: {
                    transition,
                    ...(collapsed && {
                        paddingLeft: 0,
                    }),
                },
                [`& .${inputBaseClasses.input}`]: {
                    transition,
                    ...(collapsed && {
                        width: 0,
                        paddingLeft: 0,
                        paddingRight: 0,
                    }),
                },
                [`& .${inputLabelClasses.root}`]: {
                    transition,
                    ...(collapsed && {
                        opacity: 0,
                    }),
                },
                [`& .${inputAdornmentClasses.positionStart}`]: {
                    transition,
                    ...(collapsed && {
                        marginRight: 0,
                    }),
                },
                // Variation outlined.
                [`& .${outlinedInputClasses.notchedOutline}`]: {
                    transition: `opacity ${transitionDuration}ms ${transitionEasing}`,
                    ...(collapsed && {
                        opacity: 0,
                    }),
                },
                // Variation filled.
                ...(collapsed && {
                    [`& .${filledInputClasses.root}, & .${filledInputClasses.root}.${filledInputClasses.disabled}`]: {
                        backgroundColor: "transparent",
                    },
                }),
            },
            ...(isArray(sx) ? sx : [sx]),
        ] }));
}
const transitionDuration = 300;
const transitionEasing = "ease-in-out";
const transition = `all ${transitionDuration}ms ${transitionEasing}`;
//# sourceMappingURL=TextFieldCollapsible.js.map