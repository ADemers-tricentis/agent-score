/**
 *  React component for an SVG icon of a plug and a socket diagonally with
 *  outline style.
 */
declare const IconConnectionOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconConnectionOutlined;
