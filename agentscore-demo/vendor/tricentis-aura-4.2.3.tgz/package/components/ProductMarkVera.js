import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { styled } from "@mui/material/styles";
/**
 * React component for the Tricentis Vera product mark.
 * @param props Props.
 * @returns React node.
 */
export default function ProductMarkVera({ sx, }) {
    return (_jsxs(Svg, { viewBox: "0 0 24 24", className: "ProductMarkVera", "data-testid": "ProductMarkVera", sx: sx, children: [_jsx("path", { className: "ProductMarkVera-background", d: "M0 4a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v16a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4Z" }), _jsx("path", { className: "ProductMarkVera-text", d: "M15.898 17.39c-.986 0-1.798-.314-2.435-.943-.63-.63-.944-1.428-.944-2.397 0-.952.319-1.743.957-2.372.645-.629 1.453-.943 2.422-.943.468 0 .905.08 1.313.242a3.23 3.23 0 0 1 1.097.701c.323.306.573.701.752 1.186.178.484.26 1.033.242 1.645h-4.909c.034.348.188.641.46.88.271.229.654.344 1.147.344.28 0 .535-.056.765-.166.23-.119.383-.264.459-.434h2.014c-.203.672-.611 1.216-1.223 1.633-.613.416-1.318.624-2.117.624Zm-.051-5.125c-.365 0-.671.093-.918.28-.238.187-.4.434-.485.74h2.729c-.093-.349-.268-.604-.523-.765a1.386 1.386 0 0 0-.803-.255ZM7.641 17.25l-3.71-9.052h2.206l2.41 6.03 2.397-6.03h2.23l-3.71 9.052H7.642Z" })] }));
}
const Svg = styled("svg")(({ theme }) => ({
    "&.ProductMarkVera": {
        "& .ProductMarkVera-background": {
            fill: theme.vars.palette.aura.brand,
        },
        "& .ProductMarkVera-text": {
            fill: theme.vars.palette.aura.brandInverted,
        },
    },
}));
//# sourceMappingURL=ProductMarkVera.js.map