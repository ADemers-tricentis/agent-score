import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a bell.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsNotifications` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsNotifications.mjs`.
 */
const IconNotificationOutlined = createSvgIcon(_jsx("path", { d: "M4.50003 18.7884V17.2885H6.30773V9.82692C6.30773 8.48205 6.72279 7.29295 7.55291 6.25962C8.38304 5.22629 9.44875 4.5654 10.75 4.27695V3.65387C10.75 3.30665 10.8714 3.01152 11.1143 2.76847C11.3571 2.5254 11.652 2.40387 11.9989 2.40387C12.3458 2.40387 12.641 2.5254 12.8846 2.76847C13.1282 3.01152 13.25 3.30665 13.25 3.65387V4.27695C14.5513 4.5654 15.617 5.22629 16.4471 6.25962C17.2772 7.29295 17.6923 8.48205 17.6923 9.82692V17.2885H19.5V18.7884H4.50003ZM11.9983 21.5961C11.5007 21.5961 11.0753 21.4191 10.7221 21.0651C10.3689 20.7111 10.1923 20.2856 10.1923 19.7884H13.8077C13.8077 20.2872 13.6305 20.7131 13.2762 21.0663C12.9218 21.4195 12.4959 21.5961 11.9983 21.5961ZM7.80768 17.2885H16.1923V9.82692C16.1923 8.66922 15.783 7.68108 14.9644 6.8625C14.1458 6.0439 13.1577 5.63459 12 5.63459C10.8423 5.63459 9.85416 6.0439 9.03558 6.8625C8.21698 7.68108 7.80768 8.66922 7.80768 9.82692V17.2885Z", fill: "currentColor" }), "IconNotificationOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconNotificationOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsNotifications` instead.");
}
export default IconNotificationOutlined;
//# sourceMappingURL=IconNotificationOutlined.js.map