import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a code symbol with outlined style.  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCode` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCode.mjs`.
 */
const IconCodeOutlined = createSvgIcon(_jsx("path", { d: "M8 17.6538L2.34618 12L8 6.34619L9.0692 7.41539L4.4692 12.0154L9.05383 16.6L8 17.6538ZM16 17.6538L14.9308 16.5846L19.5308 11.9846L14.9462 7.40002L16 6.34619L21.6538 12L16 17.6538Z", fill: "currentColor" }), "IconCodeOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconCodeOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsCode` instead.");
}
export default IconCodeOutlined;
//# sourceMappingURL=IconCodeOutlined.js.map