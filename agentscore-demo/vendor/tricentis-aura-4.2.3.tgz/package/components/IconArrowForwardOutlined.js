import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of forward-pointing arrow.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsArrowForward` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowForward.mjs`.
 */
const IconArrowForwardOutlined = createSvgIcon(_jsx("path", { d: "M16.6269 12.75H4.5V11.25H16.6269L10.9308 5.55383L12 4.5L19.5 12L12 19.5L10.9308 18.4461L16.6269 12.75Z", fill: "currentColor" }), "IconArrowForwardOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconArrowForwardOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsArrowForward` instead.");
}
export default IconArrowForwardOutlined;
//# sourceMappingURL=IconArrowForwardOutlined.js.map