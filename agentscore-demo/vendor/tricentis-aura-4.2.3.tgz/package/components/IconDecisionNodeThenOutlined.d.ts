/**
 * React component for an SVG icon of a custom Tosca THEN symbol representing a
 * THEN condition in the Tosca Cloud with an outlined style.
 */
declare const IconDecisionNodeThenOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDecisionNodeThenOutlined;
