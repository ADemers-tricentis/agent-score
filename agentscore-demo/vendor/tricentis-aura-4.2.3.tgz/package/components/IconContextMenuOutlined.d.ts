/**
 * React component for an SVG icon of a custom-built context menu with an
 * outlined style.
 */
declare const IconContextMenuOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconContextMenuOutlined;
