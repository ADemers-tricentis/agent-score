import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
/**
 * React component for an SVG icon of a triangle pointing bottom right.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsArrowDropDown` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowDropDown.mjs`.
 */
const IconArrowDropDown = createSvgIcon(_jsx("path", { d: "M9.07712 14.0817L12.2674 14.0817C12.7478 14.0817 13.1358 13.6937 13.1358 13.2134L13.1358 10.0231C13.1358 9.24709 12.1935 8.85908 11.6453 9.40722L8.45508 12.5975C7.90695 13.1456 8.30111 14.0817 9.07712 14.0817Z", fill: "currentColor" }), "IconArrowDropDown");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconArrowDropDown` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsArrowDropDown` instead.");
}
export default IconArrowDropDown;
//# sourceMappingURL=IconArrowDropDown.js.map