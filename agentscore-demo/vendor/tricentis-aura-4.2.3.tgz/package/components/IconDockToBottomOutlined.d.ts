/**
 * React component for an SVG icon of two uneven rectangles stacked vertically
 * with an outlined style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDockToBottom` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDockToBottom.mjs`.
 */
declare const IconDockToBottomOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDockToBottomOutlined;
