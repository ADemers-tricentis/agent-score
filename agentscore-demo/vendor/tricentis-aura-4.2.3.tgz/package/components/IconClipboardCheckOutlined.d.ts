/**
 * React component for an SVG icon of a clipboard with a check mark in an
 * outlined style.
 *
 * It serves as the `TestRunsOutlined` icon in Tosca Cloud.
 */
declare const IconClipboardCheckOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconClipboardCheckOutlined;
