import { jsx as _jsx } from "react/jsx-runtime";
import Box from "@mui/material/Box";
import { styled } from "@mui/material/styles";
/**
 * React component which allows you to create a page layout with padding and default background color.
 * The component should be used as a container for the main content of a page in the application.
 * @param props Props.
 * @returns React node.
 */
export default function Page({ padded = true, content, }) {
    return _jsx(PageContainer, { padded: padded, children: content });
}
const PageContainer = styled(Box)(({ theme, padded }) => ({
    height: "100%",
    width: "100%",
    padding: padded ? theme.spacing(2) : 0,
    backgroundColor: theme.vars.palette.aura.backgroundDefault,
}));
//# sourceMappingURL=Page.js.map