/**
 * React component for an SVG icon of an arrow pointing down and bending to the
 * right with an outlined style.
 */
declare const IconArrowTurnDownRightOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconArrowTurnDownRightOutlined;
