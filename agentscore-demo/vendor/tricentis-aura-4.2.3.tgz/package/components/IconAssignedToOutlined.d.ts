/**
 * React component for an SVG icon of an assignment or assigned to symbol with
 * outline style.
 */
declare const IconAssignedToOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAssignedToOutlined;
