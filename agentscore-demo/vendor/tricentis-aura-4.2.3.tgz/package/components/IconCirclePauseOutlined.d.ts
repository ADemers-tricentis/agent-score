/**
 * React component for an SVG icon of a circle with two vertically lines at the
 * center representing a pause cirlcle with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsPauseCircle` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsPauseCircle.mjs`.
 */
declare const IconCirclePauseOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCirclePauseOutlined;
