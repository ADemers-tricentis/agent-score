import { jsx as _jsx } from "react/jsx-runtime";
import Box, {} from "@mui/material/Box";
/**
 * React component for drawer main content. Intended for use as a child of the
 * Aura React component `DrawerContainer`; it should be the only child that flex
 * grows, filling the available space between the top and bottom drawer
 * components.
 * @param props Props.
 * @returns React node.
 */
export default function DrawerContent(props) {
    return _jsx(Box, { flexGrow: 1, px: 3, pt: 1, pb: 3, overflow: "auto", ...props });
}
//# sourceMappingURL=DrawerContent.js.map