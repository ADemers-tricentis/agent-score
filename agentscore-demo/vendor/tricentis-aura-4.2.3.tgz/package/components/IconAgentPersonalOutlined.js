import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of an avatar in a square on top of a bench
 * with an outlined style.
 */
const IconAgentPersonalOutlined = createSvgIcon(_jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M7.7 3A1.3 1.3 0 0 1 9 1.7h6A1.3 1.3 0 0 1 16.3 3v6a1.3 1.3 0 0 1-1.3 1.3H9A1.3 1.3 0 0 1 7.7 9V3ZM15 7.7v.622a3.973 3.973 0 0 0-1.309-1.06A3.672 3.672 0 0 0 12 6.87c-.612 0-1.176.13-1.691.393A3.973 3.973 0 0 0 9 8.322V3h6v4.7Zm6 5.3v-1.4H3V13h3.3v2.3H5a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H7.7V13h8.6v2.3H15a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2h-1.3V13H21ZM9 16.7H5a.6.6 0 0 0-.6.6v3a.6.6 0 0 0 .6.6h4a.6.6 0 0 0 .6-.6v-3a.6.6 0 0 0-.6-.6Zm10 0h-4a.6.6 0 0 0-.6.6v3a.6.6 0 0 0 .6.6h4a.6.6 0 0 0 .6-.6v-3a.6.6 0 0 0-.6-.6ZM12.91 5.636a1.24 1.24 0 0 1-.91.375 1.24 1.24 0 0 1-.91-.375 1.24 1.24 0 0 1-.376-.91c0-.357.125-.661.375-.911s.554-.375.911-.375.66.125.91.375.376.554.376.91c0 .358-.125.661-.375.911Z", fill: "currentColor" }), "IconAgentPersonalOutlined");
export default IconAgentPersonalOutlined;
//# sourceMappingURL=IconAgentPersonalOutlined.js.map