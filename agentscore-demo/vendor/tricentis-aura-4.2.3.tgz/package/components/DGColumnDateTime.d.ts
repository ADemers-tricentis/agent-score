/**
 * React component for rendering a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) cell that has
 * a datetime value, with a consistent format in the HTML element
 * [`time`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/time). A
 * falsy cell value causes the cell to render empty. For use with the grid
 * column definition option
 * [`renderCell`](https://mui.com/x/api/data-grid/grid-col-def/#properties).
 *
 * - [Usage guidelines](https://tricentisgmbh.sharepoint.com/:w:/r/sites/Technology/UX/Design%20System/Guidelines%20%26%20Patterns/Component%20Usage%20Guidelines/Date%20and%20Time%20Format.docx?d=w051263084dba4a43b8d102ec3affb9bb&csf=1&web=1&e=jbWvbA)
 * @param props Props.
 * @returns React node.
 */
export default function DGColumnDateTime({ format, formatFunction, value, }: {
    /**
     * Date format, to be used with the prop `formatFunction`. Defaults to
     * `"YYYY-MM-DD HH:mm:ss"`.
     */
    format?: string;
    /**
     * Formats the date.
     * @param value Date to format.
     * @param format Desired date format.
     * @returns Formatted date.
     */
    formatFunction?: (value: Date | string | number, format: string) => string;
    /** Data grid cell value. */
    value: Date | string | number | null | undefined;
}): import("react/jsx-runtime").JSX.Element | null;
