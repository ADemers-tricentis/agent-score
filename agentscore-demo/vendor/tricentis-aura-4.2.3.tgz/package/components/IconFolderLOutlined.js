import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of a custom-built folder symbol with a
 * centered "L". This icon is typically used to represent a Test Step Library
 * in Tosca Cloud.
 */
const IconFolderLOutlined = createSvgIcon(_jsx("path", { d: "M4.31 19.5C3.8 19.5 3.38 19.32 3.03 18.97C2.68 18.62 2.5 18.19 2.5 17.69V6.31C2.5 5.8 2.68 5.38 3.03 5.03C3.38 4.68 3.81 4.5 4.31 4.5H9.05C9.29 4.5 9.52 4.55 9.75 4.64C9.97 4.73 10.17 4.86 10.33 5.03L11.8 6.5H19.69C20.2 6.5 20.62 6.68 20.97 7.03C21.32 7.38 21.5 7.81 21.5 8.31V17.69C21.5 18.2 21.32 18.62 20.97 18.97C20.62 19.32 20.19 19.5 19.69 19.5H4.31ZM4.31 18H19.69C19.78 18 19.85 17.97 19.91 17.91C19.97 17.85 20 17.78 20 17.69V8.31C20 8.22 19.97 8.15 19.91 8.09C19.85 8.03 19.78 8 19.69 8H11.18L9.27 6.09C9.27 6.09 9.2 6.04 9.17 6.02C9.13 6.01 9.1 6 9.06 6H4.31C4.22 6 4.15 6.03 4.09 6.09C4.03 6.15 4 6.22 4 6.31V17.69C4 17.78 4.03 17.85 4.09 17.91C4.15 17.97 4.22 18 4.31 18ZM13.91 14.64C13.75 14.48 13.55 14.4 13.31 14.4H11.54V10.75C11.54 10.51 11.46 10.31 11.3 10.15C10.98 9.83 10.41 9.83 10.09 10.15C9.93 10.31 9.85 10.51 9.85 10.75V15.17C9.85 15.43 9.94 15.65 10.12 15.83C10.3 16.01 10.52 16.1 10.78 16.1H13.31C13.55 16.1 13.75 16.02 13.91 15.86C14.07 15.7 14.15 15.5 14.15 15.26C14.15 15.02 14.07 14.82 13.91 14.66V14.64Z", fill: "currentColor" }), "IconFolderLOutlined");
export default IconFolderLOutlined;
//# sourceMappingURL=IconFolderLOutlined.js.map