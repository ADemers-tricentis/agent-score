/**
 * React component for an SVG icon of a browser with an outlined style.
 */
declare const IconBrowserOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconBrowserOutlined;
