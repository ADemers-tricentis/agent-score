import { jsx as _jsx } from "react/jsx-runtime";
import { styled } from "@mui/material/styles";
import MuiTooltip, { tooltipClasses } from "@mui/material/Tooltip";
import { forwardRef } from "react";
/**
 * React component for a tooltip that wraps a
 * [child React element capable of receiving a React ref](https://mui.com/material-ui/guides/composition/#caveat-with-refs),
 * and displays informative text when it’s hovered, focused, or tapped. It
 * implements the [Material UI](https://mui.com/material-ui) component
 * [`Tooltip`](https://mui.com/material-ui/api/tooltip).
 * @param props Props.
 * @returns React node.
 */
const Tooltip = forwardRef(({ variant = "standard", ...props }, forwardedRef) => variant === "error" ? (_jsx(ErrorTooltip, { ref: forwardedRef, ...props })) : (_jsx(MuiTooltip, { ref: forwardedRef, ...props })));
export default Tooltip;
/** React component for a tooltip with error styling. */
const ErrorTooltip = styled(({ className, ...props }) => (_jsx(MuiTooltip, { ...props, classes: { popper: className } })))(({ theme }) => ({
    [`& .${tooltipClasses.tooltip}`]: {
        border: `1px solid ${theme.vars.palette.error.main}`,
        backgroundColor: theme.vars.palette.tooltip.error.bg,
        color: theme.vars.palette.tooltip.error.text,
    },
    [`& .${tooltipClasses.arrow}`]: {
        color: theme.vars.palette.tooltip.error.bg,
        "&::before": {
            border: `1px solid ${theme.vars.palette.error.main}`,
        },
    },
}));
//# sourceMappingURL=Tooltip.js.map