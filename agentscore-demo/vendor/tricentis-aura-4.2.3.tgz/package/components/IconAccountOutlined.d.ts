/**
 * React component for an SVG icon of a placeholder profile avatar with
 * thinner line strokes.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAccountCircle` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAccountCircle.mjs`.
 */
declare const IconAccountOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAccountOutlined;
