import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of upward-pointing arrow with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsArrowUpward` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowUpward.mjs`.
 */
const IconArrowUpwardOutlined = createSvgIcon(_jsx("path", { d: "M11.25 19.5V7.37303L5.55383 13.0692L4.5 12L12 4.5L19.5 12L18.4461 13.0692L12.7499 7.37303V19.5H11.25Z", fill: "currentColor" }), "IconArrowUpwardOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconArrowUpwardOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsArrowUpward` instead.");
}
export default IconArrowUpwardOutlined;
//# sourceMappingURL=IconArrowUpwardOutlined.js.map