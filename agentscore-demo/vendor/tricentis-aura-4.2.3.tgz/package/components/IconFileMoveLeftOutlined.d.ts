/**
 * React component for an SVG icon of a folder with an arrow pointing to the
 * left in an outlined style.
 */
declare const IconFileMoveLeftOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconFileMoveLeftOutlined;
