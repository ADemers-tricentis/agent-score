/**
 * React component for an SVG icon of a square with a grid of dots and a box to
 * its right inside with an outlined style.
 */
declare const IconAPIRegistryOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAPIRegistryOutlined;
