import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of a custom-built tree structure with nodes
 * or boxes linked together with an outlined style.
 */
const IconNodeTreeOutlined = createSvgIcon(_jsx("path", { d: "M15.25 20.75V17.75H11.25V7.75H8.75V10.75H2.25V3.25H8.75V6.25H15.25V3.25H21.75V10.75H15.25V7.75H12.75V16.25H15.25V13.25H21.75V20.75H15.25ZM16.75 9.25H20.25V4.75H16.75V9.25ZM16.75 19.25H20.25V14.75H16.75V19.25Z", fill: "currentColor" }), "IconNodeTreeOutlined");
export default IconNodeTreeOutlined;
//# sourceMappingURL=IconNodeTreeOutlined.js.map