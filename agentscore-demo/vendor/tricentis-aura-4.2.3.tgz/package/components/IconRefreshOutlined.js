import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a refresh action with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsRefresh` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsRefresh.mjs`.
 */
const IconRefreshOutlined = createSvgIcon(_jsx("path", { d: "M12.0384 19.5C9.94468 19.5 8.17124 18.7735 6.71813 17.3207C5.26501 15.8679 4.53845 14.0948 4.53845 12.0015C4.53845 9.90818 5.26501 8.13461 6.71813 6.68078C8.17124 5.22693 9.94468 4.5 12.0384 4.5C13.2077 4.5 14.3141 4.75994 15.3577 5.27982C16.4012 5.79969 17.2692 6.53335 17.9615 7.4808V4.5H19.4615V10.6153H13.3461V9.11538H17.2961C16.7692 8.14999 16.0384 7.38941 15.1038 6.83363C14.1692 6.27786 13.1474 5.99998 12.0384 5.99998C10.3718 5.99998 8.95509 6.58331 7.78843 7.74998C6.62176 8.91664 6.03843 10.3333 6.03843 12C6.03843 13.6666 6.62176 15.0833 7.78843 16.25C8.95509 17.4166 10.3718 18 12.0384 18C13.3218 18 14.4801 17.6333 15.5134 16.9C16.5468 16.1666 17.2718 15.2 17.6884 14H19.2692C18.8153 15.632 17.9214 16.9567 16.5874 17.974C15.2535 18.9913 13.7371 19.5 12.0384 19.5Z", fill: "currentColor" }), "IconRefreshOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconRefreshOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsRefresh` instead.");
}
export default IconRefreshOutlined;
//# sourceMappingURL=IconRefreshOutlined.js.map