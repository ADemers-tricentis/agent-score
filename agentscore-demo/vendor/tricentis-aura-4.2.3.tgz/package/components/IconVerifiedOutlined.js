import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon featuring a checkmark
 * within an outlined polygon, symbolizing a "verified" status.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsVerifiedUser` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsVerifiedUser.mjs`.
 */
const IconVerifiedOutlined = createSvgIcon(_jsx("path", { d: "M8.81155 21.8655L7.02695 18.8578L3.6385 18.1155L3.96928 14.627L1.67313 12.0001L3.96928 9.37322L3.6385 5.88477L7.02695 5.14247L8.81155 2.13477L12 3.48862L15.1885 2.13477L16.9731 5.14247L20.3615 5.88477L20.0307 9.37322L22.3269 12.0001L20.0307 14.627L20.3615 18.1155L16.9731 18.8578L15.1885 21.8654L12 20.5116L8.81155 21.8654V21.8655ZM9.45 19.9501L12 18.8693L14.5808 19.9501L16 17.5501L18.75 16.9193L18.5 14.1001L20.35 12.0001L18.5 9.86934L18.75 7.05012L16 6.45012L14.55 4.05012L12 5.13089L9.41923 4.05012L8 6.45012L5.25 7.05012L5.5 9.86934L3.65 12.0001L5.5 14.1001L5.25 16.9501L8 17.5501L9.45 19.9501ZM10.95 15.2039L16.2538 9.90012L15.2 8.81552L10.95 13.0655L8.8 10.9463L7.74618 12.0001L10.95 15.2039Z", fill: "currentColor" }), "IconVerifiedOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconVerifiedOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsVerifiedUser` instead.");
}
export default IconVerifiedOutlined;
//# sourceMappingURL=IconVerifiedOutlined.js.map