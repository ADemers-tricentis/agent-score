import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of adding a table column to the right.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAddColumnRight` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAddColumnRight.mjs`.
 */
const IconAddColumnRightOutlined = createSvgIcon(_jsxs(_Fragment, { children: [_jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M13 20.22C13 21.203 12.2031 22 11.22 22C8.14667 22 5.07333 22.0002 2 21.9999L2 2.00006C5.07333 1.99995 8.14667 2.00003 11.22 2.00003C12.2031 2.00003 13 2.79696 13 3.78003L13 20.22ZM11.5 15.8384L11.5001 20.18C11.5001 20.3567 11.3568 20.5 11.18 20.5L3.5 20.5C3.50001 18.9461 3.5 17.3923 3.5 15.8384H11.5ZM11.5 9.68651V14.3385H3.5L3.5 9.68651H11.5ZM11.5 8.16156V3.81998C11.5 3.64325 11.3568 3.49998 11.18 3.49998L3.5 3.49998C3.5 5.05384 3.5 6.6077 3.5 8.16156H11.5Z", fill: "currentColor" }), _jsx("path", { d: "M18.25 12.75V15.75H19.75V12.75H22.75V11.2501H19.75V8.25006H18.25V11.2501H15.25V12.75H18.25Z", fill: "currentColor" })] }), "IconAddColumnRightOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconAddColumnRightOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsAddColumnRight` instead.");
}
export default IconAddColumnRightOutlined;
//# sourceMappingURL=IconAddColumnRightOutlined.js.map