import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import Box from "@mui/material/Box";
import IconButton, {} from "@mui/material/IconButton";
import IconMaterialSymbolsMoreVert from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsMoreVert.mjs";
import { useCallback, useState } from "react";
import DGContextMenu from "./private/DGContextMenu.js";
/**
 * React component for rendering a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) cell that
 * contains an icon button to open a context menu. For use with the grid column
 * definition option
 * [`renderCell`](https://mui.com/x/api/data-grid/grid-col-def/#properties).
 * @param props Props.
 * @returns React node.
 */
export default function DGColumnContextMenuButton({ contextMenu, rowData, }) {
    const [contextMenuCoord, setContextMenuCoord] = useState(null);
    const onClickOpenContextMenuIconButton = useCallback((event) => {
        event.preventDefault();
        setContextMenuCoord(contextMenuCoord === null
            ? {
                mouseX: event.clientX - 2,
                mouseY: event.clientY - 4,
            }
            : null);
    }, [contextMenuCoord]);
    const handleClose = useCallback(() => {
        setContextMenuCoord(null);
    }, []);
    const handleClick = useCallback((callback) => {
        callback(rowData);
        handleClose();
    }, [handleClose, rowData]);
    return (_jsxs(_Fragment, { children: [_jsx(Box, { children: _jsx(IconButton, { size: "small", onClick: onClickOpenContextMenuIconButton, children: _jsx(IconMaterialSymbolsMoreVert, {}) }) }), contextMenuCoord && (_jsx(DGContextMenu, { contextMenu: contextMenu, contextMenuCoord: contextMenuCoord, handleClick: handleClick, handleClose: handleClose }))] }));
}
//# sourceMappingURL=DGColumnContextMenuButton.js.map