import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a check, tick, tick mark, correct, pass,
 * success in stroke with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCheck` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCheck.mjs`.
 */
const IconCheckOutlined = createSvgIcon(_jsx("path", { d: "M9.55005 17.6519L4.21545 12.3173L5.28468 11.2481L9.55005 15.5135L18.7154 6.34814L19.7847 7.41734L9.55005 17.6519Z", fill: "currentColor" }), "IconCheckOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconCheckOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsCheck` instead.");
}
export default IconCheckOutlined;
//# sourceMappingURL=IconCheckOutlined.js.map