import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of a star with a filled style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsStar` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsStar.mjs`.
 */
const IconStarFilled = createSvgIcon(_jsx("path", { d: "M12 17.77L18.18 21.5L16.54 14.47L22 9.74L14.81 9.13L12 2.5L9.19 9.13L2 9.74L7.46 14.47L5.82 21.5L12 17.77Z", fill: "currentColor" }), "IconStarFilled");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconStarFilled` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsStar` instead.");
}
export default IconStarFilled;
//# sourceMappingURL=IconStarFilled.js.map