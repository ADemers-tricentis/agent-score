import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a downward-pointing arrow head, dropdown,
 * dropdown, south with filled style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsArrowDropDown` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowDropDown.mjs`.
 */
const IconArrowDropDownFilled = createSvgIcon(_jsx("path", { d: "M7 9.5L12 14.5L17 9.5H7Z", fill: "currentColor" }), "IconArrowDropDownFilled");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconArrowDropDownFilled` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsArrowDropDown` instead.");
}
export default IconArrowDropDownFilled;
//# sourceMappingURL=IconArrowDropDownFilled.js.map