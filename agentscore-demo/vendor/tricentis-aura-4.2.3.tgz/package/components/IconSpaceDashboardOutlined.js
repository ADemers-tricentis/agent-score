import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a space-dashboard with
 * outlined style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsSpaceDashboard` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsSpaceDashboard.mjs`.
 */
const IconSpaceDashboardOutlined = createSvgIcon(_jsx("path", { d: "M5.30772 20.5C4.80259 20.5 4.37502 20.325 4.02502 19.975C3.67502 19.625 3.50002 19.1974 3.50002 18.6923V5.3077C3.50002 4.80257 3.67502 4.375 4.02502 4.025C4.37502 3.675 4.80259 3.5 5.30772 3.5H18.6923C19.1974 3.5 19.625 3.675 19.975 4.025C20.325 4.375 20.5 4.80257 20.5 5.3077V18.6923C20.5 19.1974 20.325 19.625 19.975 19.975C19.625 20.325 19.1974 20.5 18.6923 20.5H5.30772ZM5.30772 19H11.25V4.99998H5.30772C5.23079 4.99998 5.16026 5.03203 5.09615 5.09613C5.03205 5.16024 5 5.23077 5 5.3077V18.6923C5 18.7692 5.03205 18.8397 5.09615 18.9038C5.16026 18.9679 5.23079 19 5.30772 19ZM12.75 19H18.6923C18.7692 19 18.8397 18.9679 18.9038 18.9038C18.9679 18.8397 19 18.7692 19 18.6923V12H12.75V19ZM12.75 10.5H19V5.3077C19 5.23077 18.9679 5.16024 18.9038 5.09613C18.8397 5.03203 18.7692 4.99998 18.6923 4.99998H12.75V10.5Z", fill: "currentColor" }), "IconSpaceDashboardOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconSpaceDashboardOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsSpaceDashboard` instead.");
}
export default IconSpaceDashboardOutlined;
//# sourceMappingURL=IconSpaceDashboardOutlined.js.map