/**
 * React component for an SVG icon of a diagonally positioned wrench.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsBuild` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsBuild.mjs`.
 */
declare const IconBuilderOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconBuilderOutlined;
