import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import Box from "@mui/material/Box";
import ClickAwayListener from "@mui/material/ClickAwayListener";
import Fade from "@mui/material/Fade";
import Paper from "@mui/material/Paper";
import Popper from "@mui/material/Popper";
import { styled } from "@mui/material/styles";
import { useCallback, useState } from "react";
/**
 * React component for a popper with an optional arrow, implementing the
 * Material UI React component
 * [`Popper`](https://mui.com/material-ui/api/popper).
 * @param props Props.
 * @returns React node.
 */
export default function PopperWithArrow({ arrow, children, modifiers, onClose, placement = "bottom", ...props }) {
    const [arrowElement, setArrowElement] = useState(null);
    const onClickAway = useCallback(() => {
        onClose();
    }, [onClose]);
    return (_jsx(Container, { ...props, placement: placement, transition: true, modifiers: [
            {
                name: "offset",
                enabled: arrow,
                options: {
                    offset: [0, 8],
                },
            },
            {
                name: "preventOverflow",
                enabled: true,
                options: {
                    altAxis: true,
                    altBoundary: true,
                    tether: true,
                    rootBoundary: "document",
                    padding: 8,
                },
            },
            ...(modifiers ?? []),
            {
                name: "arrow",
                enabled: arrow,
                options: {
                    element: arrowElement,
                },
            },
        ], children: ({ TransitionProps }) => (_jsx(Fade, { ...TransitionProps, children: _jsx(Box, { display: "contents", children: _jsx(ClickAwayListener, { onClickAway: onClickAway, children: _jsxs(Paper, { sx: { boxShadow: "none" }, children: [_jsx("span", { ref: setArrowElement, className: `arrow ${arrow ? "visible" : "hidden"}` }), children] }) }) }) })) }));
}
const Container = styled(Popper)(({ placement, theme }) => ({
    zIndex: 1000,
    borderRadius: 4,
    boxShadow: "0 5px 5px -3px rgb(0 0 0 / 20%), 0 8px 10px 1px rgb(0 0 0 / 14%), 0 3px 14px 2px rgb(0 0 0 / 12%)",
    "& .arrow": {
        position: "absolute",
        width: 10,
        height: 10,
        ...(placement === "bottom"
            ? { top: -5 }
            : placement === "left"
                ? { right: -5 }
                : placement === "right"
                    ? { left: -5 }
                    : placement === "top"
                        ? { bottom: -5 }
                        : {}),
        "&::before": {
            position: "absolute",
            width: 10,
            height: 10,
            background: theme.vars.palette.background.paper,
            content: '""',
            transform: "rotate(45deg)",
        },
        "&.visible": {
            visibility: "visible",
        },
        "&.hidden": {
            visibility: "hidden",
        },
    },
}));
//# sourceMappingURL=PopperWithArrow.js.map