/**
 * React component for an SVG icon of a checklist with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsChecklist` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsChecklist.mjs`.
 */
declare const IconChecklistOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconChecklistOutlined;
