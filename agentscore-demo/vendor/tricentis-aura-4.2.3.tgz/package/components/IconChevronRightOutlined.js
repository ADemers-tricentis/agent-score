import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of right-pointing arrow head, greater than,
 * right, wast or right chevron with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsChevronRight` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsChevronRight.mjs`.
 */
const IconChevronRightOutlined = createSvgIcon(_jsx("path", { d: "M13.2798 12.0023L9.20677 7.92921C9.0683 7.79076 8.99747 7.61672 8.99427 7.40711C8.99105 7.19751 9.06188 7.02027 9.20677 6.87541C9.35163 6.73052 9.52727 6.65808 9.73367 6.65808C9.94007 6.65808 10.1157 6.73052 10.2606 6.87541L14.7548 11.3696C14.8484 11.4632 14.9144 11.5619 14.9529 11.6658C14.9913 11.7696 15.0106 11.8818 15.0106 12.0023C15.0106 12.1228 14.9913 12.235 14.9529 12.3388C14.9144 12.4427 14.8484 12.5414 14.7548 12.635L10.2606 17.1292C10.1221 17.2677 9.94808 17.3385 9.73847 17.3417C9.52887 17.3449 9.35163 17.2741 9.20677 17.1292C9.06188 16.9843 8.98944 16.8087 8.98944 16.6023C8.98944 16.3959 9.06188 16.2203 9.20677 16.0754L13.2798 12.0023Z", fill: "currentColor" }), "IconChevronRightOutlined");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconChevronRightOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsChevronRight` instead.");
}
export default IconChevronRightOutlined;
//# sourceMappingURL=IconChevronRightOutlined.js.map