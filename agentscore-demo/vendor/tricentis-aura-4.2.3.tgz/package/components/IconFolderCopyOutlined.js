import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a folder-copy with an outlined style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFolderCopy` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFolderCopy.mjs`.
 */
const IconFolderCopyOutlined = createSvgIcon(_jsx("path", { d: "M3.30773 20.9423C2.80901 20.9423 2.38305 20.7657 2.02985 20.4125C1.67662 20.0593 1.5 19.6333 1.5 19.1346V7.09621H3V19.1346C3 19.2244 3.02885 19.2981 3.08655 19.3558C3.14425 19.4135 3.21798 19.4423 3.30773 19.4423H19.5V20.9423H3.30773ZM6.80768 17.4423C6.30896 17.4423 5.883 17.2657 5.5298 16.9125C5.1766 16.5593 5 16.1334 5 15.6346V4.86544C5 4.36672 5.1766 3.94076 5.5298 3.58756C5.883 3.23435 6.30896 3.05774 6.80768 3.05774H11.7885L13.7885 5.05774H20.6923C21.191 5.05774 21.617 5.23435 21.9702 5.58756C22.3234 5.94076 22.5 6.36672 22.5 6.86544V15.6346C22.5 16.1334 22.3234 16.5593 21.9702 16.9125C21.617 17.2657 21.191 17.4423 20.6923 17.4423H6.80768ZM6.80768 15.9424H20.6923C20.782 15.9424 20.8558 15.9135 20.9135 15.8558C20.9712 15.7981 21 15.7244 21 15.6346V6.86544C21 6.77569 20.9712 6.70196 20.9135 6.64426C20.8558 6.58656 20.782 6.55771 20.6923 6.55771H13.175L11.175 4.55771H6.80768C6.71793 4.55771 6.6442 4.58656 6.5865 4.64426C6.52882 4.70196 6.49997 4.77569 6.49997 4.86544V15.6346C6.49997 15.7244 6.52882 15.7981 6.5865 15.8558C6.6442 15.9135 6.71793 15.9424 6.80768 15.9424Z", fill: "currentColor" }), "IconFolderCopyOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconFolderCopyOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFolderCopy` instead.");
}
export default IconFolderCopyOutlined;
//# sourceMappingURL=IconFolderCopyOutlined.js.map