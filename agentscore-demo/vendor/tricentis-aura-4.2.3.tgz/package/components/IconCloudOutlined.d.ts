/**
 * React component for an SVG icon of a cloud symbol with outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCloud` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCloud.mjs`.
 */
declare const IconCloudOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCloudOutlined;
