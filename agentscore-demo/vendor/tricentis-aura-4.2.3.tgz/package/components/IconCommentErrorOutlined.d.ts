/**
 * React component for an SVG icon of an exclamation mark centered within a
 * comment with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFeedback` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFeedback.mjs`.
 */
declare const IconCommentErrorOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCommentErrorOutlined;
