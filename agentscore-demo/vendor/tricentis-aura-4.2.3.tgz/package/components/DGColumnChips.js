import { jsx as _jsx } from "react/jsx-runtime";
import { gridDensitySelector, useGridApiContext, useGridSelector, } from "@mui/x-data-grid-pro";
import { useMemo } from "react";
import ChipGroup from "./ChipGroup.js";
/**
 * React component for rendering a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) cell as a chip
 * group using the Aura React component {@linkcode ChipGroup}. An array cell
 * value renders as a chip for each array item, otherwise a truthy cell value
 * renders as a single chip, or else the cell is rendered empty. For use with
 * the grid column definition option
 * [`renderCell`](https://mui.com/x/api/data-grid/grid-col-def/#properties).
 * @param props Props.
 * @returns React node.
 */
export default function DGColumnChips({ chipProps, displayValue, onClick, onDelete, sx, value, variant, }) {
    const gridApiContext = useGridApiContext();
    const gridDensityValue = useGridSelector(gridApiContext, gridDensitySelector);
    const chipValues = useMemo(() => (Array.isArray(value) ? value : value ? [value] : []), [value]);
    return chipValues.length ? (_jsx(ChipGroup, { chips: chipValues.map((chipValue) => ({
            label: displayValue ? displayValue(chipValue) : String(chipValue),
            onClick: onClick &&
                (() => {
                    onClick(chipValue);
                }),
            onDelete: onDelete &&
                (() => {
                    onDelete(chipValue);
                }),
            variant: typeof variant === "function" ? variant(chipValue) : variant,
            ...(typeof chipProps === "function" ? chipProps(chipValue) : {}),
        })), multiline: gridDensityValue === "comfortable", plusSx: {
            backgroundColor: "transparent",
        }, sx: sx })) : null;
}
//# sourceMappingURL=DGColumnChips.js.map