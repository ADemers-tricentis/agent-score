import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/** React component for an SVG icon of a Tosca Commander HTML control */
const IconHtmlLinkOutlined = createSvgIcon(_jsx("path", { d: "M14.9 16.1L12.2 18.8C11.3 19.7 10.2 20.1 9 20.1C7.7 20.1 6.7 19.7 5.8 18.8C4.9 17.9 4.5 16.8 4.5 15.6C4.5 14.3 4.9 13.3 5.8 12.4L8.5 9.7L9.6 10.8L6.9 13.5C6.3 14.1 6 14.8 6 15.6C6 16.4 6.3 17.2 6.9 17.7C7.5 18.2 8.2 18.6 9 18.6C9.8 18.6 10.6 18.3 11.1 17.7L13.8 15L14.9 16.1ZM10.4 15.2L9.3 14.1L14.6 8.8L15.7 9.9L10.4 15.2ZM16.6 14.4L15.5 13.3L18.2 10.6C18.8 10 19.1 9.3 19.1 8.5C19.1 7.7 18.8 6.9 18.2 6.4C17.6 5.9 16.9 5.5 16.1 5.5C15.3 5.5 14.5 5.8 14 6.4L11.3 9.1L10.2 8L12.9 5.3C13.8 4.4 14.9 4 16.1 4C17.4 4 18.4 4.4 19.3 5.3C20.2 6.2 20.6 7.3 20.6 8.5C20.6 9.8 20.2 10.8 19.3 11.7L16.6 14.4Z", fill: "currentColor" }), "IconHtmlLinkOutlined");
export default IconHtmlLinkOutlined;
//# sourceMappingURL=IconHtmlLinkOutlined.js.map