import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of a custom-built menu item with an outlined
 * style.
 */
const IconWindowTextOutlined = createSvgIcon(_jsx("path", { d: "M5.31 20.5C4.8 20.5 4.38 20.32 4.03 19.97C3.68 19.62 3.5 19.19 3.5 18.69V5.31C3.5 4.8 3.68 4.38 4.03 4.03C4.38 3.68 4.81 3.5 5.31 3.5H18.69C19.2 3.5 19.62 3.68 19.97 4.03C20.32 4.38 20.5 4.81 20.5 5.31V18.69C20.5 19.2 20.32 19.62 19.97 19.97C19.62 20.32 19.19 20.5 18.69 20.5H5.31ZM5.31 19H18.69C18.77 19 18.84 18.97 18.9 18.9C18.96 18.84 19 18.77 19 18.69V8.07H5V18.69C5 18.77 5.03 18.84 5.1 18.9C5.16 18.96 5.23 19 5.31 19ZM6.81 5.03H5V6.84H6.81V5.03ZM12.9 5.03H11.09V6.84H12.9V5.03ZM19 5.03H17.19V6.84H19V5.03ZM7.6 12.54H16.4V11.04H7.6V12.54ZM7.6 16.04H16.4V14.54H7.6V16.04Z", fill: "currentColor" }), "IconWindowTextOutlined");
export default IconWindowTextOutlined;
//# sourceMappingURL=IconWindowTextOutlined.js.map