/**
 * React component for an SVG icon of a chevron pointing upward with an outlined
 * style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsKeyboardArrowUp` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsKeyboardArrowUp.mjs`.
 */
declare const IconChevronUpOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconChevronUpOutlined;
