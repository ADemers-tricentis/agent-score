import type { GridRowModel } from "@mui/x-data-grid-pro";
/**
 * React component for rendering a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) cell as an
 * empty or filled star icon representing the favorited status derived from the
 * cell value truthiness, that when the prop `onClick` is populated, can be
 * toggled by clicking the star icon. For use with the grid column definition
 * option
 * [`renderCell`](https://mui.com/x/api/data-grid/grid-col-def/#properties).
 * @param props Props.
 * @returns React node.
 */
export default function DGColumnFavorite<Row extends GridRowModel>({ onClick, row, value, }: {
    /**
     * Callback invoked when the star icon is clicked. Populating this prop causes
     * the star icon to render within an icon button.
     */
    onClick?: (event: {
        /** Is the favorited status now active. */
        isActive: boolean;
        /** Data grid row model. */
        row: Row;
    }) => void;
    /** Data grid row model. */
    row: Row;
    /** Data grid cell value. */
    value: boolean | null | undefined;
}): import("react/jsx-runtime").JSX.Element;
