import type { SwitchProps } from "@mui/material/Switch";
import type { GridRowId, GridRowModel } from "@mui/x-data-grid-pro";
/**
 * React component for rendering a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) cell as a
 * switch, with the boolean status derived from the cell value truthiness. If
 * the data grid row ID starts with `auto-generated-row-null` then the row is
 * considered auto-generated and the cell is rendered empty. For use with the
 * grid column definition option
 * [`renderCell`](https://mui.com/x/api/data-grid/grid-col-def/#properties).
 * @param props Props.
 * @returns React node.
 */
export default function DGColumnSwitch<Row extends GridRowModel>({ id, onChangeHandler, onChangeHandlerError, row, switchProps, value, }: {
    /** Data grid row ID. */
    id: GridRowId;
    /** Callback invoked when the switch changes. */
    onChangeHandler?: (
    /** Data grid row model. */
    row: Row, 
    /** Is the switch now checked. */
    checked: boolean) => Promise<void>;
    /** Callback invoked when the prop `onChangeHandler` callback rejects. */
    onChangeHandlerError?: (
    /** The rejection error. */
    error: unknown, 
    /** Data grid row model. */
    row: Row) => void;
    /** Data grid row model. */
    row: Row;
    /**
     * Props applied to the Material UI component
     * [`Switch`](https://mui.com/material-ui/api/switch).
     */
    switchProps?: SwitchProps;
    /** Data grid cell value. */
    value: boolean | null | undefined;
}): import("react/jsx-runtime").JSX.Element | null;
