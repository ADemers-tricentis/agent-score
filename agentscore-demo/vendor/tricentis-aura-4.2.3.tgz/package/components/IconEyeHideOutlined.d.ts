/**
 * React component for an SVG icon of an open eye slashed by a diagonal line
 * with outlined style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsVisibilityOff` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsVisibilityOff.mjs`.
 */
declare const IconEyeHideOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconEyeHideOutlined;
