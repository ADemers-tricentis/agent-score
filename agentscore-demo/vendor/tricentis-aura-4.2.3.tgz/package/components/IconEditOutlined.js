import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of a pencil or pen with an outlined style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsEdit` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsEdit.mjs`.
 */
const IconEditOutlined = createSvgIcon(_jsx("path", { d: "M4.61488 19.3766H5.92425L15.7294 9.5715L14.42 8.26211L4.61488 18.0672V19.3766ZM19.1259 8.42301L15.5522 4.88185L16.9328 3.50123C17.2437 3.19035 17.6218 3.03491 18.067 3.03491C18.5123 3.03491 18.8904 3.19035 19.2013 3.50123L20.4903 4.7902C20.8011 5.10108 20.962 5.47373 20.9729 5.90814C20.9837 6.34256 20.8337 6.7152 20.5228 7.02608L19.1259 8.42301ZM17.9774 9.58778L6.6003 20.9649H3.02658V17.3912L14.4037 6.01403L17.9774 9.58778ZM15.0696 8.91172L14.42 8.26211L15.7294 9.5715L15.0696 8.91172Z", fill: "currentColor" }), "IconEditOutlined");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconEditOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsEdit` instead.");
}
export default IconEditOutlined;
//# sourceMappingURL=IconEditOutlined.js.map