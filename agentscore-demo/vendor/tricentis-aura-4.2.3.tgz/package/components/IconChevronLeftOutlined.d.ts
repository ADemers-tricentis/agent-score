/**
 * React component for an SVG icon of left-pointing arrow head, less than,
 * left, west or left chevron with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsChevronLeft` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsChevronLeft.mjs`.
 */
declare const IconChevronLeftOutlined: import("@mui/material/OverridableComponent.js").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconChevronLeftOutlined;
