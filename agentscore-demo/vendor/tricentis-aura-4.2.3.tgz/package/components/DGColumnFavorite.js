import { jsx as _jsx } from "react/jsx-runtime";
import Box from "@mui/material/Box";
import IconButton, {} from "@mui/material/IconButton";
import IconMaterialSymbolsStarRate from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsStarRate.mjs";
import { useCallback, useMemo, useState } from "react";
/**
 * React component for rendering a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) cell as an
 * empty or filled star icon representing the favorited status derived from the
 * cell value truthiness, that when the prop `onClick` is populated, can be
 * toggled by clicking the star icon. For use with the grid column definition
 * option
 * [`renderCell`](https://mui.com/x/api/data-grid/grid-col-def/#properties).
 * @param props Props.
 * @returns React node.
 */
export default function DGColumnFavorite({ onClick, row, value, }) {
    const [isActive, setActive] = useState(Boolean(value));
    const icon = useMemo(() => isActive ? (_jsx(IconMaterialSymbolsStarRate, { color: "primary" })) : (_jsx(IconMaterialSymbolsStarRate, {})), [isActive]);
    const onClickIconButton = useCallback((event) => {
        event.stopPropagation();
        setActive(!isActive);
        onClick?.({
            isActive: !isActive,
            row,
        });
    }, [isActive, onClick, row]);
    return (_jsx(Box, { display: "inline-block", alignItems: "center", justifyContent: "center", color: "action.active", children: onClick ? (_jsx(IconButton, { "data-testid": "dgc-iconbutton-favorite", onClick: onClickIconButton, size: "small", children: icon })) : (icon) }));
}
//# sourceMappingURL=DGColumnFavorite.js.map