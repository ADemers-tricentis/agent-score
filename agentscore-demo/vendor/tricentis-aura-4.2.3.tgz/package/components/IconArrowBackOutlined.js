import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of a left-pointing arrow with an outlined
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsArrowBack` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowBack.mjs`.
 */
const IconArrowBackOutlined = createSvgIcon(_jsx("path", { d: "M7.37302 12.75L13.0692 18.4461L12 19.5L4.5 12L12 4.5L13.0692 5.55383L7.37302 11.25H19.5V12.75H7.37302Z", fill: "currentColor" }), "IconArrowBackOutlined");
export default IconArrowBackOutlined;
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconArrowBackOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsArrowBack` instead.");
}
//# sourceMappingURL=IconArrowBackOutlined.js.map