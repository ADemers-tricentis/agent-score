/**
 * React component for an SVG icon of a decision node with an inward rotation
 * and an outlined style
 */
declare const IconDecisionNodeRotateInwardOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDecisionNodeRotateInwardOutlined;
