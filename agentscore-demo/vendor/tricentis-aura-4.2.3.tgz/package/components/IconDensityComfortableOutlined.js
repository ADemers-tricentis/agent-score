import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of two vertically stacked boxes.  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDensityLarge` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDensityLarge.mjs`.
 */
const IconDensityComfortableOutlined = createSvgIcon(_jsx("path", { d: "M3.79412 20.5C3.56912 20.5 3.38052 20.428 3.22831 20.2842C3.0761 20.1404 3 19.9622 3 19.7496C3 19.537 3.0761 19.3589 3.22831 19.2154C3.38052 19.0718 3.56912 19 3.79412 19H20.2059C20.4309 19 20.6195 19.0719 20.7717 19.2157C20.9239 19.3595 21 19.5377 21 19.7503C21 19.9629 20.9239 20.141 20.7717 20.2846C20.6195 20.4282 20.4309 20.5 20.2059 20.5H3.79412ZM3.79412 4.99998C3.56912 4.99998 3.38052 4.92807 3.22831 4.78425C3.0761 4.64045 3 4.46225 3 4.24965C3 4.03707 3.0761 3.85898 3.22831 3.7154C3.38052 3.5718 3.56912 3.5 3.79412 3.5H20.2059C20.4309 3.5 20.6195 3.57191 20.7717 3.71573C20.9239 3.85954 21 4.03774 21 4.25033C21 4.46293 20.9239 4.64102 20.7717 4.7846C20.6195 4.92818 20.4309 4.99998 20.2059 4.99998H3.79412Z", fill: "currentColor" }), "IconDensityComfortableOutlined");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconDensityComfortableOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsDensityLarge` instead.");
}
export default IconDensityComfortableOutlined;
//# sourceMappingURL=IconDensityComfortableOutlined.js.map