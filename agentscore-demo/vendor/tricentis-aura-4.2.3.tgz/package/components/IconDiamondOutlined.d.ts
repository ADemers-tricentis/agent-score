/**
 * React component for an SVG icon of a square rotated 45 degrees with an
 * outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsStat0` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsStat0.mjs`.
 */
declare const IconDiamondOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDiamondOutlined;
