/**
 * React component for an SVG icon of a book with outline outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsBook` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsBook.mjs`.
 */
declare const IconBookOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconBookOutlined;
