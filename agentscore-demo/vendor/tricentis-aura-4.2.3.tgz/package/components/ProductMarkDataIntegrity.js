import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// ignore unused exports
import { styled } from "@mui/material/styles";
/**
 * React component for the Tricentis Data Integrity product mark.
 * @param props Props.
 * @returns React node.
 */
export default function ProductMarkDataIntegrity({ sx, }) {
    return (_jsxs(Svg, { viewBox: "0 0 24 24", className: "ProductMarkDataIntegrity", "data-testid": "ProductMarkDataIntegrity", sx: sx, children: [_jsx("path", { className: "ProductMarkDataIntegrity-background", d: "M0 4a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v16a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4Z" }), _jsx("path", { className: "ProductMarkDataIntegrity-text", d: "M15.359 16.5V7.448h2.027V16.5h-2.027Zm-9.115 0V7.448H9.33c1.275 0 2.363.442 3.264 1.326.9.884 1.351 1.95 1.351 3.2 0 1.25-.45 2.316-1.351 3.2-.901.884-1.99 1.326-3.264 1.326H6.244Zm2.028-1.861H9.33c.748 0 1.36-.255 1.836-.765.484-.519.727-1.152.727-1.9s-.243-1.377-.727-1.887c-.476-.519-1.088-.778-1.836-.778H8.272v5.33Z" })] }));
}
const Svg = styled("svg")(({ theme }) => ({
    "&.ProductMarkDataIntegrity": {
        "& .ProductMarkDataIntegrity-background": {
            fill: theme.vars.palette.aura.brand,
        },
        "& .ProductMarkDataIntegrity-text": {
            fill: theme.vars.palette.aura.brandInverted,
        },
    },
}));
//# sourceMappingURL=ProductMarkDataIntegrity.js.map