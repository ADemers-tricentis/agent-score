/**
 * React component for an SVG icon of a copy content symbol with outline style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsContentCopy` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsContentCopy.mjs`.
 */
declare const IconContentCopyOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconContentCopyOutlined;
