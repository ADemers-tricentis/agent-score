/** React component for an SVG icon of a chevron down up with outlined style. */
declare const IconChevronDownUpOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconChevronDownUpOutlined;
