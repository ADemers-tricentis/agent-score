import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a clock with three lines to the left.  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAcute` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAcute.mjs`.
 */
const IconLastModifiedOutlined = createSvgIcon(_jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M15.4 17.9C18.6585 17.9 21.3 15.2585 21.3 12C21.3 8.74152 18.6585 6.1 15.4 6.1C12.1415 6.1 9.49998 8.74152 9.49998 12C9.49998 15.2585 12.1415 17.9 15.4 17.9ZM15.4 19.5C19.5421 19.5 22.9 16.1421 22.9 12C22.9 7.85786 19.5421 4.5 15.4 4.5C11.2578 4.5 7.89998 7.85786 7.89998 12C7.89998 16.1421 11.2578 19.5 15.4 19.5ZM15.2 8.00005C15.6418 8.00005 16 8.35822 16 8.80005V11.9687L18.2657 14.2344C18.5781 14.5468 18.5781 15.0533 18.2657 15.3657C17.9533 15.6782 17.4467 15.6782 17.1343 15.3657L14.6343 12.8657L14.4 12.6314V12.3V8.80005C14.4 8.35822 14.7582 8.00005 15.2 8.00005ZM2.89998 7.7C2.45815 7.7 2.09998 8.05817 2.09998 8.5C2.09998 8.94183 2.45815 9.3 2.89998 9.3H5.89998C6.3418 9.3 6.69998 8.94183 6.69998 8.5C6.69998 8.05817 6.3418 7.7 5.89998 7.7H2.89998ZM2.09998 16.5C2.09998 16.0582 2.45815 15.7 2.89998 15.7H5.89998C6.3418 15.7 6.69998 16.0582 6.69998 16.5C6.69998 16.9418 6.3418 17.3 5.89998 17.3H2.89998C2.45815 17.3 2.09998 16.9418 2.09998 16.5ZM1.89998 11.7C1.45815 11.7 1.09998 12.0582 1.09998 12.5C1.09998 12.9418 1.45815 13.3 1.89998 13.3H5.89998C6.3418 13.3 6.69998 12.9418 6.69998 12.5C6.69998 12.0582 6.3418 11.7 5.89998 11.7H1.89998Z", fill: "currentColor" }), "IconLastModifiedOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconLastModifiedOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsAcute` instead.");
}
export default IconLastModifiedOutlined;
//# sourceMappingURL=IconLastModifiedOutlined.js.map