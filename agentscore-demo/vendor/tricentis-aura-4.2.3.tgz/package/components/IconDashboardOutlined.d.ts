/**
 * React component for an SVG icon of four uneven rectangles nested in a square
 * with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDashboard` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDashboard.mjs`.
 */
declare const IconDashboardOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDashboardOutlined;
