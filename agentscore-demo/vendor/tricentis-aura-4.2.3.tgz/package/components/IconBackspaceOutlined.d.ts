/**
 * React component for an SVG icon of a rectangular shape with a curved
 * edge, a leftward arrow and an X mark within on the right side with an
 * outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsBackspace` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsBackspace.mjs`.
 */
declare const IconBackspaceOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconBackspaceOutlined;
