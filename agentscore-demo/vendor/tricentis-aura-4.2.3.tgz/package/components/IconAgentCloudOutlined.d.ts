/**
 * React component for an SVG icon of a cloud on top of a bench with an outlined
 * style.
 */
declare const IconAgentCloudOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAgentCloudOutlined;
