import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a checkbox in an indeterminate
 * state with filled style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsIndeterminateCheckBox` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsIndeterminateCheckBox.mjs`.
 */
const IconCheckBoxIndeterminateFilled = createSvgIcon(_jsx("path", { d: "M8.49998 13.25H16.5C16.7128 13.25 16.891 13.1782 17.0346 13.0346C17.1782 12.891 17.25 12.7128 17.25 12.5C17.25 12.2872 17.1782 12.109 17.0346 11.9654C16.891 11.8218 16.7128 11.75 16.5 11.75H8.49998C8.28716 11.75 8.10896 11.8218 7.96538 11.9654C7.82179 12.109 7.75 12.2872 7.75 12.5C7.75 12.7128 7.82179 12.891 7.96538 13.0346C8.10896 13.1782 8.28716 13.25 8.49998 13.25ZM5.8077 21C5.30257 21 4.875 20.825 4.525 20.475C4.175 20.125 4 19.6974 4 19.1923V5.8077C4 5.30257 4.175 4.875 4.525 4.525C4.875 4.175 5.30257 4 5.8077 4H19.1923C19.6974 4 20.125 4.175 20.475 4.525C20.825 4.875 21 5.30257 21 5.8077V19.1923C21 19.6974 20.825 20.125 20.475 20.475C20.125 20.825 19.6974 21 19.1923 21H5.8077Z", fill: "currentColor" }), "IconCheckBoxIndeterminateFilled");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconCheckBoxIndeterminateFilled` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsIndeterminateCheckBox` instead.");
}
export default IconCheckBoxIndeterminateFilled;
//# sourceMappingURL=IconCheckBoxIndeterminateFilled.js.map