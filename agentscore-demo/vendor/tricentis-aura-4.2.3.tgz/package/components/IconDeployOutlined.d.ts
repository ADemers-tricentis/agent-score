/**
 * React component for an SVG icon of an arrow pointing up from a isometric
 * box.
 */
declare const IconDeployOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDeployOutlined;
