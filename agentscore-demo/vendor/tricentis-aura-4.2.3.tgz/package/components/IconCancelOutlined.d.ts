/**
 * React component for an SVG icon of a cancel, fail, x, close symbol with
 * outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCancel` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCancel.mjs`.
 */
declare const IconCancelOutlined: import("@mui/material/OverridableComponent.js").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCancelOutlined;
