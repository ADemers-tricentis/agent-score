import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a chevron pointing upward with an outlined
 * style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsKeyboardArrowUp` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsKeyboardArrowUp.mjs`.
 */
const IconChevronUpOutlined = createSvgIcon(_jsx("path", { d: "M12.0023 10.7202L7.92921 14.7933C7.79076 14.9318 7.61672 15.0026 7.40711 15.0058C7.19751 15.009 7.02027 14.9382 6.87541 14.7933C6.73052 14.6484 6.65808 14.4728 6.65808 14.2664C6.65808 14.06 6.73052 13.8843 6.87541 13.7395L11.3696 9.24525C11.4632 9.15167 11.5619 9.08564 11.6658 9.04718C11.7696 9.00873 11.8818 8.9895 12.0023 8.9895C12.1228 8.9895 12.235 9.00873 12.3388 9.04718C12.4427 9.08564 12.5414 9.15167 12.635 9.24525L17.1292 13.7395C17.2677 13.8779 17.3385 14.052 17.3417 14.2616C17.3449 14.4712 17.2741 14.6484 17.1292 14.7933C16.9843 14.9382 16.8087 15.0106 16.6023 15.0106C16.3959 15.0106 16.2203 14.9382 16.0754 14.7933L12.0023 10.7202Z", fill: "currentColor" }), "IconChevronUpOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconChevronUpOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsKeyboardArrowUp` instead.");
}
export default IconChevronUpOutlined;
//# sourceMappingURL=IconChevronUpOutlined.js.map