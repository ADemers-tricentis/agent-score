import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a geometric arrangement of two squares
 * with an outlined style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsLayers` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsLayers.mjs`.
 */
const IconLayersOutlined = createSvgIcon(_jsx("path", { d: "M12 19.896L3.80775 13.5306L5.03465 12.5883L12 17.9806L18.9654 12.5883L20.1923 13.5306L12 19.896ZM12 15.4614L3.80775 9.09604L12 2.73071L20.1923 9.09604L12 15.4614ZM12 13.546L17.75 9.09604L12 4.64604L6.25 9.09604L12 13.546Z", fill: "currentColor" }), "IconLayersOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconLayersOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsLayers` instead.");
}
export default IconLayersOutlined;
//# sourceMappingURL=IconLayersOutlined.js.map