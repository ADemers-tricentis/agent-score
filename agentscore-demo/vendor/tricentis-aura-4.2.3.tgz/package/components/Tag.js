import { jsx as _jsx } from "react/jsx-runtime";
import Chip from "@mui/material/Chip";
import { styled } from "@mui/material/styles";
import IconMaterialSymbolsClose from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsClose.mjs";
import { forwardRef } from "react";
/**
 * React component for a customized Material UI component
 * [`Chip`](https://mui.com/material-ui/api/chip) with rounded corners.
 * Tags represent a set of interactive, clickable keywords that help label,
 * organize, and categorize objects.
 * @param props Props.
 * @returns React node.
 */
const Tag = forwardRef(({ ...props }, forwardedRef) => (_jsx(RoundedCornersTag, { ref: forwardedRef, size: "small", deleteIcon: _jsx(IconMaterialSymbolsClose, {}), ...props })));
const RoundedCornersTag = styled(Chip)(({ theme }) => ({
    borderRadius: theme.aura.borderRadius.xs,
    backgroundColor: theme.vars.palette.aura.backgroundDefault,
    color: theme.vars.palette.text.primary,
    // hovered state
    "&:hover, &.Mui-hovered": {
        backgroundColor: theme.vars.palette.action.hover,
        color: theme.vars.palette.text.primary,
        "& .MuiChip-deleteIcon": {
            color: theme.vars.palette.secondary.dark,
        },
    },
    // focused state
    "&.Mui-focusVisible": {
        border: `1px solid ${theme.vars.palette.primary.light}`,
    },
    // Disabled state
    "&.Mui-disabled": {
        backgroundColor: theme.vars.palette.action.disabledBackground,
        color: theme.vars.palette.text.disabled,
    },
}));
export default Tag;
//# sourceMappingURL=Tag.js.map