/**
 * React component for an SVG icon of two vertically stacked boxes.  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDensityLarge` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDensityLarge.mjs`.
 */
declare const IconDensityComfortableOutlined: import("@mui/material/OverridableComponent.js").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDensityComfortableOutlined;
