import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of italic text with outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFormatItalic` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFormatItalic.mjs`.
 */
const IconFormatItalicOutlined = createSvgIcon(_jsx("path", { d: "M5.39429 18.625V16.8173H9.21159L12.452 7.18265H8.63469V5.375H17.7885V7.18265H14.2789L11.0385 16.8173H14.5481V18.625H5.39429Z", fill: "currentColor" }), "IconFormatItalicOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconFormatItalicOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFormatItalic` instead.");
}
export default IconFormatItalicOutlined;
//# sourceMappingURL=IconFormatItalicOutlined.js.map