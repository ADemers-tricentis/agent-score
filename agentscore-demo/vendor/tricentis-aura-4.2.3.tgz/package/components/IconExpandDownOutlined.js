import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of a downward-pointing arrow in a square
 * with an outlined style.
 */
const IconExpandDownOutlined = createSvgIcon(_jsx("path", { d: "M5.31 20.5C4.8 20.5 4.38 20.32 4.03 19.97C3.68 19.62 3.5 19.19 3.5 18.69V5.31C3.5 4.8 3.68 4.38 4.03 4.03C4.38 3.68 4.81 3.5 5.31 3.5H18.69C19.2 3.5 19.62 3.68 19.97 4.03C20.32 4.38 20.5 4.81 20.5 5.31V18.69C20.5 19.2 20.32 19.62 19.97 19.97C19.62 20.32 19.19 20.5 18.69 20.5H5.31ZM5.31 19H18.69C18.77 19 18.84 18.97 18.9 18.9C18.96 18.84 19 18.77 19 18.69V5.31C19 5.23 18.97 5.16 18.9 5.1C18.84 5.04 18.77 5 18.69 5H5.31C5.23 5 5.16 5.03 5.1 5.1C5.04 5.16 5 5.23 5 5.31V18.69C5 18.77 5.03 18.84 5.1 18.9C5.16 18.96 5.23 19 5.31 19ZM12 15.35L6.35 9.7L7.4 8.65L12 13.25L16.6 8.65L17.65 9.7L12 15.35Z", fill: "currentColor" }), "IconExpandDownOutlined");
export default IconExpandDownOutlined;
//# sourceMappingURL=IconExpandDownOutlined.js.map