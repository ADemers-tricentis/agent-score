/**
 * React component for an SVG icon of three horizontal lines with a code symbol
 * at the right side bottom corner with an outlined style.
 */
declare const IconAPIActionsOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAPIActionsOutlined;
