import type { GridRowModel } from "@mui/x-data-grid-pro";
import { type ComponentPropsWithoutRef } from "react";
import DGContextMenu from "./private/DGContextMenu.js";
/**
 * React component for rendering a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) cell that
 * contains an icon button to open a context menu. For use with the grid column
 * definition option
 * [`renderCell`](https://mui.com/x/api/data-grid/grid-col-def/#properties).
 * @param props Props.
 * @returns React node.
 */
export default function DGColumnContextMenuButton({ contextMenu, rowData, }: {
    /** Context menu items. */
    contextMenu: ComponentPropsWithoutRef<typeof DGContextMenu>["contextMenu"];
    /** Data grid row model. */
    rowData: GridRowModel;
}): import("react/jsx-runtime").JSX.Element;
