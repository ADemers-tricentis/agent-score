/**
 * React component for an SVG icon of a close, x symbol with outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsClose` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsClose.mjs`.
 */
declare const IconCloseOutlined: import("@mui/material/OverridableComponent.js").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCloseOutlined;
