import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of with two vertically
 * stacked rectangles, outlined with the top filled.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsSplitscreenTop` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsSplitscreenTop.mjs`.
 */
const IconSplitscreenTopOutlined = createSvgIcon(_jsx("path", { d: "M5.3077 10.8077C4.80257 10.8077 4.375 10.6327 4.025 10.2827C3.675 9.93266 3.5 9.50511 3.5 8.99999V5.61541C3.5 5.1103 3.675 4.68274 4.025 4.33274C4.375 3.98274 4.80257 3.80774 5.3077 3.80774H18.6923C19.1974 3.80774 19.625 3.98274 19.975 4.33274C20.325 4.68274 20.5 5.1103 20.5 5.61541V8.99999C20.5 9.50511 20.325 9.93266 19.975 10.2827C19.625 10.6327 19.1974 10.8077 18.6923 10.8077H5.3077ZM5.3077 20.1922C4.80257 20.1922 4.375 20.0172 4.025 19.6672C3.675 19.3172 3.5 18.8897 3.5 18.3846V15C3.5 14.4949 3.675 14.0673 4.025 13.7173C4.375 13.3673 4.80257 13.1923 5.3077 13.1923H18.6923C19.1974 13.1923 19.625 13.3673 19.975 13.7173C20.325 14.0673 20.5 14.4949 20.5 15V18.3846C20.5 18.8897 20.325 19.3172 19.975 19.6672C19.625 20.0172 19.1974 20.1922 18.6923 20.1922H5.3077ZM5.3077 18.6923H18.6923C18.7692 18.6923 18.8397 18.6602 18.9038 18.5961C18.9679 18.532 19 18.4615 19 18.3846V15C19 14.9231 18.9679 14.8525 18.9038 14.7884C18.8397 14.7243 18.7692 14.6923 18.6923 14.6923H5.3077C5.23077 14.6923 5.16024 14.7243 5.09612 14.7884C5.03202 14.8525 4.99997 14.9231 4.99997 15V18.3846C4.99997 18.4615 5.03202 18.532 5.09612 18.5961C5.16024 18.6602 5.23077 18.6923 5.3077 18.6923Z", fill: "currentColor" }), "IconSplitscreenTopOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconSplitscreenTopOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsSplitscreenTop` instead.");
}
export default IconSplitscreenTopOutlined;
//# sourceMappingURL=IconSplitscreenTopOutlined.js.map