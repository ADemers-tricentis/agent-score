/**
 * React component for an SVG icon of a cancel, fail, x, close symbol with
 * filled style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCancelFill` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCancelFill.mjs`.
 */
declare const IconCancelFilled: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCancelFilled;
