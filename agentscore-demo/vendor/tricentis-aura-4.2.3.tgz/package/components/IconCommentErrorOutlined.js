import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of an exclamation mark centered within a
 * comment with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFeedback` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFeedback.mjs`.
 */
const IconCommentErrorOutlined = createSvgIcon(_jsx("path", { d: "M11.25 11.4615H12.75V5.42301H11.25V11.4615ZM12 14.9422C12.232 14.9422 12.4247 14.8656 12.5779 14.7124C12.7311 14.5592 12.8077 14.3666 12.8077 14.1345C12.8077 13.9025 12.7311 13.7099 12.5779 13.5567C12.4247 13.4034 12.232 13.3268 12 13.3268C11.7679 13.3268 11.5753 13.4034 11.4221 13.5567C11.2689 13.7099 11.1923 13.9025 11.1923 14.1345C11.1923 14.3666 11.2689 14.5592 11.4221 14.7124C11.5753 14.8656 11.7679 14.9422 12 14.9422ZM2.5 21.2691V4.53841C2.5 4.03328 2.675 3.60571 3.025 3.25571C3.375 2.90571 3.80257 2.73071 4.3077 2.73071H19.6923C20.1974 2.73071 20.625 2.90571 20.975 3.25571C21.325 3.60571 21.5 4.03328 21.5 4.53841V15.923C21.5 16.4281 21.325 16.8557 20.975 17.2057C20.625 17.5557 20.1974 17.7307 19.6923 17.7307H6.03845L2.5 21.2691ZM3.99998 17.6461L5.41538 16.2307H19.6923C19.782 16.2307 19.8557 16.2018 19.9134 16.1441C19.9711 16.0864 20 16.0127 20 15.923V4.53841C20 4.44866 19.9711 4.37494 19.9134 4.31724C19.8557 4.25954 19.782 4.23069 19.6923 4.23069H4.3077C4.21795 4.23069 4.14423 4.25954 4.08653 4.31724C4.02883 4.37494 3.99998 4.44866 3.99998 4.53841V17.6461ZM3.99998 4.53841V4.23069V17.6461V4.53841Z", fill: "currentColor" }), "IconCommentErrorOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconCommentErrorOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFeedback` instead.");
}
export default IconCommentErrorOutlined;
//# sourceMappingURL=IconCommentErrorOutlined.js.map