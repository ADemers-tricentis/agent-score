import type { ChipProps } from "@mui/material/Chip";
/**
 * React component for rendering a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) cell as a chip
 * group using the Aura React component {@linkcode ChipGroup}. An array cell
 * value renders as a chip for each array item, otherwise a truthy cell value
 * renders as a single chip, or else the cell is rendered empty. For use with
 * the grid column definition option
 * [`renderCell`](https://mui.com/x/api/data-grid/grid-col-def/#properties).
 * @param props Props.
 * @returns React node.
 */
export default function DGColumnChips<ChipValue = unknown>({ chipProps, displayValue, onClick, onDelete, sx, value, variant, }: {
    /** Gets overriding chip props. */
    chipProps?: (
    /** Chip value. */
    value: ChipValue) => ChipProps;
    /** Renders the chip label. */
    displayValue?: (
    /** Chip value. */
    value: ChipValue) => string;
    /** Callback invoked when a chip is clicked. */
    onClick?: (
    /** Clicked chip value. */
    value: ChipValue) => void;
    /** Callback invoked when a chip is deleted. */
    onDelete?: (
    /** Deleted chip value. */
    value: ChipValue) => void;
    /**
     * [Material UI theme aware custom styles](https://mui.com/system/getting-started/the-sx-prop)
     * for the [Material UI](https://mui.com/material-ui) component
     * [`Chip`](https://mui.com/material-ui/api/chip).
     */
    sx?: ChipProps["sx"];
    /** Data grid cell value. */
    value: ChipValue | Array<ChipValue> | null | undefined;
    /** Chip variant. */
    variant?: ChipProps["variant"] | ((
    /** Chip value. */
    value: ChipValue) => ChipProps["variant"]);
}): import("react/jsx-runtime").JSX.Element | null;
