/**
 * React component for an SVG icon of a left-pointing arrow with an outlined
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsArrowBack` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowBack.mjs`.
 */
declare const IconArrowBackOutlined: import("@mui/material/OverridableComponent.js").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconArrowBackOutlined;
