import type { SxProps, Theme } from "@mui/material/styles";
import type { ReactNode } from "react";
/**
 * React component for a responsive layout.
 * @param props Props.
 * @returns React node.
 */
export default function DefaultContentLayout({ cardSx, children, contentSx, preset, }: {
    /**
     * [Material UI theme aware custom styles](https://mui.com/system/getting-started/the-sx-prop)
     * for the [Material UI](https://mui.com/material-ui) component
     * [`Card`](https://mui.com/material-ui/api/card) that contains everything.
     */
    cardSx?: SxProps<Theme>;
    /** Content to display. */
    children?: ReactNode;
    /**
     * [Material UI theme aware custom styles](https://mui.com/system/getting-started/the-sx-prop)
     * for the [Material UI](https://mui.com/material-ui) component
     * [`CardContent`](https://mui.com/material-ui/api/card-content) that contains
     * the children.
     */
    contentSx?: SxProps<Theme>;
    /** Layout preset for styles. */
    preset?: DefaultContentLayoutPreset;
}): import("react/jsx-runtime").JSX.Element;
/** Default content layout preset for styles. */
type DefaultContentLayoutPreset = {
    height: "initial" | "workspace" | "min-workspace";
};
export {};
