/**
 * React component for an SVG for a gear illustration.
 * @returns React node.
 */
export default function GraphicsSettings(): import("react/jsx-runtime").JSX.Element;
