import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of a 3D isometric box on top of a bench with
 * an outlined style.
 */
const IconAgentSimOutlined = createSvgIcon(_jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M8.419 3.337A1.3 1.3 0 0 0 7.7 4.5v4c0 .492.278.943.719 1.163l3 1.5a1.3 1.3 0 0 0 1.162 0l3-1.5A1.3 1.3 0 0 0 16.3 8.5v-4a1.3 1.3 0 0 0-.719-1.163l-3-1.5a1.3 1.3 0 0 0-1.162 0l-3 1.5Zm2.931 6.338V6.402L9 5.227V8.5l2.35 1.175ZM12 10Zm.65-.325L15 8.5V5.227l-2.35 1.175v3.273ZM12 3l2.273 1.137L12 5.273 9.727 4.137 12 3ZM3 13v-1.4h18V13h-3.3v2.3H19a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h1.3V13H7.7v2.3H9a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h1.3V13H3Zm2 3.7h4a.6.6 0 0 1 .6.6v3a.6.6 0 0 1-.6.6H5a.6.6 0 0 1-.6-.6v-3a.6.6 0 0 1 .6-.6Zm10 0h4a.6.6 0 0 1 .6.6v3a.6.6 0 0 1-.6.6h-4a.6.6 0 0 1-.6-.6v-3a.6.6 0 0 1 .6-.6Z", fill: "currentColor" }), "IconAgentSimOutlined");
export default IconAgentSimOutlined;
//# sourceMappingURL=IconAgentSimOutlined.js.map