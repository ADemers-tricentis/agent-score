/**
 * React component for an SVG icon of a custom Tosca Business Parameter symbol
 * representing a Table Chart in the Tosca Cloud with outlined style.
 */
declare const IconBusinessParameterOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconBusinessParameterOutlined;
