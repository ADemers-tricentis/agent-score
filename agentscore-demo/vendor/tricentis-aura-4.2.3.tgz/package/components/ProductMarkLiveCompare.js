import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { styled } from "@mui/material/styles";
/**
 * React component for the Tricentis LiveCompare product mark.
 * @param props Props.
 * @returns React node.
 */
export default function ProductMarkLiveCompare({ sx, }) {
    return (_jsxs(Svg, { viewBox: "0 0 24 24", className: "ProductMarkLiveCompare", "data-testid": "ProductMarkLiveCompare", sx: sx, children: [_jsx("path", { className: "ProductMarkLiveCompare-background", d: "M0 4a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v16a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4Z" }), _jsx("path", { className: "ProductMarkLiveCompare-text", d: "M15.377 16.653c-1.368 0-2.503-.45-3.404-1.351-.9-.901-1.351-2.01-1.351-3.328s.45-2.427 1.351-3.328c.901-.9 2.036-1.351 3.404-1.351 1.012 0 1.934.301 2.767.905.842.595 1.386 1.381 1.632 2.359H17.57a2.072 2.072 0 0 0-.892-.957c-.4-.23-.833-.344-1.3-.344-.816 0-1.475.26-1.977.778-.493.518-.74 1.164-.74 1.938 0 .773.247 1.42.74 1.938.502.518 1.16.778 1.976.778.468 0 .902-.11 1.301-.332.4-.23.697-.552.892-.969h2.206c-.246.978-.79 1.768-1.632 2.372a4.653 4.653 0 0 1-2.766.892ZM4.495 16.5V7.448h2.027v7.114h3.749V16.5H4.495Z" })] }));
}
const Svg = styled("svg")(({ theme }) => ({
    "&.ProductMarkLiveCompare": {
        "& .ProductMarkLiveCompare-background": {
            fill: theme.vars.palette.aura.brand,
        },
        "& .ProductMarkLiveCompare-text": {
            fill: theme.vars.palette.aura.brandInverted,
        },
    },
}));
//# sourceMappingURL=ProductMarkLiveCompare.js.map