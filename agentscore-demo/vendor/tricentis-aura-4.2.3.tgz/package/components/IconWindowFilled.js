import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of two vertically stacked rectangles with
 * the first rectangle with a filled style and the second rectangle with an
 * outlined style.
 */
const IconWindowFilled = createSvgIcon(_jsx("path", { d: "M5.30773 20.5C4.8026 20.5 4.37503 20.325 4.02503 19.975C3.67503 19.625 3.50003 19.1974 3.50003 18.6923V5.3077C3.50003 4.80257 3.67503 4.375 4.02503 4.025C4.37503 3.675 4.8026 3.5 5.30773 3.5H18.6923C19.1974 3.5 19.625 3.675 19.975 4.025C20.325 4.375 20.5 4.80257 20.5 5.3077V18.6923C20.5 19.1974 20.325 19.625 19.975 19.975C19.625 20.325 19.1974 20.5 18.6923 20.5H5.30773ZM5.30773 19H18.6923C18.7692 19 18.8397 18.9679 18.9039 18.9038C18.968 18.8397 19 18.7692 19 18.6923V8.0769H5.00001V18.6923C5.00001 18.7692 5.03206 18.8397 5.09616 18.9038C5.16027 18.9679 5.2308 19 5.30773 19Z", fill: "currentColor" }), "IconWindowFilled");
export default IconWindowFilled;
//# sourceMappingURL=IconWindowFilled.js.map