import { type MenuItemProps } from "@mui/material/MenuItem";
import type { GridValidRowModel } from "@mui/x-data-grid-pro";
import type { ReactNode } from "react";
/**
 * React component for a context menu within a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro).
 * @param props Props.
 * @returns React node.
 */
export default function DGContextMenu({ contextMenu, contextMenuCoord, handleClick, handleClose, }: {
    /** Context menu items. */
    contextMenu: Array<{
        /** Custom menu item content. Can’t be used with `icon` and `text`. */
        children?: ReactNode;
        /** Menu item icon. Can’t be used with `children`. */
        icon?: ReactNode;
        /** Callback invoked when the menu item is clicked. */
        onClickMenuItem: (rowData?: GridValidRowModel) => void;
        /** Menu item text. Can’t be used with `children`. */
        text?: string;
        /** Test automation ID. */
        testId?: string;
        /** Menu item tooltip. Only shown when the menu item is disabled. */
        tooltip?: string;
    } & Omit<MenuItemProps, "children" | "onClick">>;
    /**
     * Coordinates for the context menu. Should relate to the mouse position when
     * the context menu was invoked.
     */
    contextMenuCoord: {
        mouseX: number;
        mouseY: number;
    } | null;
    /** Handles the click event of a menu item. */
    handleClick: (
    /** Callback invoked when a menu item is clicked. */
    callback: (rowData?: GridValidRowModel) => void) => void;
    /** Callback invoked when the context menu is closed. */
    handleClose: () => void;
}): import("react/jsx-runtime").JSX.Element;
