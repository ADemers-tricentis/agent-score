import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import Box from "@mui/material/Box";
import Menu from "@mui/material/Menu";
import MenuItem, {} from "@mui/material/MenuItem";
import Stack from "@mui/material/Stack";
import { styled } from "@mui/material/styles";
import Tooltip from "../Tooltip";
/**
 * React component for a context menu within a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro).
 * @param props Props.
 * @returns React node.
 */
export default function DGContextMenu({ contextMenu, contextMenuCoord, handleClick, handleClose, }) {
    return (_jsx(ContextMenu, { open: contextMenuCoord !== null, onClose: handleClose, anchorReference: "anchorPosition", anchorPosition: contextMenuCoord !== null
            ? {
                top: contextMenuCoord.mouseY,
                left: contextMenuCoord.mouseX,
            }
            : undefined, slotProps: {
            list: {
                "aria-labelledby": "basic-button",
            },
            root: {
                onContextMenu: (event) => {
                    event.preventDefault();
                    handleClose();
                },
            },
        }, children: contextMenu.map(({ children, icon, onClickMenuItem, testId, text, tooltip, ...menuItemProps }, index) => {
            const menuItem = (_jsx(MenuItem, { ...menuItemProps, "data-testid": testId, onClick: () => {
                    handleClick(onClickMenuItem);
                }, children: children ?? (_jsxs(Stack, { direction: "row", spacing: 2, alignItems: "center", children: [_jsx(Box, { display: "flex", alignItems: "center", color: "action.active", children: icon }), _jsx(Box, { children: text })] })) }, index));
            return tooltip && menuItemProps.disabled ? (_jsx(Tooltip, { arrow: true, title: tooltip, placement: "top", role: "tooltip", children: _jsx("div", { children: menuItem }) }, index)) : (menuItem);
        }) }));
}
const ContextMenu = styled(Menu)(({ theme }) => ({
    "& .MuiPaper-root": {
        marginTop: theme.spacing(1),
        borderRadius: 6,
    },
}));
//# sourceMappingURL=DGContextMenu.js.map