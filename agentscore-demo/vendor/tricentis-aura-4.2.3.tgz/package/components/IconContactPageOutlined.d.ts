/**
 * React component for an SVG icon of an avatar inside a document symbol with
 * outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsContactPage` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsContactPage.mjs`.
 */
declare const IconContactPageOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconContactPageOutlined;
