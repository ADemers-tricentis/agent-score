/**
 * React component for an SVG icon used in Neoload that represents distribution
 * ramp up with an outlined style.
 */
declare const IconDistributionRampUpOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDistributionRampUpOutlined;
