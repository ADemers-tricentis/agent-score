import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of a custom-built progress bar within a
 * square shape and an outlined style.
 */
const IconProgressBarSquareOutlined = createSvgIcon(_jsx("path", { d: "M5.31 20.5C4.8 20.5 4.38 20.32 4.03 19.97C3.68 19.62 3.5 19.19 3.5 18.69V5.31C3.5 4.8 3.68 4.38 4.03 4.03C4.38 3.68 4.81 3.5 5.31 3.5H18.69C19.2 3.5 19.62 3.68 19.97 4.03C20.32 4.38 20.5 4.81 20.5 5.31V18.69C20.5 19.2 20.32 19.62 19.97 19.97C19.62 20.32 19.19 20.5 18.69 20.5H5.31ZM5.31 19H18.69C18.77 19 18.84 18.97 18.9 18.9C18.96 18.84 19 18.77 19 18.69V5.31C19 5.23 18.97 5.16 18.9 5.1C18.84 5.04 18.77 5 18.69 5H5.31C5.23 5 5.16 5.03 5.1 5.1C5.04 5.16 5 5.23 5 5.31V18.69C5 18.77 5.03 18.84 5.1 18.9C5.16 18.96 5.23 19 5.31 19ZM7.78 13.91C7.36 13.91 7 13.73 6.71 13.36C6.42 12.99 6.27 12.54 6.27 12C6.27 11.46 6.42 11.01 6.71 10.64C7 10.27 7.36 10.09 7.78 10.09H16.22C16.64 10.09 17 10.27 17.29 10.64C17.58 11.01 17.73 11.46 17.73 12C17.73 12.54 17.58 12.99 17.29 13.36C17 13.73 16.64 13.91 16.22 13.91H7.78ZM13.21 12.76H16.22C16.39 12.76 16.53 12.69 16.65 12.54C16.77 12.39 16.82 12.21 16.82 12C16.82 11.79 16.76 11.6 16.65 11.46C16.53 11.31 16.39 11.24 16.22 11.24H13.21V12.77V12.76Z", fill: "currentColor" }), "IconProgressBarSquareOutlined");
export default IconProgressBarSquareOutlined;
//# sourceMappingURL=IconProgressBarSquareOutlined.js.map