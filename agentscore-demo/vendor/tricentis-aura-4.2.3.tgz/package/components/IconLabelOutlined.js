import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a rectangular pentagon with two equal
 * sides  with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsLabel` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsLabel.mjs`.
 */
const IconLabelOutlined = createSvgIcon(_jsx("path", { d: "M20.5 12L16.5346 17.6115C16.3385 17.891 16.0881 18.1089 15.7837 18.2653C15.4792 18.4217 15.1538 18.5 14.8077 18.5H5.30773C4.80901 18.5 4.38306 18.3233 4.02986 17.9701C3.67664 17.6169 3.50003 17.191 3.50003 16.6923V7.3077C3.50003 6.80898 3.67664 6.38302 4.02986 6.02982C4.38306 5.67661 4.80901 5.5 5.30773 5.5H14.8077C15.1602 5.5 15.4872 5.58142 15.7885 5.74425C16.0897 5.90707 16.3385 6.12822 16.5346 6.4077L20.5 12ZM18.6654 12L15.2885 7.25C15.2372 7.17948 15.1683 7.12018 15.0817 7.0721C14.9952 7.02402 14.9038 6.99998 14.8077 6.99998H5.30773C5.2308 6.99998 5.16027 7.03203 5.09616 7.09613C5.03206 7.16024 5.00001 7.23077 5.00001 7.3077V16.6923C5.00001 16.7692 5.03206 16.8397 5.09616 16.9038C5.16027 16.9679 5.2308 17 5.30773 17H14.8077C14.9038 17 14.9952 16.9759 15.0817 16.9279C15.1683 16.8798 15.2372 16.8205 15.2885 16.75L18.6654 12Z", fill: "currentColor" }), "IconLabelOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconLabelOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsLabel` instead.");
}
export default IconLabelOutlined;
//# sourceMappingURL=IconLabelOutlined.js.map