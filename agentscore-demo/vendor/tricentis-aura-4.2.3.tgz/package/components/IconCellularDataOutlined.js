import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon featuring three vertical outlined bars of
 * varying heights, symbolizing cellular data strength.
 */
const IconCellularDataOutlined = createSvgIcon(_jsx("path", { d: "M5 19.5V14.5H7.30765V19.5H5ZM10.9039 19.5V9.5H13.2115V19.5H10.9039ZM16.6923 19.5V4.5H19V19.5H16.6923Z", fill: "currentColor" }), "IconCellularDataOutlined");
export default IconCellularDataOutlined;
//# sourceMappingURL=IconCellularDataOutlined.js.map