import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of an arrow pointing down and bending to the
 * right with an outlined style.
 */
const IconArrowTurnDownRightOutlined = createSvgIcon(_jsx("path", { d: "M6.87016 4.4231C6.87016 4.85352 6.87016 7.85209 6.87016 10.5732C6.87016 13.1137 8.92965 15.1731 11.4702 15.1731H15.7721L13.9221 13.3231L14.9759 12.2693L18.6298 15.9231L14.9759 19.5769L13.9221 18.5231L15.7721 16.6731H11.3702C8.05648 16.6731 5.37019 13.9871 5.37019 10.6734C5.37019 8.34271 5.37019 5.88624 5.37019 4.4231H6.87016Z", fill: "currentColor" }), "IconArrowTurnDownRightOutlined");
export default IconArrowTurnDownRightOutlined;
//# sourceMappingURL=IconArrowTurnDownRightOutlined.js.map