/**
 * React component for an SVG icon of a custom-built decision node with a
 * rotate left arrow symbol on the bottom right corner with an outlined style.
 */
declare const IconDecisionNodeRotateLeftOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDecisionNodeRotateLeftOutlined;
