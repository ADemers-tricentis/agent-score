import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of a paper showing left and right
 * chevrons.
 */
const IconFileCodeOutlined = createSvgIcon(_jsxs(_Fragment, { children: [_jsx("path", { d: "M6.3077 21.5C5.80257 21.5 5.375 21.325 5.025 20.975C4.675 20.625 4.5 20.1974 4.5 19.6923V4.3077C4.5 3.80257 4.675 3.375 5.025 3.025C5.375 2.675 5.80257 2.5 6.3077 2.5H14.25L19.5 7.74995V19.6923C19.5 20.1974 19.325 20.625 18.975 20.975C18.625 21.325 18.1974 21.5 17.6922 21.5H6.3077ZM13.5 8.49995V3.99998H6.3077C6.23077 3.99998 6.16024 4.03203 6.09612 4.09613C6.03202 4.16024 5.99997 4.23077 5.99997 4.3077V19.6923C5.99997 19.7692 6.03202 19.8397 6.09612 19.9038C6.16024 19.9679 6.23077 20 6.3077 20H17.6922C17.7692 20 17.8397 19.9679 17.9038 19.9038C17.9679 19.8397 18 19.7692 18 19.6923V8.49995H13.5Z", fill: "currentColor" }), _jsx("path", { d: "M11.3077 17.9383L10.2538 19.0075L7 15.7536L10.2442 12.5094L11.298 13.5786L9.12302 15.7536L11.3077 17.9383Z", fill: "currentColor" }), _jsx("path", { d: "M17 15.7538L13.7462 19.0077L12.6923 17.9385L14.877 15.7538L12.6923 13.5692L13.7462 12.5L17 15.7538Z", fill: "currentColor" })] }), "IconFileCodeOutlined");
export default IconFileCodeOutlined;
//# sourceMappingURL=IconFileCodeOutlined.js.map