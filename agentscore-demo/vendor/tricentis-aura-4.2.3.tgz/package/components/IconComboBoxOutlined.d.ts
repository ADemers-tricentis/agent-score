/**
 * React component for an SVG icon of a Tosca Commander Combo box control
 * link control
 */
declare const IconComboBoxOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconComboBoxOutlined;
