import { type BoxProps } from "@mui/material/Box";
import type { ReactNode } from "react";
/**
 * React component for containing Material UI React component
 * [`Drawer`](https://mui.com/material-ui/api/drawer) children, ensuring a
 * particular width for the drawer paper contents. It fills the height of the
 * drawer paper and has a similar internal flex layout.
 * @param props Props.
 * @returns React node.
 */
export default function DrawerContainer(props: BoxProps & {
    /**
     * Drawer children, typically these Aura React components in order:
     *
     * 1. `DrawerCloser`
     * 2. `DrawerHeader`
     * 3. `DrawerContent`
     * 4. `DrawerActions`
     */
    children?: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
