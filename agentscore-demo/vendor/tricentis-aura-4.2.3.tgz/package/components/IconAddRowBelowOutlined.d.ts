/**
 * React component for an SVG icon of adding a row below.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAddRowBelow` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAddRowBelow.mjs`.
 */
declare const IconAddRowBelowOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAddRowBelowOutlined;
