/** React component for an SVG icon of an X under a row of boxes. */
declare const IconDeleteRowOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDeleteRowOutlined;
