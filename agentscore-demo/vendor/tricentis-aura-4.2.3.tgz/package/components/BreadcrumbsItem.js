import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import Link, {} from "@mui/material/Link";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
/**
 * React component for a breadcrumbs item that’s a child of the
 * [Material UI](https://mui.com/material-ui) React component
 * [`Breadcrumbs`](https://mui.com/material-ui/api/breadcrumbs).
 *
 * It implements the [Material UI](https://mui.com/material-ui) React component
 * [`Link`](https://mui.com/material-ui/api/link) and has a prop
 * [`component`](https://mui.com/material-ui/api/link/#Link-prop-component) that
 * allows a third-party router link component and it’s props to be used; see
 * [the Material UI guide](https://mui.com/material-ui/guides/routing/#link).
 * @example
 * A breadcrumbs item using the [Next.js](https://nextjs.org) router component
 * [`Link`](https://nextjs.org/docs/pages/api-reference/components/link):
 *
 * ```tsx
 * import BreadcrumbsItem from "@tricentis/aura/components/BreadcrumbsItem.js";
 * import Link from "next/link";
 *
 * const breadcrumbItem = (
 *   <BreadcrumbsItem
 *     label="Settings"
 *     component={Link}
 *     href="/settings"
 *     // Other Next.js component `Link` props can be used here…
 *   />
 * );
 * ```
 * @param props Props.
 * @returns React node.
 */
export default function BreadcrumbsItem({ icon, label, ...linkProps }) {
    return (_jsx(Link, { variant: "body2", underline: "hover", color: "inherit", ...linkProps, children: _jsxs(Stack, { direction: "row", alignItems: "center", spacing: 1, children: [icon, _jsx(Typography, { variant: "inherit", component: "span", children: label })] }) }));
}
//# sourceMappingURL=BreadcrumbsItem.js.map