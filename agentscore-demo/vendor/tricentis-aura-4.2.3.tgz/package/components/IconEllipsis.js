import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of an ellipsis with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsMoreHoriz` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsMoreHoriz.mjs`.
 */
const IconEllipsis = createSvgIcon(_jsx("path", { d: "M6.23079 13.5C5.8183 13.5 5.46518 13.3531 5.17143 13.0593C4.8777 12.7656 4.73083 12.4125 4.73083 12C4.73083 11.5875 4.8777 11.2344 5.17143 10.9406C5.46518 10.6469 5.8183 10.5 6.23079 10.5C6.64329 10.5 6.9964 10.6469 7.29014 10.9406C7.58389 11.2344 7.73076 11.5875 7.73076 12C7.73076 12.4125 7.58389 12.7656 7.29014 13.0593C6.9964 13.3531 6.64329 13.5 6.23079 13.5ZM12 13.5C11.5875 13.5 11.2344 13.3531 10.9407 13.0593C10.6469 12.7656 10.5 12.4125 10.5 12C10.5 11.5875 10.6469 11.2344 10.9407 10.9406C11.2344 10.6469 11.5875 10.5 12 10.5C12.4125 10.5 12.7656 10.6469 13.0594 10.9406C13.3531 11.2344 13.5 11.5875 13.5 12C13.5 12.4125 13.3531 12.7656 13.0594 13.0593C12.7656 13.3531 12.4125 13.5 12 13.5ZM17.7692 13.5C17.3567 13.5 17.0036 13.3531 16.7099 13.0593C16.4161 12.7656 16.2693 12.4125 16.2693 12C16.2693 11.5875 16.4161 11.2344 16.7099 10.9406C17.0036 10.6469 17.3567 10.5 17.7692 10.5C18.1817 10.5 18.5348 10.6469 18.8286 10.9406C19.1223 11.2344 19.2692 11.5875 19.2692 12C19.2692 12.4125 19.1223 12.7656 18.8286 13.0593C18.5348 13.3531 18.1817 13.5 17.7692 13.5Z", fill: "currentColor" }), "IconEllipsis");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconEllipsis` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsMoreHoriz` instead.");
}
export default IconEllipsis;
//# sourceMappingURL=IconEllipsis.js.map