/**
 * React component for an SVG icon of a paper with writing on it.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDescription` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDescription.mjs`.
 */
declare const IconDescriptionOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDescriptionOutlined;
