import type { ReactNode } from "react";
/**
 * React component for drawer actions. Intended for use as the last child of the
 * Aura React component `DrawerContainer`.
 * @param props Props.
 * @returns React node.
 */
export default function DrawerActions({ children, }: {
    /** Content to be rendered. */
    children?: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
