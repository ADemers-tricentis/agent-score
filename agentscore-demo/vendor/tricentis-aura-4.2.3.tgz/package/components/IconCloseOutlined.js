import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of a close, x symbol with outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsClose` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsClose.mjs`.
 */
const IconCloseOutlined = createSvgIcon(_jsx("path", { d: "M6.40002 18.6538L5.34619 17.6L10.9462 12L5.34619 6.40002L6.40002 5.34619L12 10.9462L17.6 5.34619L18.6538 6.40002L13.0538 12L18.6538 17.6L17.6 18.6538L12 13.0538L6.40002 18.6538Z", fill: "currentColor" }), "IconCloseOutlined");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconCloseOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsClose` instead.");
}
export default IconCloseOutlined;
//# sourceMappingURL=IconCloseOutlined.js.map