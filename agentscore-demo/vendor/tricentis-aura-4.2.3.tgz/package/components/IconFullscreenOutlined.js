import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of entering fullscreen with an outlined
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFullscreen` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFullscreen.mjs`.
 */
const IconFullscreenOutlined = createSvgIcon(_jsx("path", { d: "M3.49524 20.5V15.7884H4.99521V19H8.20676V20.5H3.49524ZM15.7933 20.5V19H19.0048V15.7884H20.5048V20.5H15.7933ZM3.49524 8.21153V3.5H8.20676V4.99998H4.99521V8.21153H3.49524ZM19.0048 8.21153V4.99998H15.7933V3.5H20.5048V8.21153H19.0048Z", fill: "currentColor" }), "IconFullscreenOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconFullscreenOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFullscreen` instead.");
}
export default IconFullscreenOutlined;
//# sourceMappingURL=IconFullscreenOutlined.js.map