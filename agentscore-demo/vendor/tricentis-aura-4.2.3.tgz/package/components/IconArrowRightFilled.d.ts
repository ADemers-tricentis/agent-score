/**
 * React component for an SVG icon of a rigiht-pointing arrow head with filled
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsArrowRight` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowRight.mjs`.
 */
declare const IconArrowRightFilled: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconArrowRightFilled;
