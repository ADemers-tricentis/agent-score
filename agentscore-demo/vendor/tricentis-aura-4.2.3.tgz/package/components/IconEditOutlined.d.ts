/**
 * React component for an SVG icon of a pencil or pen with an outlined style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsEdit` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsEdit.mjs`.
 */
declare const IconEditOutlined: import("@mui/material/OverridableComponent.js").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconEditOutlined;
