/**
 * React component for an SVG icon of a downward-pointing arrow head, dropdown,
 * dropdown, south with filled style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsArrowDropDown` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowDropDown.mjs`.
 */
declare const IconArrowDropDownFilled: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconArrowDropDownFilled;
