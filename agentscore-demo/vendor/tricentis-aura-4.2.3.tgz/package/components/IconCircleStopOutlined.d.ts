/**
 * React component for an SVG icon of a filled square in a circle.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsStopCircle` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsStopCircle.mjs`.
 */
declare const IconCircleStopOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCircleStopOutlined;
