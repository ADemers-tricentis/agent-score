import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a check box, checked, square with filled
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCheckBox` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCheckBox.mjs`.
 */
const IconCheckBoxFilled = createSvgIcon(_jsx("path", { d: "M10.4896 14.4283L8.16652 12.1052C8.02807 11.9667 7.85404 11.8959 7.64442 11.8927C7.43482 11.8895 7.25759 11.9603 7.11272 12.1052C6.96784 12.2501 6.8954 12.4257 6.8954 12.6321C6.8954 12.8385 6.96784 13.0141 7.11272 13.159L9.85695 15.9032C10.0377 16.084 10.2486 16.1744 10.4896 16.1744C10.7306 16.1744 10.9415 16.084 11.1223 15.9032L16.6858 10.3398C16.8242 10.2013 16.8951 10.0273 16.8983 9.81768C16.9015 9.60806 16.8306 9.43082 16.6858 9.28595C16.5409 9.14109 16.3653 9.06865 16.1588 9.06865C15.9524 9.06865 15.7768 9.14109 15.6319 9.28595L10.4896 14.4283ZM5.19735 21.1821C4.69222 21.1821 4.26465 21.0071 3.91465 20.6571C3.56465 20.3071 3.38965 19.8795 3.38965 19.3744V5.98983C3.38965 5.4847 3.56465 5.05713 3.91465 4.70713C4.26465 4.35713 4.69222 4.18213 5.19735 4.18213H18.5819C19.087 4.18213 19.5146 4.35713 19.8646 4.70713C20.2146 5.05713 20.3896 5.4847 20.3896 5.98983V19.3744C20.3896 19.8795 20.2146 20.3071 19.8646 20.6571C19.5146 21.0071 19.087 21.1821 18.5819 21.1821H5.19735Z", fill: "currentColor" }), "IconCheckBoxFilled");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconCheckBoxFilled` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsCheckBox` instead.");
}
export default IconCheckBoxFilled;
//# sourceMappingURL=IconCheckBoxFilled.js.map