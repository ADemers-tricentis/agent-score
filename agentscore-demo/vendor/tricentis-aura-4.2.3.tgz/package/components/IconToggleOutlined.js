import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of an oval shape with a dot at the left
 * side.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsToggleOff` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsToggleOff.mjs`.
 */
const IconToggleOutlined = createSvgIcon(_jsx("path", { d: "M6.99998 17.5C5.47221 17.5 4.17361 16.9655 3.10418 15.8965C2.03473 14.8275 1.5 13.5294 1.5 12.0023C1.5 10.4751 2.03473 9.17628 3.10418 8.10578C4.17361 7.03526 5.47221 6.5 6.99998 6.5H17C18.5277 6.5 19.8263 7.0345 20.8958 8.1035C21.9652 9.1725 22.5 10.4706 22.5 11.9977C22.5 13.5249 21.9652 14.8237 20.8958 15.8942C19.8263 16.9647 18.5277 17.5 17 17.5H6.99998ZM6.99998 16H17C18.1 16 19.0416 15.6083 19.825 14.825C20.6083 14.0416 21 13.1 21 12C21 10.9 20.6083 9.95831 19.825 9.17498C19.0416 8.39164 18.1 7.99998 17 7.99998H6.99998C5.89998 7.99998 4.95831 8.39164 4.17498 9.17498C3.39164 9.95831 2.99998 10.9 2.99998 12C2.99998 13.1 3.39164 14.0416 4.17498 14.825C4.95831 15.6083 5.89998 16 6.99998 16ZM6.99885 14.75C7.76242 14.75 8.41183 14.4827 8.94708 13.9482C9.48233 13.4137 9.74995 12.7647 9.74995 12.0011C9.74995 11.2375 9.4827 10.5881 8.9482 10.0529C8.4137 9.51763 7.76467 9.25 7.0011 9.25C6.23753 9.25 5.58813 9.51725 5.05288 10.0518C4.51763 10.5863 4.25 11.2353 4.25 11.9989C4.25 12.7624 4.51725 13.4118 5.05175 13.9471C5.58625 14.4823 6.23528 14.75 6.99885 14.75Z", fill: "currentColor" }), "IconToggleOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconToggleOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsToggleOff` instead.");
}
export default IconToggleOutlined;
//# sourceMappingURL=IconToggleOutlined.js.map