/**
 * React component for an SVG icon of adding a table column to the right.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAddColumnRight` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAddColumnRight.mjs`.
 */
declare const IconAddColumnRightOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAddColumnRightOutlined;
