import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of with two horizontally
 * stacked rectangles, outlined with the right filled.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsSplitscreenRight` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsSplitscreenRight.mjs`.
 */
const IconSplitscreenRightOutlined = createSvgIcon(_jsx("path", { d: "M15 20.5C14.4949 20.5 14.0673 20.325 13.7173 19.975C13.3673 19.625 13.1923 19.1974 13.1923 18.6923V5.3077C13.1923 4.80257 13.3673 4.375 13.7173 4.025C14.0673 3.675 14.4949 3.5 15 3.5H18.3846C18.8897 3.5 19.3172 3.675 19.6672 4.025C20.0172 4.375 20.1922 4.80257 20.1922 5.3077V18.6923C20.1922 19.1974 20.0172 19.625 19.6672 19.975C19.3172 20.325 18.8897 20.5 18.3846 20.5H15ZM5.61541 20.5C5.1103 20.5 4.68274 20.325 4.33274 19.975C3.98274 19.625 3.80774 19.1974 3.80774 18.6923V5.3077C3.80774 4.80257 3.98274 4.375 4.33274 4.025C4.68274 3.675 5.1103 3.5 5.61541 3.5H8.99999C9.50511 3.5 9.93266 3.675 10.2827 4.025C10.6327 4.375 10.8077 4.80257 10.8077 5.3077V18.6923C10.8077 19.1974 10.6327 19.625 10.2827 19.975C9.93266 20.325 9.50511 20.5 8.99999 20.5H5.61541ZM5.30771 5.3077V18.6923C5.30771 18.7692 5.33976 18.8397 5.40386 18.9038C5.46796 18.9679 5.53848 19 5.61541 19H8.99999C9.07692 19 9.14744 18.9679 9.21154 18.9038C9.27566 18.8397 9.30771 18.7692 9.30771 18.6923V5.3077C9.30771 5.23077 9.27566 5.16024 9.21154 5.09613C9.14744 5.03203 9.07692 4.99998 8.99999 4.99998H5.61541C5.53848 4.99998 5.46796 5.03203 5.40386 5.09613C5.33976 5.16024 5.30771 5.23077 5.30771 5.3077Z", fill: "currentColor" }), "IconSplitscreenRightOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconSplitscreenRightOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsSplitscreenRight` instead.");
}
export default IconSplitscreenRightOutlined;
//# sourceMappingURL=IconSplitscreenRightOutlined.js.map