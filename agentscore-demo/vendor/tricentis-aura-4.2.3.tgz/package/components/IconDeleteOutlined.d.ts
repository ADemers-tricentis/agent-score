/**
 * React component for an SVG icon of a trash or bin with an outlined style.
 */
declare const IconDeleteOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDeleteOutlined;
