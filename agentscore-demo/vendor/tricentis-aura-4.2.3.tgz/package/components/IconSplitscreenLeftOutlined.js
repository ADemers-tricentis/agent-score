import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of with two horizontally
 * stacked rectangles, outlined with the left filled.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsSplitscreenLeft` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsSplitscreenLeft.mjs`.
 */
const IconSplitscreenLeftOutlined = createSvgIcon(_jsx("path", { d: "M5.61541 20.5C5.1103 20.5 4.68274 20.325 4.33274 19.975C3.98274 19.625 3.80774 19.1974 3.80774 18.6923V5.3077C3.80774 4.80257 3.98274 4.375 4.33274 4.025C4.68274 3.675 5.1103 3.5 5.61541 3.5H8.99999C9.50511 3.5 9.93266 3.675 10.2827 4.025C10.6327 4.375 10.8077 4.80257 10.8077 5.3077V18.6923C10.8077 19.1974 10.6327 19.625 10.2827 19.975C9.93266 20.325 9.50511 20.5 8.99999 20.5H5.61541ZM15 20.5C14.4949 20.5 14.0673 20.325 13.7173 19.975C13.3673 19.625 13.1923 19.1974 13.1923 18.6923V5.3077C13.1923 4.80257 13.3673 4.375 13.7173 4.025C14.0673 3.675 14.4949 3.5 15 3.5H18.3846C18.8897 3.5 19.3172 3.675 19.6672 4.025C20.0172 4.375 20.1922 4.80257 20.1922 5.3077V18.6923C20.1922 19.1974 20.0172 19.625 19.6672 19.975C19.3172 20.325 18.8897 20.5 18.3846 20.5H15ZM18.6923 5.3077C18.6923 5.23077 18.6602 5.16024 18.5961 5.09613C18.532 5.03203 18.4615 4.99998 18.3846 4.99998H15C14.9231 4.99998 14.8525 5.03203 14.7884 5.09613C14.7243 5.16024 14.6923 5.23077 14.6923 5.3077V18.6923C14.6923 18.7692 14.7243 18.8397 14.7884 18.9038C14.8525 18.9679 14.9231 19 15 19H18.3846C18.4615 19 18.532 18.9679 18.5961 18.9038C18.6602 18.8397 18.6923 18.7692 18.6923 18.6923V5.3077Z", fill: "currentColor" }), "IconSplitscreenLeftOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconSplitscreenLeftOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsSplitscreenLeft` instead.");
}
export default IconSplitscreenLeftOutlined;
//# sourceMappingURL=IconSplitscreenLeftOutlined.js.map