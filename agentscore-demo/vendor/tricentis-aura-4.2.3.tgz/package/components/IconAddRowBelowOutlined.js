import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of adding a row below.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAddRowBelow` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAddRowBelow.mjs`.
 */
const IconAddRowBelowOutlined = createSvgIcon(_jsxs(_Fragment, { children: [_jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M3.78011 12C2.79704 12 2.00011 11.2031 2.00011 10.22L2 3H3.5L3.50011 5H8.16168V3H9.66163V5H14.3136V3H15.8385V5H20.5001V3L22.0001 3V10.22C22.0001 11.2031 21.2031 12 20.2201 12H3.78011ZM8.16168 10.5H3.82011C3.64337 10.5 3.50011 10.3568 3.50011 10.18V6.5H8.16168V10.5ZM14.3136 10.5H9.66163V6.5H14.3136V10.5ZM15.8385 10.5H20.1801C20.3568 10.5 20.5001 10.3568 20.5001 10.18V6.5H15.8385V10.5Z", fill: "currentColor" }), _jsx("path", { d: "M12.7489 21.7492L12.7598 18.7548L15.7541 18.7439L15.7541 17.2536L12.7598 17.2427L12.7489 14.2484L11.2585 14.2484L11.2477 17.2427L8.25335 17.2536V18.7439L11.2477 18.7548L11.2585 21.7491L12.7489 21.7492Z", fill: "currentColor" })] }), "IconAddRowBelowOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconAddRowBelowOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsAddRowBelow` instead.");
}
export default IconAddRowBelowOutlined;
//# sourceMappingURL=IconAddRowBelowOutlined.js.map