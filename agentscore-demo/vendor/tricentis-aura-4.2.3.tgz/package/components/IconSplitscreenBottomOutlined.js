import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of with two vertically
 * stacked rectangles, outlined with the below filled.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsSplitscreenBottom` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsSplitscreenBottom.mjs`.
 */
const IconSplitscreenBottomOutlined = createSvgIcon(_jsx("path", { d: "M5.3077 20.1922C4.80257 20.1922 4.375 20.0172 4.025 19.6672C3.675 19.3172 3.5 18.8897 3.5 18.3846V15C3.5 14.4949 3.675 14.0673 4.025 13.7173C4.375 13.3673 4.80257 13.1923 5.3077 13.1923H18.6923C19.1974 13.1923 19.625 13.3673 19.975 13.7173C20.325 14.0673 20.5 14.4949 20.5 15V18.3846C20.5 18.8897 20.325 19.3172 19.975 19.6672C19.625 20.0172 19.1974 20.1922 18.6923 20.1922H5.3077ZM5.3077 10.8077C4.80257 10.8077 4.375 10.6327 4.025 10.2827C3.675 9.93266 3.5 9.50511 3.5 8.99999V5.61541C3.5 5.1103 3.675 4.68274 4.025 4.33274C4.375 3.98274 4.80257 3.80774 5.3077 3.80774H18.6923C19.1974 3.80774 19.625 3.98274 19.975 4.33274C20.325 4.68274 20.5 5.1103 20.5 5.61541V8.99999C20.5 9.50511 20.325 9.93266 19.975 10.2827C19.625 10.6327 19.1974 10.8077 18.6923 10.8077H5.3077ZM18.6923 5.30771H5.3077C5.23077 5.30771 5.16024 5.33977 5.09612 5.40387C5.03202 5.46797 4.99997 5.53848 4.99997 5.61541V8.99999C4.99997 9.07692 5.03202 9.14744 5.09612 9.21154C5.16024 9.27566 5.23077 9.30771 5.3077 9.30771H18.6923C18.7692 9.30771 18.8397 9.27566 18.9038 9.21154C18.9679 9.14744 19 9.07692 19 8.99999V5.61541C19 5.53848 18.9679 5.46797 18.9038 5.40387C18.8397 5.33977 18.7692 5.30771 18.6923 5.30771Z", fill: "currentColor" }), "IconSplitscreenBottomOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconSplitscreenBottomOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsSplitscreenBottom` instead.");
}
export default IconSplitscreenBottomOutlined;
//# sourceMappingURL=IconSplitscreenBottomOutlined.js.map