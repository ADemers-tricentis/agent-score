import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import Box from "@mui/material/Box";
import Divider from "@mui/material/Divider";
import Stack from "@mui/material/Stack";
import { styled } from "@mui/material/styles";
import Typography from "@mui/material/Typography";
/**
 * React component for wrapping notifications.
 * @param props Props.
 * @returns React node.
 */
export default function NotificationCenterWrapper({ children, dataTestId, secondaryAction, title, }) {
    return (_jsxs(Box, { display: "contents", children: [_jsxs(NotificationCenterHeader, { "data-testid": dataTestId, children: [_jsx(Typography, { variant: "subtitle2", children: title }), secondaryAction] }), _jsx(Divider, {}), _jsx(Stack, { flex: 1, overflow: "auto", children: children })] }));
}
const NotificationCenterHeader = styled(Box)(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
    maxHeight: 52,
    padding: theme.spacing(2),
}));
//# sourceMappingURL=NotificationCenterWrapper.js.map