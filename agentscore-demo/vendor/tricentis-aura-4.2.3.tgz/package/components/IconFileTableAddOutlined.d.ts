/** React component for an SVG icon of a paper with a table and + sign. */
declare const IconFileTableAddOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconFileTableAddOutlined;
