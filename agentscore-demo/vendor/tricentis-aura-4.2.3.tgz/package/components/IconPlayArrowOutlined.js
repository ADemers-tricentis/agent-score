import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a play arrow with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsPlayArrow` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsPlayArrow.mjs`.
 */
const IconPlayArrowOutlined = createSvgIcon(_jsx("path", { d: "M7.21158 18.096V5.90381L16.7884 11.9999L7.21158 18.096ZM8.71155 15.3499L13.9808 11.9999L8.71155 8.64991V15.3499Z", fill: "currentColor" }), "IconPlayArrowOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconPlayArrowOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsPlayArrow` instead.");
}
export default IconPlayArrowOutlined;
//# sourceMappingURL=IconPlayArrowOutlined.js.map