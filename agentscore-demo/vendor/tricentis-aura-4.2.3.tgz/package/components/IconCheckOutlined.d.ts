/**
 * React component for an SVG icon of a check, tick, tick mark, correct, pass,
 * success in stroke with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCheck` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCheck.mjs`.
 */
declare const IconCheckOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCheckOutlined;
