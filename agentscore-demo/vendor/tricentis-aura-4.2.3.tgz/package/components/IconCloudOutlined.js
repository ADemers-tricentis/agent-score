import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a cloud symbol with outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCloud` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCloud.mjs`.
 */
const IconCloudOutlined = createSvgIcon(_jsx("path", { d: "M6.50001 19.5C5.11797 19.5 3.93913 19.0198 2.96348 18.0596C1.98785 17.0993 1.50003 15.9282 1.50003 14.5461C1.50003 13.3231 1.8917 12.2352 2.67503 11.2827C3.45836 10.3301 4.45772 9.76667 5.67311 9.59232C5.99362 8.09744 6.74522 6.875 7.92791 5.925C9.11059 4.975 10.468 4.5 12 4.5C13.809 4.5 15.3445 5.13109 16.6067 6.39328C17.8689 7.65544 18.5 9.19101 18.5 11V11.5H18.8077C19.8615 11.5821 20.7404 12.0058 21.4442 12.7712C22.1481 13.5365 22.5 14.4461 22.5 15.5C22.5 16.6153 22.1122 17.5609 21.3365 18.3365C20.5609 19.1121 19.6154 19.5 18.5 19.5H6.50001ZM6.50001 18H18.5C19.2 18 19.7917 17.7583 20.275 17.275C20.7583 16.7916 21 16.2 21 15.5C21 14.8 20.7583 14.2083 20.275 13.725C19.7917 13.2416 19.2 13 18.5 13H17V11C17 9.61664 16.5125 8.43748 15.5375 7.46248C14.5625 6.48748 13.3833 5.99998 12 5.99998C10.6167 5.99998 9.43751 6.48748 8.46251 7.46248C7.48751 8.43748 7.00001 9.61664 7.00001 11H6.50001C5.53334 11 4.70834 11.3416 4.02501 12.025C3.34167 12.7083 3.00001 13.5333 3.00001 14.5C3.00001 15.4666 3.34167 16.2916 4.02501 16.975C4.70834 17.6583 5.53334 18 6.50001 18Z", fill: "currentColor" }), "IconCloudOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconCloudOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsCloud` instead.");
}
export default IconCloudOutlined;
//# sourceMappingURL=IconCloudOutlined.js.map