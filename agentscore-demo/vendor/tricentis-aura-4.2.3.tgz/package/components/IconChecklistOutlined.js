import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a checklist with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsChecklist` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsChecklist.mjs`.
 */
const IconChecklistOutlined = createSvgIcon(_jsx("path", { d: "M5.69425 18.4519L2.50002 15.2577L3.54425 14.2135L5.66925 16.3385L9.91925 12.0885L10.9634 13.1577L5.69425 18.4519ZM5.69425 10.8365L2.50002 7.64234L3.54425 6.59814L5.66925 8.72314L9.91925 4.47314L10.9634 5.54234L5.69425 10.8365ZM13.0096 16.5577V15.0577H21.5096V16.5577H13.0096ZM13.0096 8.94232V7.44237H21.5096V8.94232H13.0096Z", fill: "currentColor" }), "IconChecklistOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconChecklistOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsChecklist` instead.");
}
export default IconChecklistOutlined;
//# sourceMappingURL=IconChecklistOutlined.js.map