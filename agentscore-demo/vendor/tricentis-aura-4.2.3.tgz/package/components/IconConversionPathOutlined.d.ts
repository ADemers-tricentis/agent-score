/**
 * React component for an SVG icon of a conversion path with outline style
 */
declare const IconConversionPathOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconConversionPathOutlined;
