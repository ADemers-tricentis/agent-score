import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of multiple columns tightly together.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsViewColumn` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsViewColumn.mjs`.
 */
const IconViewColumnOutlined = createSvgIcon(_jsx("path", { d: "M3.49799 19.2H7.95094V4.79998H3.49799C3.39879 4.79998 3.31731 4.8346 3.25353 4.90384C3.18976 4.97308 3.15787 5.06155 3.15787 5.16925V18.8308C3.15787 18.9385 3.18976 19.0269 3.25353 19.0962C3.31731 19.1654 3.39879 19.2 3.49799 19.2ZM9.60878 19.2H14.3912V4.79998H9.60878V19.2ZM16.0491 19.2H20.502C20.6012 19.2 20.6827 19.1654 20.7465 19.0962C20.8102 19.0269 20.8421 18.9385 20.8421 18.8308V5.16925C20.8421 5.06155 20.8102 4.97308 20.7465 4.90384C20.6827 4.8346 20.6012 4.79998 20.502 4.79998H16.0491V19.2ZM3.49799 21C2.93968 21 2.46711 20.79 2.08026 20.37C1.69342 19.95 1.5 19.4369 1.5 18.8308V5.16925C1.5 4.56309 1.69342 4.05 2.08026 3.63C2.46711 3.21 2.93968 3 3.49799 3H20.502C21.0603 3 21.5329 3.21 21.9197 3.63C22.3066 4.05 22.5 4.56309 22.5 5.16925V18.8308C22.5 19.4369 22.3066 19.95 21.9197 20.37C21.5329 20.79 21.0603 21 20.502 21H3.49799Z", fill: "currentColor" }), "IconViewColumnOutlined");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconViewColumnOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsViewColumn` instead.");
}
export default IconViewColumnOutlined;
//# sourceMappingURL=IconViewColumnOutlined.js.map