import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import Box from "@mui/material/Box";
import Divider from "@mui/material/Divider";
/**
 * React component for drawer actions. Intended for use as the last child of the
 * Aura React component `DrawerContainer`.
 * @param props Props.
 * @returns React node.
 */
export default function DrawerActions({ children, }) {
    return (_jsxs(_Fragment, { children: [_jsx(Divider, {}), _jsx(Box, { display: "flex", justifyContent: "flex-end", gap: 1, px: 3, pt: 2, pb: 3, children: children })] }));
}
//# sourceMappingURL=DrawerActions.js.map