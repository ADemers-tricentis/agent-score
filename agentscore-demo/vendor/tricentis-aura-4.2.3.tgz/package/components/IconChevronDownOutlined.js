import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of a chevron pointing downward with an
 * outlined style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsKeyboardArrowDown` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsKeyboardArrowDown.mjs`.
 */
const IconChevronDownOutlined = createSvgIcon(_jsx("path", { d: "M11.9976 15.0105C11.8771 15.0105 11.7649 14.9913 11.6611 14.9528C11.5572 14.9144 11.4585 14.8483 11.3649 14.7547L6.87069 10.2605C6.73222 10.1221 6.66139 9.94802 6.65819 9.7384C6.65497 9.5288 6.7258 9.35157 6.87069 9.2067C7.01555 9.06182 7.19119 8.98938 7.39759 8.98938C7.60399 8.98938 7.77962 9.06182 7.92449 9.2067L11.9976 13.2798L16.0707 9.2067C16.2091 9.06824 16.3832 8.9974 16.5928 8.9942C16.8024 8.99099 16.9796 9.06182 17.1245 9.2067C17.2694 9.35157 17.3418 9.5272 17.3418 9.7336C17.3418 9.94 17.2694 10.1156 17.1245 10.2605L12.6303 14.7547C12.5367 14.8483 12.438 14.9144 12.3341 14.9528C12.2303 14.9913 12.1181 15.0105 11.9976 15.0105Z", fill: "currentColor" }), "IconChevronDownOutlined");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconChevronDownOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsKeyboardArrowDown` instead.");
}
export default IconChevronDownOutlined;
//# sourceMappingURL=IconChevronDownOutlined.js.map