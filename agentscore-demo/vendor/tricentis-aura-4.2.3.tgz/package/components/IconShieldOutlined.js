import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a shield with an outlined style.  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsShield` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsShield.mjs`.
 */
const IconShieldOutlined = createSvgIcon(_jsx("path", { d: "M12 21.4808C9.83716 20.8911 8.04646 19.618 6.62787 17.6616C5.20929 15.7052 4.5 13.518 4.5 11.1001V5.34625L12 2.53857L19.5 5.34625V11.1001C19.5 13.518 18.7907 15.7052 17.3721 17.6616C15.9535 19.618 14.1628 20.8911 12 21.4808ZM12 19.9001C13.7333 19.3501 15.1666 18.2501 16.3 16.6001C17.4333 14.9501 18 13.1167 18 11.1001V6.37507L12 4.1347L5.99997 6.37507V11.1001C5.99997 13.1167 6.56664 14.9501 7.69997 16.6001C8.83331 18.2501 10.2666 19.3501 12 19.9001Z", fill: "currentColor" }), "IconShieldOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconShieldOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsShield` instead.");
}
export default IconShieldOutlined;
//# sourceMappingURL=IconShieldOutlined.js.map