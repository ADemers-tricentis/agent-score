import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of an open eye with a filled style  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsVisibility` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsVisibility.mjs`.
 */
const IconEyeFilled = createSvgIcon(_jsx("path", { d: "M12.0022 16.0769C13.1353 16.0769 14.0977 15.6803 14.8894 14.8871C15.681 14.0939 16.0769 13.1308 16.0769 11.9977C16.0769 10.8646 15.6803 9.90224 14.8871 9.11058C14.0939 8.31891 13.1308 7.92308 11.9977 7.92308C10.8646 7.92308 9.90222 8.31966 9.11055 9.11282C8.31889 9.90601 7.92305 10.8692 7.92305 12.0023C7.92305 13.1353 8.31964 14.0977 9.1128 14.8894C9.90599 15.681 10.8691 16.0769 12.0022 16.0769ZM12 14.7C11.25 14.7 10.6125 14.4375 10.0875 13.9125C9.56245 13.3875 9.29995 12.75 9.29995 12C9.29995 11.25 9.56245 10.6125 10.0875 10.0875C10.6125 9.56248 11.25 9.29998 12 9.29998C12.75 9.29998 13.3875 9.56248 13.9125 10.0875C14.4375 10.6125 14.7 11.25 14.7 12C14.7 12.75 14.4375 13.3875 13.9125 13.9125C13.3875 14.4375 12.75 14.7 12 14.7ZM12.0013 19C9.70171 19 7.60639 18.3657 5.71535 17.0971C3.82434 15.8285 2.43204 14.1295 1.53845 12C2.43204 9.87049 3.82389 8.17146 5.714 6.90288C7.6041 5.63429 9.69896 5 11.9986 5C14.2982 5 16.3935 5.63429 18.2846 6.90288C20.1756 8.17146 21.5679 9.87049 22.4615 12C21.5679 14.1295 20.176 15.8285 18.2859 17.0971C16.3958 18.3657 14.3009 19 12.0013 19Z", fill: "currentColor" }), "IconEyeFilled");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconEyeFilled` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsVisibility` instead.");
}
export default IconEyeFilled;
//# sourceMappingURL=IconEyeFilled.js.map