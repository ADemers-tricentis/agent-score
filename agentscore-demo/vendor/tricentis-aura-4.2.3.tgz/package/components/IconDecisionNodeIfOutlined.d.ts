/**
 * React component for an SVG icon of a custom Tosca IF symbol representing an
 * IF condition in the Tosca Cloud with outlined style.
 */
declare const IconDecisionNodeIfOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDecisionNodeIfOutlined;
