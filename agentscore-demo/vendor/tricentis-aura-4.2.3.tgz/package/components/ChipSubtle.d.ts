/**
 * React component for a customized Material UI component
 * [`Chip`](https://mui.com/material-ui/api/chip) based on the variant `outlined`.
 * Typically used to represent a status.
 * @param props Props.
 * @returns React node.
 */
declare const ChipSubtle: import("react").ForwardRefExoticComponent<Omit<Omit<import("@mui/material/Chip").ChipOwnProps & import("@mui/material/Chip").ChipSlotsAndSlotProps & import("@mui/material/OverridableComponent").CommonProps & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "color" | "variant" | "sx" | "label" | "style" | "children" | "className" | "classes" | "icon" | "tabIndex" | "disabled" | "avatar" | "clickable" | "deleteIcon" | "onDelete" | "size" | "skipFocusWhenDisabled" | "slots" | "slotProps">, "ref">, "variant"> & import("react").RefAttributes<HTMLDivElement>>;
export default ChipSubtle;
