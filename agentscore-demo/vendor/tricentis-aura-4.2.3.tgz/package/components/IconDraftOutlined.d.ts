/**
 * React component for an SVG icon of a pencil and paper.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDraftOrders` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDraftOrders.mjs`.
 */
declare const IconDraftOutlined: import("@mui/material/OverridableComponent.js").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDraftOutlined;
