/**
 * React component for an SVG icon of archive, box, bin symbol
 * with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsInventory2` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsInventory2.mjs`.
 */
declare const IconArchiveOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconArchiveOutlined;
