/**
 * React component for an SVG icon of a create folder symbol with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCreateNewFolder` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCreateNewFolder.mjs`.
 */
declare const IconCreateNewFolderOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCreateNewFolderOutlined;
