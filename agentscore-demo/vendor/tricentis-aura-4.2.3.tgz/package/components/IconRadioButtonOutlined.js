import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a radio button with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsRadioButtonUnchecked` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsRadioButtonUnchecked.mjs`.
 */
const IconRadioButtonOutlined = createSvgIcon(_jsx("path", { d: "M12.002 21.5a9.255 9.255 0 0 1-3.705-.748 9.598 9.598 0 0 1-3.017-2.03 9.591 9.591 0 0 1-2.032-3.016 9.245 9.245 0 0 1-.748-3.704c0-1.314.25-2.55.748-3.705a9.597 9.597 0 0 1 2.03-3.018 9.592 9.592 0 0 1 3.016-2.03 9.245 9.245 0 0 1 3.704-.749c1.314 0 2.55.25 3.705.748a9.596 9.596 0 0 1 3.018 2.03 9.592 9.592 0 0 1 2.03 3.016 9.247 9.247 0 0 1 .749 3.704c0 1.314-.25 2.55-.748 3.705a9.597 9.597 0 0 1-2.03 3.018 9.592 9.592 0 0 1-3.016 2.03 9.245 9.245 0 0 1-3.704.749ZM12 20c2.233 0 4.125-.775 5.675-2.325C19.225 16.125 20 14.233 20 12c0-2.233-.775-4.125-2.325-5.675C16.125 4.775 14.233 4 12 4c-2.233 0-4.125.775-5.675 2.325C4.775 7.875 4 9.767 4 12c0 2.233.775 4.125 2.325 5.675C7.875 19.225 9.767 20 12 20Z", fill: "currentColor" }), "IconRadioButtonOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconRadioButtonOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsRadioButtonUnchecked` instead.");
}
export default IconRadioButtonOutlined;
//# sourceMappingURL=IconRadioButtonOutlined.js.map