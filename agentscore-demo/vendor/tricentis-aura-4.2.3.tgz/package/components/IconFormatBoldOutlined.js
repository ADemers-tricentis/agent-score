import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of format-bold symbol with outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFormatBold` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFormatBold.mjs`.
 */
const IconFormatBoldOutlined = createSvgIcon(_jsx("path", { d: "M7.3385 18.625V5.375H12.2C13.2192 5.375 14.1407 5.69231 14.9644 6.32693C15.7881 6.96154 16.2 7.81603 16.2 8.89038C16.2 9.63779 16.0195 10.2471 15.6586 10.7183C15.2977 11.1894 14.9089 11.5314 14.4923 11.7442C15.0051 11.9211 15.4948 12.2708 15.9615 12.7933C16.4282 13.3157 16.6615 14.0192 16.6615 14.9038C16.6615 16.182 16.1904 17.1217 15.2481 17.723C14.3058 18.3243 13.3564 18.625 12.4 18.625H7.3385ZM9.48843 16.6327H12.3192C13.1064 16.6327 13.6628 16.4141 13.9885 15.9769C14.3141 15.5397 14.477 15.1205 14.477 14.7192C14.477 14.3179 14.3141 13.8987 13.9885 13.4615C13.6628 13.0243 13.091 12.8057 12.2731 12.8057H9.48843V16.6327ZM9.48843 10.875H12.0827C12.6904 10.875 13.1721 10.7013 13.5279 10.3539C13.8837 10.0064 14.0616 9.59037 14.0616 9.10575C14.0616 8.59035 13.8734 8.16918 13.4971 7.84225C13.1208 7.51533 12.6596 7.35188 12.1135 7.35188H9.48843V10.875Z", fill: "currentColor" }), "IconFormatBoldOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconFormatBoldOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFormatBold` instead.");
}
export default IconFormatBoldOutlined;
//# sourceMappingURL=IconFormatBoldOutlined.js.map