/**
 * React component for an SVG icon of a database with a search check in an
 * outlined style.
 *
 * It serves as the `DITestingOutlined` icon in Tosca Cloud.
 */
declare const IconDatabaseSearchCheckOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDatabaseSearchCheckOutlined;
