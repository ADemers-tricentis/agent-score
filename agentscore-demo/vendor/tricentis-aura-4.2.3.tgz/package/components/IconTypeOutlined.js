import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a shield with a checkmark on it.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsVerifiedUser` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsVerifiedUser.mjs`.
 */
const IconTypeOutlined = createSvgIcon(_jsx("path", { d: "M10.95 15.1941L16.2538 9.89031L15.1846 8.82111L10.95 13.0557L8.83075 10.9365L7.76155 12.0057L10.95 15.1941ZM12 21.471C9.83716 20.8813 8.04646 19.6082 6.62787 17.6518C5.20929 15.6954 4.5 13.5082 4.5 11.0903V5.33648L12 2.52881L19.5 5.33648V11.0903C19.5 13.5082 18.7907 15.6954 17.3721 17.6518C15.9535 19.6082 14.1628 20.8813 12 21.471ZM12 19.8903C13.7333 19.3403 15.1666 18.2403 16.3 16.5903C17.4333 14.9403 18 13.107 18 11.0903V6.36531L12 4.12493L5.99997 6.36531V11.0903C5.99997 13.107 6.56664 14.9403 7.69997 16.5903C8.83331 18.2403 10.2666 19.3403 12 19.8903Z", fill: "currentColor" }), "IconTypeOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconTypeOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsVerifiedUser` instead.");
}
export default IconTypeOutlined;
//# sourceMappingURL=IconTypeOutlined.js.map