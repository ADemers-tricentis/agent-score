import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of bulleted list with outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsNotes` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsNotes.mjs`.
 */
const IconListOutlined = createSvgIcon(_jsx("path", { d: "M7.24998 15.5C7.03749 15.5 6.85938 15.4281 6.71563 15.2843C6.57188 15.1404 6.5 14.9622 6.5 14.7497C6.5 14.5371 6.57188 14.359 6.71563 14.2154C6.85938 14.0718 7.03749 14 7.24998 14H12.75C12.9625 14 13.1406 14.0719 13.2844 14.2157C13.4281 14.3595 13.5 14.5377 13.5 14.7503C13.5 14.9629 13.4281 15.141 13.2844 15.2846C13.1406 15.4282 12.9625 15.5 12.75 15.5H7.24998ZM7.24998 11.5C7.03749 11.5 6.85938 11.4281 6.71563 11.2843C6.57188 11.1404 6.5 10.9622 6.5 10.7497C6.5 10.5371 6.57188 10.359 6.71563 10.2154C6.85938 10.0718 7.03749 10 7.24998 10H16.75C16.9625 10 17.1406 10.0719 17.2844 10.2157C17.4281 10.3595 17.5 10.5377 17.5 10.7503C17.5 10.9629 17.4281 11.141 17.2844 11.2846C17.1406 11.4282 16.9625 11.5 16.75 11.5H7.24998ZM7.24998 7.49995C7.03749 7.49995 6.85938 7.42805 6.71563 7.28425C6.57188 7.14043 6.5 6.96223 6.5 6.74965C6.5 6.53705 6.57188 6.35896 6.71563 6.21538C6.85938 6.07179 7.03749 6 7.24998 6H16.75C16.9625 6 17.1406 6.0719 17.2844 6.2157C17.4281 6.35952 17.5 6.53772 17.5 6.7503C17.5 6.9629 17.4281 7.14099 17.2844 7.28457C17.1406 7.42816 16.9625 7.49995 16.75 7.49995H7.24998Z", fill: "currentColor" }), "IconListOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconListOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsNotes` instead.");
}
export default IconListOutlined;
//# sourceMappingURL=IconListOutlined.js.map