import { jsx as _jsx } from "react/jsx-runtime";
import Box, {} from "@mui/material/Box";
/**
 * React component for containing Material UI React component
 * [`Drawer`](https://mui.com/material-ui/api/drawer) children, ensuring a
 * particular width for the drawer paper contents. It fills the height of the
 * drawer paper and has a similar internal flex layout.
 * @param props Props.
 * @returns React node.
 */
export default function DrawerContainer(props) {
    return (_jsx(Box, { component: "aside", display: "flex", flexDirection: "column", width: 400, maxWidth: "100vw", height: "100%", ...props }));
}
//# sourceMappingURL=DrawerContainer.js.map