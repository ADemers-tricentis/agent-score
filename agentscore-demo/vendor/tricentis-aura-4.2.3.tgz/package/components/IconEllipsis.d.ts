/**
 * React component for an SVG icon of an ellipsis with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsMoreHoriz` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsMoreHoriz.mjs`.
 */
declare const IconEllipsis: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconEllipsis;
