import { type SxProps, type Theme } from "@mui/material/styles";
/**
 * React component for the Tricentis brand mark and text.
 * @param props Props.
 * @returns React node.
 */
export default function Brand({ color, variant, sx, }: {
    /** Logo mark and text fill color. */
    color?: "primary" | "secondary" | "tertiary";
    /**
     * Render the full logo (`full`), just the mark (`mark`), or just the text
     * (`text`).
     */
    variant?: "full" | "mark" | "text";
    /**
     * [Material UI theme aware custom styles](https://mui.com/system/getting-started/the-sx-prop)
     * for the SVG element.
     */
    sx?: SxProps<Theme>;
}): import("react/jsx-runtime").JSX.Element;
