import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon for two stacked rectangles,with the
 * lower one divided in half, representing a dashboard with an outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsTeamDashboard` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsTeamDashboard.mjs`.
 */
const IconTeamDashboardOutlined = createSvgIcon(_jsx("path", { d: "M5.30772 20.5C4.80901 20.5 4.38305 20.3233 4.02985 19.9701C3.67663 19.6169 3.50002 19.191 3.50002 18.6923V5.3077C3.50002 4.80898 3.67663 4.38302 4.02985 4.02982C4.38305 3.67661 4.80901 3.5 5.30772 3.5H18.6923C19.191 3.5 19.617 3.67661 19.9701 4.02982C20.3234 4.38302 20.5 4.80898 20.5 5.3077V18.6923C20.5 19.191 20.3234 19.6169 19.9701 19.9701C19.617 20.3233 19.191 20.5 18.6923 20.5H5.30772ZM10.25 19V12.75H5V18.6923C5 18.782 5.02885 18.8557 5.08655 18.9134C5.14425 18.9711 5.21797 19 5.30772 19H10.25ZM11.75 19H18.6923C18.782 19 18.8557 18.9711 18.9134 18.9134C18.9711 18.8557 19 18.782 19 18.6923V12.75H11.75V19ZM5 11.25H19V5.3077C19 5.21795 18.9711 5.14423 18.9134 5.08653C18.8557 5.02883 18.782 4.99998 18.6923 4.99998H5.30772C5.21797 4.99998 5.14425 5.02883 5.08655 5.08653C5.02885 5.14423 5 5.21795 5 5.3077V11.25Z", fill: "currentColor" }), "IconTeamDashboardOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconTeamDashboardOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsTeamDashboard` instead.");
}
export default IconTeamDashboardOutlined;
//# sourceMappingURL=IconTeamDashboardOutlined.js.map