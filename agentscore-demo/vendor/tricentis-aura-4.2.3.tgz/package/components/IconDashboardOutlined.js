import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of four uneven rectangles nested in a square
 * with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDashboard` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDashboard.mjs`.
 */
const IconDashboardOutlined = createSvgIcon(_jsx("path", { d: "M13.25 8.99998V3.5H20.5V8.99998H13.25ZM3.50003 12.5V3.5H10.75V12.5H3.50003ZM13.25 20.5V11.5H20.5V20.5H13.25ZM3.50003 20.5V15H10.75V20.5H3.50003ZM5.00001 11H9.25003V4.99998H5.00001V11ZM14.75 19H19V13H14.75V19ZM14.75 7.5H19V4.99998H14.75V7.5ZM5.00001 19H9.25003V16.5H5.00001V19Z", fill: "currentColor" }), "IconDashboardOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconDashboardOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsDashboard` instead.");
}
export default IconDashboardOutlined;
//# sourceMappingURL=IconDashboardOutlined.js.map