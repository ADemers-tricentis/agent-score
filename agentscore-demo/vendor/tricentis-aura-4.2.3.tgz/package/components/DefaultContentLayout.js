import { jsx as _jsx } from "react/jsx-runtime";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import isArray from "../utils/private/isArray.js";
/**
 * React component for a responsive layout.
 * @param props Props.
 * @returns React node.
 */
export default function DefaultContentLayout({ cardSx = [], children, contentSx = [], preset = { height: "workspace" }, }) {
    return (_jsx(Card, { sx: [
            (theme) => ({
                margin: theme.spacing(theme.constants.defaultContentLayout?.spacing.marginTop ?? 3),
                ...getDefaultContentLayoutPresetPresetSx(preset, theme),
            }),
            ...(isArray(cardSx) ? cardSx : [cardSx]),
        ], children: _jsx(CardContent, { sx: [
                (theme) => ({
                    height: `calc(100% - ${theme.spacing(theme.constants.defaultContentLayout?.getPX() ?? 6)})`,
                    padding: theme.spacing(theme.constants.defaultContentLayout?.spacing.paddingTop ?? 3),
                    "&:last-child": {
                        paddingBottom: 0,
                    },
                    ...getDefaultContentLayoutPresetPresetSx({ height: "workspace" }, theme),
                }),
                ...(isArray(contentSx) ? contentSx : [contentSx]),
            ], children: children }) }));
}
const getHeightSx = (theme) => {
    const marginTop = theme.constants.defaultContentLayout?.spacing.marginTop ?? 3;
    return Object.fromEntries(theme.breakpoints.keys.map((breakpoint) => [
        breakpoint,
        `calc(100vh - ${theme.spacing(2 * marginTop)} - ${theme.constants.appBar.height[breakpoint]}px)`,
    ]));
};
/**
 * Gets default content layout preset SX styles.
 * @param preset Default content layout preset.
 * @param theme Material UI theme.
 * @returns SX styling object.
 */
function getDefaultContentLayoutPresetPresetSx(preset, theme) {
    switch (preset.height) {
        case "workspace":
            return {
                height: getHeightSx(theme),
            };
        case "min-workspace":
            return {
                minHeight: getHeightSx(theme),
            };
        default:
            return {};
    }
}
//# sourceMappingURL=DefaultContentLayout.js.map