import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a Tosca Commander Table control
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsTableChart` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsTableChart.mjs`.
 */
const IconTableOutlined = createSvgIcon(_jsx("path", { d: "M4.00003 18.6923V5.30773C4.00003 4.81062 4.17704 4.38506 4.53106 4.03106C4.88506 3.67704 5.31061 3.50003 5.80773 3.50003H19.1923C19.6894 3.50003 20.115 3.67704 20.469 4.03106C20.823 4.38506 21 4.81062 21 5.30773V18.6923C21 19.1894 20.823 19.615 20.469 19.969C20.115 20.323 19.6894 20.5 19.1923 20.5H5.80773C5.31061 20.5 4.88506 20.323 4.53106 19.969C4.17704 19.615 4.00003 19.1894 4.00003 18.6923ZM5.50001 9.07693H19.5V5.30773C19.5 5.21798 19.4712 5.14426 19.4135 5.08656C19.3558 5.02886 19.282 5.00001 19.1923 5.00001H5.80773C5.71798 5.00001 5.64426 5.02886 5.58656 5.08656C5.52886 5.14426 5.50001 5.21798 5.50001 5.30773V9.07693ZM10.6615 14.0385H14.3385V10.5769H10.6615V14.0385ZM10.6615 19H14.3385V15.5384H10.6615V19ZM5.50001 14.0385H9.16158V10.5769H5.50001V14.0385ZM15.8384 14.0385H19.5V10.5769H15.8384V14.0385ZM5.80773 19H9.16158V15.5384H5.50001V18.6923C5.50001 18.782 5.52886 18.8558 5.58656 18.9135C5.64426 18.9712 5.71798 19 5.80773 19ZM15.8384 19H19.1923C19.282 19 19.3558 18.9712 19.4135 18.9135C19.4712 18.8558 19.5 18.782 19.5 18.6923V15.5384H15.8384V19Z", fill: "currentColor" }), "IconTableOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconTableOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsTableChart` instead.");
}
export default IconTableOutlined;
//# sourceMappingURL=IconTableOutlined.js.map