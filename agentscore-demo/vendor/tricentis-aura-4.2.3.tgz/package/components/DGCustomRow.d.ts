import { type GridRowModel, type GridRowProps } from "@mui/x-data-grid-pro";
import type { ComponentPropsWithoutRef } from "react";
import DGContextMenu from "./private/DGContextMenu.js";
/**
 * React component for a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) row that has a
 * context menu.
 * @param props Props.
 * @returns React node.
 */
export default function DGCustomRow<Row extends GridRowModel>({ contextMenu, onRightClickSelectedRow, ...props }: {
    /** Context menu items. */
    contextMenu?: ComponentPropsWithoutRef<typeof DGContextMenu>["contextMenu"];
    /** Callback invoked when the context menu is triggered. */
    onRightClickSelectedRow?: (
    /** Selected data grid row model. */
    selectedRow: Row) => void;
    /** Data grid row model. */
    row: Row;
} & Omit<GridRowProps, "row">): import("react/jsx-runtime").JSX.Element;
