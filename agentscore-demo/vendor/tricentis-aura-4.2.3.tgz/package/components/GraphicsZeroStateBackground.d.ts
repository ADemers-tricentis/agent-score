/**
 * React component for an SVG for the zero state background.
 * @returns React node.
 */
export default function GraphicsZeroStateBackground(): import("react/jsx-runtime").JSX.Element;
