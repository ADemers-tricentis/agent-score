import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { styled } from "@mui/material/styles";
/**
 * React component for the Tricentis brand mark.
 * @param props Props.
 * @returns React node.
 */
export default function BrandMark({ sx, }) {
    return (_jsxs(Svg, { viewBox: "0 0 24 24", className: "BrandMark", "data-testid": "BrandMark", sx: sx, children: [_jsx("path", { className: "BrandMark-background", d: "M0 4a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v16a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4Z" }), _jsx("path", { className: "BrandMark-text", d: "m6.735 16.65-1.86-1.86 2.796-2.795L4.896 9.22l1.86-1.86 4.635 4.635-4.656 4.655Zm2.857 2.856-1.86-1.86 4.657-4.654 4.636 4.634-1.86 1.859-2.776-2.774-2.797 2.795Zm2.779-8.491L7.736 6.38l1.86-1.859 2.775 2.775L15.168 4.5l1.86 1.86-4.657 4.655Z" })] }));
}
const Svg = styled("svg")(({ theme }) => ({
    "&.BrandMark": {
        "& .BrandMark-background": {
            fill: theme.vars.palette.aura.brand,
        },
        "& .BrandMark-text": {
            fill: theme.vars.palette.aura.brandInverted,
        },
    },
}));
//# sourceMappingURL=BrandMark.js.map