import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a testcase radio button with
 * outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsRadioButtonChecked` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsRadioButtonChecked.mjs`.
 */
const IconTestCaseRadioButtonOutlined = createSvgIcon(_jsx("path", { d: "M12.5 16.5C13.7487 16.5 14.8109 16.0622 15.6865 15.1865C16.5622 14.3109 17 13.2487 17 12C17 10.7513 16.5622 9.68912 15.6865 8.81347C14.8109 7.93784 13.7487 7.50002 12.5 7.50002C11.2513 7.50002 10.1891 7.93784 9.31348 8.81347C8.43785 9.68912 8.00003 10.7513 8.00003 12C8.00003 13.2487 8.43785 14.3109 9.31348 15.1865C10.1891 16.0622 11.2513 16.5 12.5 16.5ZM12.5017 21.5C11.1877 21.5 9.95271 21.2506 8.79658 20.752C7.64043 20.2533 6.63475 19.5766 5.77953 18.7217C4.9243 17.8669 4.24724 16.8616 3.74836 15.706C3.24947 14.5504 3.00003 13.3156 3.00003 12.0017C3.00003 10.6877 3.24936 9.45271 3.74803 8.29657C4.2467 7.14042 4.92345 6.13474 5.77828 5.27952C6.63313 4.42429 7.63837 3.74723 8.79401 3.24835C9.94962 2.74947 11.1844 2.50002 12.4983 2.50002C13.8123 2.50002 15.0473 2.74936 16.2034 3.24802C17.3596 3.74669 18.3653 4.42344 19.2205 5.27827C20.0757 6.13312 20.7528 7.13837 21.2517 8.294C21.7505 9.44962 22 10.6844 22 11.9983C22 13.3123 21.7506 14.5473 21.252 15.7034C20.7533 16.8596 20.0766 17.8653 19.2217 18.7205C18.3669 19.5757 17.3616 20.2528 16.206 20.7516C15.0504 21.2505 13.8156 21.5 12.5017 21.5ZM12.5 20C14.7333 20 16.625 19.225 18.175 17.675C19.725 16.125 20.5 14.2333 20.5 12C20.5 9.76667 19.725 7.875 18.175 6.325C16.625 4.775 14.7333 4 12.5 4C10.2667 4 8.37501 4.775 6.82501 6.325C5.27501 7.875 4.50001 9.76667 4.50001 12C4.50001 14.2333 5.27501 16.125 6.82501 17.675C8.37501 19.225 10.2667 20 12.5 20Z", fill: "currentColor" }), "IconRadioButtonOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconTestCaseRadioButtonOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsRadioButtonChecked` instead.");
}
export default IconTestCaseRadioButtonOutlined;
//# sourceMappingURL=IconTestCaseRadioButtonOutlined.js.map