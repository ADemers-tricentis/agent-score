import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of adding a link.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAddLink` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAddLink.mjs`.
 */
const IconAddLinkOutlined = createSvgIcon(_jsx("path", { d: "M17.0385 18.0192V15.0577H14.0769V13.5577H17.0385V10.5962H18.5384V13.5577H21.5V15.0577H18.5384V18.0192H17.0385ZM10.8077 15.0577H7.03847C5.78284 15.0577 4.71252 14.6152 3.82752 13.7304C2.94252 12.8455 2.50002 11.7753 2.50002 10.5198C2.50002 9.26433 2.94252 8.19396 3.82752 7.30871C4.71252 6.42346 5.78284 5.98083 7.03847 5.98083H10.8077V7.48078H7.03847C6.19872 7.48078 5.48237 7.77726 4.88942 8.37021C4.29647 8.96316 4 9.67951 4 10.5193C4 11.359 4.29647 12.0754 4.88942 12.6683C5.48237 13.2613 6.19872 13.5577 7.03847 13.5577H10.8077V15.0577ZM8.25002 11.2692V9.76928H15.75V11.2692H8.25002ZM21.5 10.5193H20C20 9.67951 19.7035 8.96316 19.1106 8.37021C18.5176 7.77726 17.8013 7.48078 16.9615 7.48078H13.1923V5.98083H16.9615C18.2172 5.98083 19.2875 6.42333 20.1725 7.30831C21.0575 8.19331 21.5 9.26363 21.5 10.5193Z", fill: "currentColor" }), "IconAddLinkOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconAddLinkOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsAddLink` instead.");
}
export default IconAddLinkOutlined;
//# sourceMappingURL=IconAddLinkOutlined.js.map