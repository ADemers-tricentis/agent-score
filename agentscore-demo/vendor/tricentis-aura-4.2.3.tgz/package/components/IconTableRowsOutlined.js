import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of a Tosca Commander Table row control  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsTableRows` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsTableRows.mjs`.
 */
const IconTableRowsOutlined = createSvgIcon(_jsx("path", { d: "M19.5 18.6923V15.6634H5.49997V18.6923C5.49997 18.782 5.52883 18.8557 5.58653 18.9134C5.64423 18.9711 5.71795 19 5.8077 19H19.1923C19.282 19 19.3557 18.9711 19.4134 18.9134C19.4711 18.8557 19.5 18.782 19.5 18.6923ZM19.5 14.1635V9.8365H5.49997V14.1635H19.5ZM19.5 8.33655V5.3077C19.5 5.21795 19.4711 5.14423 19.4134 5.08653C19.3557 5.02883 19.282 4.99998 19.1923 4.99998H5.8077C5.71795 4.99998 5.64423 5.02883 5.58653 5.08653C5.52883 5.14423 5.49997 5.21795 5.49997 5.3077V8.33655H19.5ZM5.8077 20.5C5.30257 20.5 4.875 20.325 4.525 19.975C4.175 19.625 4 19.1974 4 18.6923V5.3077C4 4.80257 4.175 4.375 4.525 4.025C4.875 3.675 5.30257 3.5 5.8077 3.5H19.1923C19.6974 3.5 20.125 3.675 20.475 4.025C20.825 4.375 21 4.80257 21 5.3077V18.6923C21 19.1974 20.825 19.625 20.475 19.975C20.125 20.325 19.6974 20.5 19.1923 20.5H5.8077Z", fill: "currentColor" }), "IconTableRowsOutlined");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconTableRowsOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsTableRows` instead.");
}
export default IconTableRowsOutlined;
//# sourceMappingURL=IconTableRowsOutlined.js.map