/**
 * React component for an SVG icon of a downward-pointing arrow in a square
 * with an outlined style.
 */
declare const IconExpandDownOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconExpandDownOutlined;
