/** React component for a subtle chip that represents a status. */
declare const ChipStatus: import("react").ForwardRefExoticComponent<{
    /** Status that the chip represents. */
    status: typeof STATUS_ACTIVE | typeof STATUS_CANCELED | typeof STATUS_DRAFT | typeof STATUS_FAILED | typeof STATUS_NOT_APPLICABLE | typeof STATUS_PASSED | typeof STATUS_PENDING | typeof STATUS_READY | typeof STATUS_RUNNING;
} & Omit<Omit<Omit<Omit<import("@mui/material/Chip").ChipOwnProps & import("@mui/material/Chip").ChipSlotsAndSlotProps & import("@mui/material/OverridableComponent").CommonProps & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "color" | "variant" | "sx" | "label" | "style" | "children" | "className" | "classes" | "icon" | "tabIndex" | "disabled" | "avatar" | "clickable" | "deleteIcon" | "onDelete" | "size" | "skipFocusWhenDisabled" | "slots" | "slotProps">, "ref">, "variant"> & import("react").RefAttributes<HTMLDivElement>, "ref">, "color" | "avatar" | "deleteIcon" | "onDelete"> & import("react").RefAttributes<HTMLDivElement>>;
export default ChipStatus;
declare const STATUS_ACTIVE = "Active";
declare const STATUS_CANCELED = "Canceled";
declare const STATUS_DRAFT = "Draft";
declare const STATUS_FAILED = "Failed";
declare const STATUS_NOT_APPLICABLE = "NotApplicable";
declare const STATUS_PASSED = "Passed";
declare const STATUS_PENDING = "Pending";
declare const STATUS_READY = "Ready";
declare const STATUS_RUNNING = "Running";
