import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a rigiht-pointing arrow head with filled
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsArrowRight` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowRight.mjs`.
 */
const IconArrowRightFilled = createSvgIcon(_jsxs(_Fragment, { children: [_jsx("g", { clipPath: "url(#clip0_11310_428490)", children: _jsx("path", { d: "M10 17L15 12L10 7V17Z", fill: "currentColor" }) }), _jsx("defs", { children: _jsx("clipPath", { id: "clip0_11310_428490", children: _jsx("rect", { width: "24", height: "24", fill: "white" }) }) })] }), "IconArrowRightFilled");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconArrowRightFilled` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsArrowRight` instead.");
}
export default IconArrowRightFilled;
//# sourceMappingURL=IconArrowRightFilled.js.map