import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of two uneven rectangles stacked horizontally
 * with an outlined style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDockToLeft` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDockToLeft.mjs`.
 */
const IconDockToLeftOutlined = createSvgIcon(_jsx("path", { d: "M5.30773 20.5C4.80901 20.5 4.38306 20.3233 4.02986 19.9701C3.67664 19.6169 3.50003 19.191 3.50003 18.6923V5.3077C3.50003 4.80898 3.67664 4.38302 4.02986 4.02982C4.38306 3.67661 4.80901 3.5 5.30773 3.5H18.6923C19.191 3.5 19.617 3.67661 19.9702 4.02982C20.3234 4.38302 20.5 4.80898 20.5 5.3077V18.6923C20.5 19.191 20.3234 19.6169 19.9702 19.9701C19.617 20.3233 19.191 20.5 18.6923 20.5H5.30773ZM16 19H19V5.3077C19 5.23077 18.968 5.16024 18.9039 5.09613C18.8397 5.03203 18.7692 4.99998 18.6923 4.99998H16V19ZM14.5 19V4.99998H5.30773C5.2308 4.99998 5.16027 5.03203 5.09616 5.09613C5.03206 5.16024 5.00001 5.23077 5.00001 5.3077V18.6923C5.00001 18.7692 5.03206 18.8397 5.09616 18.9038C5.16027 18.9679 5.2308 19 5.30773 19H14.5Z", fill: "currentColor" }), "IconDockToLeftOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconDockToLeftOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsDockToLeft` instead.");
}
export default IconDockToLeftOutlined;
//# sourceMappingURL=IconDockToLeftOutlined.js.map