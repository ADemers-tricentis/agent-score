import { jsx as _jsx } from "react/jsx-runtime";
import Box, {} from "@mui/material/Box";
import Typography from "@mui/material/Typography";
/**
 * React component for a drawer header. Intended for use as a child of the Aura
 * React component `DrawerContainer`.
 * @param props Props.
 * @returns React node.
 */
export default function DrawerHeader({ heading, ...props }) {
    return (_jsx(Box, { component: "header", px: 2, py: 1, ...props, children: _jsx(Typography, { variant: "h4", children: heading }) }));
}
//# sourceMappingURL=DrawerHeader.js.map