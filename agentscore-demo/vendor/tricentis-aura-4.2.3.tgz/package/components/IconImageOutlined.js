import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a square with two triangles at the
 * bottom representing an image or a picture with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsImage` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsImage.mjs`.
 */
const IconImageOutlined = createSvgIcon(_jsx("path", { d: "M5.30773 20.5C4.8026 20.5 4.37503 20.325 4.02503 19.975C3.67503 19.625 3.50003 19.1974 3.50003 18.6923V5.3077C3.50003 4.80257 3.67503 4.375 4.02503 4.025C4.37503 3.675 4.8026 3.5 5.30773 3.5H18.6923C19.1974 3.5 19.625 3.675 19.975 4.025C20.325 4.375 20.5 4.80257 20.5 5.3077V18.6923C20.5 19.1974 20.325 19.625 19.975 19.975C19.625 20.325 19.1974 20.5 18.6923 20.5H5.30773ZM5.30773 19H18.6923C18.7692 19 18.8397 18.9679 18.9039 18.9038C18.968 18.8397 19 18.7692 19 18.6923V5.3077C19 5.23077 18.968 5.16024 18.9039 5.09613C18.8397 5.03203 18.7692 4.99998 18.6923 4.99998H5.30773C5.2308 4.99998 5.16027 5.03203 5.09616 5.09613C5.03206 5.16024 5.00001 5.23077 5.00001 5.3077V18.6923C5.00001 18.7692 5.03206 18.8397 5.09616 18.9038C5.16027 18.9679 5.2308 19 5.30773 19ZM6.75006 16.75H17.3269L14.0385 12.3654L11.2308 16.0192L9.23078 13.4616L6.75006 16.75Z", fill: "currentColor" }), "IconImageOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconImageOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsImage` instead.");
}
export default IconImageOutlined;
//# sourceMappingURL=IconImageOutlined.js.map