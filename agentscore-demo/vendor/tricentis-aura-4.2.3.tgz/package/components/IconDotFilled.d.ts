/**
 * React component for an SVG icon of a small centered dot.  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCircle` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCircle.mjs`.
 */
declare const IconDotFilled: import("@mui/material/OverridableComponent.js").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDotFilled;
