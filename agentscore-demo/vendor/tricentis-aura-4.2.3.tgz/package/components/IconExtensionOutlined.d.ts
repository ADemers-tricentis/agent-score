/**
 * React component for an SVG icon of a puzzle or extension symbol with outline
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsExtension` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsExtension.mjs`.
 */
declare const IconExtensionOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconExtensionOutlined;
