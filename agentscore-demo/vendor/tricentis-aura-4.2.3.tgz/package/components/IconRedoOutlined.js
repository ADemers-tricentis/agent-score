import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of an arrow in a circular motion moving
 * forward with an outlined style..
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsRedo` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsRedo.mjs`.
 */
const IconRedoOutlined = createSvgIcon(_jsx("path", { d: "M9.62112 18.5C8.15832 18.5 6.90545 18.0102 5.8625 17.0307C4.81956 16.0512 4.2981 14.8455 4.2981 13.4134C4.2981 11.9814 4.81956 10.7772 5.8625 9.80095C6.90545 8.82468 8.15832 8.33655 9.62112 8.33655H16.6423L13.8596 5.55383L14.9134 4.5L19.5 9.08652L14.9134 13.673L13.8596 12.6192L16.6423 9.8365H9.62112C8.57754 9.8365 7.67946 10.1795 6.9269 10.8654C6.17433 11.5513 5.79805 12.4006 5.79805 13.4134C5.79805 14.4262 6.17433 15.2772 6.9269 15.9663C7.67946 16.6554 8.57754 17 9.62112 17H16.798V18.5H9.62112Z", fill: "currentColor" }), "IconRedoOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconRedoOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsRedo` instead.");
}
export default IconRedoOutlined;
//# sourceMappingURL=IconRedoOutlined.js.map