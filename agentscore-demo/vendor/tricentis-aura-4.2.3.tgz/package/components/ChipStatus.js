import { jsx as _jsx } from "react/jsx-runtime";
import { forwardRef } from "react";
import IconStatusActive from "../constants/IconStatusActive.js";
import IconStatusCanceled from "../constants/IconStatusCanceled.js";
import IconStatusDraft from "../constants/IconStatusDraft.js";
import IconStatusFailed from "../constants/IconStatusFailed.js";
import IconStatusNotApplicable from "../constants/IconStatusNotApplicable.js";
import IconStatusPassed from "../constants/IconStatusPassed.js";
import IconStatusPending from "../constants/IconStatusPending.js";
import IconStatusReady from "../constants/IconStatusReady.js";
import IconStatusRunning from "../constants/IconStatusRunning.js";
import ChipSubtle from "./ChipSubtle.js";
/** React component for a subtle chip that represents a status. */
const ChipStatus = forwardRef(({ status, ...props }, forwardedRef) => {
    switch (status) {
        case STATUS_ACTIVE:
            return (_jsx(ChipSubtle, { ref: forwardedRef, color: "success", icon: _jsx(IconStatusActive, {}), label: STATUS_ACTIVE, ...props }));
        case STATUS_CANCELED:
            return (_jsx(ChipSubtle, { ref: forwardedRef, icon: _jsx(IconStatusCanceled, {}), label: STATUS_CANCELED, ...props }));
        case STATUS_DRAFT:
            return (_jsx(ChipSubtle, { ref: forwardedRef, icon: _jsx(IconStatusDraft, {}), label: STATUS_DRAFT, ...props }));
        case STATUS_FAILED:
            return (_jsx(ChipSubtle, { ref: forwardedRef, color: "error", icon: _jsx(IconStatusFailed, {}), label: STATUS_FAILED, ...props }));
        case STATUS_NOT_APPLICABLE:
            return (_jsx(ChipSubtle, { ref: forwardedRef, icon: _jsx(IconStatusNotApplicable, {}), label: "N/A", ...props }));
        case STATUS_PASSED:
            return (_jsx(ChipSubtle, { ref: forwardedRef, color: "success", icon: _jsx(IconStatusPassed, {}), label: STATUS_PASSED, ...props }));
        case STATUS_PENDING:
            return (_jsx(ChipSubtle, { ref: forwardedRef, color: "warning", icon: _jsx(IconStatusPending, {}), label: STATUS_PENDING, ...props }));
        case STATUS_READY:
            return (_jsx(ChipSubtle, { ref: forwardedRef, color: "primary", icon: _jsx(IconStatusReady, {}), label: STATUS_READY, ...props }));
        case STATUS_RUNNING:
            return (_jsx(ChipSubtle, { ref: forwardedRef, color: "primary", icon: _jsx(IconStatusRunning, {}), label: STATUS_RUNNING, ...props }));
    }
});
export default ChipStatus;
const STATUS_ACTIVE = "Active";
const STATUS_CANCELED = "Canceled";
const STATUS_DRAFT = "Draft";
const STATUS_FAILED = "Failed";
const STATUS_NOT_APPLICABLE = "NotApplicable";
const STATUS_PASSED = "Passed";
const STATUS_PENDING = "Pending";
const STATUS_READY = "Ready";
const STATUS_RUNNING = "Running";
//# sourceMappingURL=ChipStatus.js.map