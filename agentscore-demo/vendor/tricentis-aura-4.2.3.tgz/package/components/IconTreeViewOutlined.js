import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of multiple boxes linked together.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAccountTree` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAccountTree.mjs`.
 */
const IconTreeViewOutlined = createSvgIcon(_jsx("path", { d: "M15.25 20.75V17.75H11.25V7.74995H8.74998V10.75H2.25003V3.25H8.74998V6.25H15.25V3.25H21.75V10.75H15.25V7.74995H12.75V16.25H15.25V13.25H21.75V20.75H15.25ZM16.75 9.25H20.25V4.74995H16.75V9.25ZM16.75 19.25H20.25V14.75H16.75V19.25ZM3.74998 9.25H7.25003V4.74995H3.74998V9.25Z", fill: "currentColor" }), "IconTreeViewOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconTreeViewOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsAccountTree` instead.");
}
export default IconTreeViewOutlined;
//# sourceMappingURL=IconTreeViewOutlined.js.map