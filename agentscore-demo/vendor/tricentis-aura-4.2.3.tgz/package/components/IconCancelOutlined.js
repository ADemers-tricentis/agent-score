import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a cancel, fail, x, close symbol with
 * outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCancel` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCancel.mjs`.
 */
const IconCancelOutlined = createSvgIcon(_jsx("path", { d: "M8.28814 17.085L12.125 13.2481L15.9618 17.085L17.085 15.9618L13.2481 12.125L17.085 8.28814L15.9618 7.16498L12.125 11.0018L8.28814 7.16498L7.16498 8.28814L11.0018 12.125L7.16498 15.9618L8.28814 17.085ZM12.1268 22.25C10.7264 22.25 9.4101 21.9842 8.17791 21.4528C6.94569 20.9213 5.87385 20.2 4.96236 19.2889C4.05087 18.3778 3.32926 17.3065 2.79756 16.0748C2.26585 14.8432 2 13.5271 2 12.1268C2 10.7264 2.26574 9.4101 2.79721 8.17791C3.32869 6.94569 4.04996 5.87385 4.96103 4.96236C5.87212 4.05086 6.9435 3.32926 8.17516 2.79756C9.40681 2.26585 10.7228 2 12.1232 2C13.5236 2 14.8399 2.26574 16.0721 2.79721C17.3043 3.32869 18.3761 4.04996 19.2876 4.96103C20.1991 5.87212 20.9207 6.9435 21.4524 8.17516C21.9841 9.40681 22.25 10.7228 22.25 12.1232C22.25 13.5236 21.9842 14.8399 21.4528 16.0721C20.9213 17.3043 20.2 18.3761 19.2889 19.2876C18.3778 20.1991 17.3065 20.9207 16.0748 21.4524C14.8432 21.9841 13.5271 22.25 12.1268 22.25ZM12.125 20.6513C14.5052 20.6513 16.5214 19.8253 18.1733 18.1733C19.8253 16.5214 20.6513 14.5052 20.6513 12.125C20.6513 9.74472 19.8253 7.7286 18.1733 6.07662C16.5214 4.42465 14.5052 3.59866 12.125 3.59866C9.74472 3.59866 7.7286 4.42465 6.07662 6.07662C4.42465 7.7286 3.59866 9.74472 3.59866 12.125C3.59866 14.5052 4.42465 16.5214 6.07662 18.1733C7.7286 19.8253 9.74472 20.6513 12.125 20.6513Z", fill: "currentColor" }), "IconCancelOutlined");
import checkIsInternalImport from "../utils/private/isInternalImport.js";
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconCancelOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsCancel` instead.");
}
export default IconCancelOutlined;
//# sourceMappingURL=IconCancelOutlined.js.map