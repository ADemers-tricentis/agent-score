/**
 * React component for an SVG icon of a chevron up down with outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsUnfoldMore` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsUnfoldMore.mjs`.
 */
declare const IconChevronUpDownOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconChevronUpDownOutlined;
