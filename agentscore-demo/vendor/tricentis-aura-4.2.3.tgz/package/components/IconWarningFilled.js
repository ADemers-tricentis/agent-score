import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a triangle with an exclamation mark at
 * the center with a filled style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsWarning` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsWarning.mjs`.
 */
const IconWarningFilled = createSvgIcon(_jsx("path", { d: "M1.86548 20.4999L12 3L22.1346 20.4999H1.86548ZM12 17.8076C12.2289 17.8076 12.4207 17.7302 12.5755 17.5754C12.7303 17.4206 12.8077 17.2288 12.8077 16.9999C12.8077 16.7711 12.7303 16.5793 12.5755 16.4245C12.4207 16.2697 12.2289 16.1923 12 16.1923C11.7712 16.1923 11.5794 16.2697 11.4246 16.4245C11.2698 16.5793 11.1924 16.7711 11.1924 16.9999C11.1924 17.2288 11.2698 17.4206 11.4246 17.5754C11.5794 17.7302 11.7712 17.8076 12 17.8076ZM11.2501 15.1923H12.75V10.1923H11.2501V15.1923Z", fill: "currentColor" }), "IconWarningFilled");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconWarningFilled` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsWarning` instead.");
}
export default IconWarningFilled;
//# sourceMappingURL=IconWarningFilled.js.map