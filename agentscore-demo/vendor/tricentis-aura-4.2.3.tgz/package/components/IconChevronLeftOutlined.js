import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of left-pointing arrow head, less than,
 * left, west or left chevron with outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsChevronLeft` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsChevronLeft.mjs`.
 */
const IconChevronLeftOutlined = createSvgIcon(_jsx("path", { d: "M10.7201 11.9976L14.7932 16.0707C14.9316 16.2091 15.0025 16.3832 15.0057 16.5928C15.0089 16.8024 14.9381 16.9796 14.7932 17.1245C14.6483 17.2694 14.4727 17.3418 14.2663 17.3418C14.0599 17.3418 13.8842 17.2694 13.7394 17.1245L9.24515 12.6303C9.15155 12.5367 9.08553 12.438 9.04708 12.3341C9.00861 12.2303 8.98938 12.1181 8.98938 11.9976C8.98938 11.8771 9.00861 11.7649 9.04708 11.6611C9.08553 11.5572 9.15155 11.4585 9.24515 11.3649L13.7394 6.87069C13.8778 6.73222 14.0519 6.66139 14.2615 6.65819C14.4711 6.65497 14.6483 6.7258 14.7932 6.87069C14.9381 7.01555 15.0105 7.19119 15.0105 7.39759C15.0105 7.60399 14.9381 7.77962 14.7932 7.92449L10.7201 11.9976Z", fill: "currentColor" }), "IconChevronLeftOutlined");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconChevronLeftOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsChevronLeft` instead.");
}
export default IconChevronLeftOutlined;
//# sourceMappingURL=IconChevronLeftOutlined.js.map