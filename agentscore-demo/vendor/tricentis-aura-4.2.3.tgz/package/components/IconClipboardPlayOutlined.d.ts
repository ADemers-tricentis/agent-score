/**
 * React component for an SVG icon of a clipboard with a play button in an
 * outlined style.
 *
 * It serves as the `PlaylistsOutlined` icon in Tosca Cloud.
 */
declare const IconClipboardPlayOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconClipboardPlayOutlined;
