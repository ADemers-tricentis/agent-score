import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import Box, {} from "@mui/material/Box";
import Collapse from "@mui/material/Collapse";
import Divider from "@mui/material/Divider";
import Drawer from "@mui/material/Drawer";
import IconButton, {} from "@mui/material/IconButton";
import List from "@mui/material/List";
import ListItemButton, {} from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Popover, {} from "@mui/material/Popover";
import { styled } from "@mui/material/styles";
import Tooltip from "@mui/material/Tooltip";
import IconMaterialSymbolsArrowDropDown from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowDropDown.mjs";
import IconMaterialSymbolsChevronLeft from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsChevronLeft.mjs";
import IconMaterialSymbolsChevronRight from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsChevronRight.mjs";
import IconMaterialSymbolsKeyboardArrowDown from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsKeyboardArrowDown.mjs";
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, } from "react";
/**
 * React component which provides users with easy access to different sections
 * or pages of the application. It appears as a vertical bar on the left side
 * of the screen, containing links or icons that represent various destinations
 * or sections within the application. Users can click or tap on these links or
 * icons to navigate to their desired location.
 * @param props Props.
 * @returns React node.
 */
export default function NavRail({ clipped, items, onToggle, open: initialOpen, width, isChangeSelectedDisabled, toggleTooltips = { expand: "Expand", collapse: "Collapse" }, }) {
    const [open, setOpen] = useState(false);
    const [selected, setSelected] = useState(undefined);
    const listRef = useRef(null);
    useEffect(() => {
        setOpen(initialOpen ?? false);
    }, [initialOpen]);
    useEffect(() => {
        const selectedIndex = items.findIndex((item) => item.selected);
        setSelected(selectedIndex !== -1 ? items[selectedIndex].id : undefined);
    }, [items]);
    useLayoutEffect(() => {
        if (selected)
            updateIndicatorPosition(listRef.current);
    }, [selected]);
    useLayoutEffect(() => {
        updateIndicatorPosition(listRef.current, false);
    }, [open]);
    const onClickToggleOpenIconButton = useCallback(() => {
        const newOpen = !open;
        setOpen(newOpen);
        onToggle?.(newOpen);
    }, [onToggle, open]);
    const onClickSetSelected = useCallback((itemId) => {
        if (!isChangeSelectedDisabled) {
            setSelected(itemId);
        }
    }, [isChangeSelectedDisabled]);
    return (_jsxs(NavRailDrawer, { variant: "permanent", open: open, clipped: clipped, width: width ?? 240, slotProps: {
            paper: {
                elevation: 0,
                sx: {
                    display: "flex",
                    flexDirection: "column",
                    borderRight: open ? "none" : undefined,
                    // Reset border radius due to the override in the drawer paper.
                    borderTopLeftRadius: 0,
                    borderBottomLeftRadius: 0,
                    borderTopRightRadius: open
                        ? (theme) => theme.aura.borderRadius.lg
                        : 0,
                    borderBottomRightRadius: open
                        ? (theme) => theme.aura.borderRadius.lg
                        : 0,
                    boxShadow: open ? "0px 4px 30px rgba(157, 167, 181, 0.2)" : "",
                    backgroundColor: (theme) => theme.vars.palette.aura.navigationBackground,
                },
            },
        }, children: [_jsx(NavRailDrawerList, { className: open ? "Mui-NavRail-open" : "", ref: listRef, children: items.map((item) => item.variant === "divider" ? (_jsx("li", { children: _jsx(Divider, { variant: "fullWidth" }) }, item.id)) : (_jsx(NavRailListItem, { className: "Mui-NavRailItem-firstLevel", item: item, onClick: onClickSetSelected, selected: selected, open: open }, item.id))) }), _jsx(Box, { display: "flex", justifyContent: open ? "flex-end" : "center", marginTop: "auto", children: _jsx(IconButton, { "aria-label": open ? toggleTooltips.collapse : toggleTooltips.expand, onClick: onClickToggleOpenIconButton, children: open ? (_jsx(Tooltip, { title: toggleTooltips.collapse, arrow: true, children: _jsx(IconMaterialSymbolsChevronLeft, { color: "action" }) })) : (_jsx(Tooltip, { title: toggleTooltips.expand, arrow: true, placement: "right-end", children: _jsx(IconMaterialSymbolsChevronRight, { color: "action" }) })) }) })] }));
}
const NavRailDrawer = styled(Drawer, {
    shouldForwardProp: (prop) => !["clipped", "open"].includes(prop),
})(({ clipped, open, theme, width }) => ({
    flexShrink: 0,
    boxSizing: "border-box",
    width,
    whiteSpace: "nowrap",
    "& > *": {
        boxSizing: "border-box",
    },
    ...(open
        ? {
            ...openedMixin(theme, false, width),
            "& .MuiDrawer-paper": openedMixin(theme, clipped ?? false, width),
        }
        : {
            ...closedMixin(theme, false),
            "& .MuiDrawer-paper": closedMixin(theme, clipped ?? false),
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
        }),
}));
/**
 * Generates Material UI SX styles for an open drawer, including padding, width,
 * transition effects, and positioning, to be used in the animation of expanding
 * the drawer.
 * @param theme Material UI theme.
 * @param clipped Is the drawer clipped.
 * @param drawerWidth Drawer width, in pixels.
 * @returns Material UI SX styles for an open drawer.
 */
const openedMixin = (theme, clipped, drawerWidth) => ({
    width: drawerWidth,
    paddingInline: theme.spacing(1.5),
    paddingBlock: theme.spacing(1.5),
    overflowX: "hidden",
    transition: theme.transitions.create("all", {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
    }),
    ...(clipped
        ? {
            top: `${theme.constants.appBar.height.xs}px`,
            height: `calc(100% - ${theme.constants.appBar.height.xs}px)`,
            zIndex: theme.vars.zIndex.appBar - 1,
            [theme.breakpoints.up("sm")]: {
                top: `${theme.constants.appBar.height.sm}px`,
                height: `calc(100% - ${theme.constants.appBar.height.sm}px)`,
            },
            [theme.breakpoints.up("md")]: {
                top: `${theme.constants.appBar.height.md}px`,
                height: `calc(100% - ${theme.constants.appBar.height.md}px)`,
            },
            [theme.breakpoints.up("lg")]: {
                top: `${theme.constants.appBar.height.lg}px`,
                height: `calc(100% - ${theme.constants.appBar.height.lg}px)`,
            },
            [theme.breakpoints.up("xl")]: {
                top: `${theme.constants.appBar.height.xl}px`,
                height: `calc(100% - ${theme.constants.appBar.height.xl}px)`,
            },
        }
        : {}),
});
/**
 * Generates Material UI SX styles for a closed drawer, including padding,
 * width, transition effects, and positioning, to be used in the animation of
 * collapsing the drawer.
 * @param theme Material UI theme.
 * @param clipped Is the drawer clipped.
 * @returns Material UI SX styles for a closed drawer.
 */
const closedMixin = (theme, clipped) => ({
    width: `calc(${theme.spacing(7)} + 1px)`,
    paddingInline: theme.spacing(0.5),
    paddingBlock: theme.spacing(1.5),
    overflowX: "hidden",
    transition: theme.transitions.create("all", {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    ...(clipped
        ? {
            top: `${theme.constants.appBar.height.xs}px`,
            height: `calc(100% - ${theme.constants.appBar.height.xs}px)`,
            zIndex: theme.vars.zIndex.appBar - 1,
            [theme.breakpoints.up("sm")]: {
                top: `${theme.constants.appBar.height.sm}px`,
                width: `calc(${theme.spacing(7)} + 1px)`,
                height: `calc(100% - ${theme.constants.appBar.height.sm}px)`,
            },
            [theme.breakpoints.up("md")]: {
                top: `${theme.constants.appBar.height.md}px`,
                height: `calc(100% - ${theme.constants.appBar.height.md}px)`,
            },
            [theme.breakpoints.up("lg")]: {
                top: `${theme.constants.appBar.height.lg}px`,
                height: `calc(100% - ${theme.constants.appBar.height.lg}px)`,
            },
            [theme.breakpoints.up("xl")]: {
                top: `${theme.constants.appBar.height.xl}px`,
                height: `calc(100% - ${theme.constants.appBar.height.xl}px)`,
            },
        }
        : {
            [theme.breakpoints.up("sm")]: {
                width: `calc(${theme.spacing(7)} + 1px)`,
            },
        }),
});
/**
 * Updates the position of an indicator within a list element to highlight
 * the selected item, optionally with an animation.
 * @param listElement List element containing the items.
 * @param visible Is the indicator position update to be animated.
 */
function updateIndicatorPosition(listElement, visible = true) {
    // Check if the list element exists.
    if (listElement) {
        if (visible)
            // Add a CSS class for animating the indicator.
            listElement.classList.add("animating-indicator");
        // Use `requestAnimationFrame` for smoother animations.
        requestAnimationFrame(() => {
            // Find the selected item within the list.
            const selectedElement = listElement.querySelector(":scope > .MuiBox-root > .Mui-selected");
            // If a selected item is found, calculate and set the indicator’s top
            // position.
            if (selectedElement) {
                const top = 
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-expect-error
                selectedElement.offsetTop -
                    parseInt(getComputedStyle(listElement).paddingTop, 10);
                listElement.style.setProperty("--selected-item-top", String(top));
            }
            if (visible) {
                // Remove the animation class after a short delay (300 milliseconds).
                setTimeout(() => {
                    listElement.classList.remove("animating-indicator");
                }, 300);
            }
        });
    }
}
const NavRailDrawerList = styled(List)(({ theme }) => ({
    display: "flex",
    flexDirection: "column",
    flex: 1,
    overflowY: "auto",
    overflowX: "hidden",
    gap: theme.spacing(1),
    "&::after": {
        content: '""',
        position: "absolute",
        right: theme.spacing(0.5),
        borderRadius: theme.spacing(0.75),
        width: theme.spacing(0.25),
        height: theme.spacing(2.75),
        background: theme.vars.palette.primary.main,
        opacity: 0,
        pointerEvents: "none",
        transform: `translateY(calc(var(--selected-item-top, 0) * 1px + ${theme.spacing(navigationRailListItemButtonHeight / 2)} - 50%))`,
        transition: "transform .2s ease .1s",
    },
    "&.animating-indicator::after": {
        opacity: 1,
    },
}));
/**
 * React component for a clickable navigation rail list item that can have a
 * selected state.
 * @param props Props.
 * @returns React node.
 */
function NavRailListItem({ className, item, onClick, open, selected, sx, ...props }) {
    const [expanded, setExpanded] = useState(false);
    const [subSelected, setSubSelected] = useState(item.items?.find((i) => i.selected)?.id);
    const [anchorEl, setPopoverAnchorEl] = useState(null);
    const containerElementRef = useRef(null);
    const popoverOpen = Boolean(anchorEl);
    useLayoutEffect(() => {
        setTimeout(() => {
            if (containerElementRef.current)
                updateIndicatorPosition(containerElementRef.current.closest("ul"), false);
        }, 300);
    }, [expanded]);
    const classes = useMemo(() => [
        className,
        expanded ? "Mui-NavRailItem-expanded" : null,
        popoverOpen ? "Mui-NavRailItem-popover-open" : null,
    ].filter(Boolean), [className, expanded, popoverOpen]);
    const selectedItemId = selected === item.id ? subSelected : undefined;
    const onClickListItem = useCallback((event) => {
        if (item.items?.length) {
            if (open)
                setExpanded(!expanded);
            else
                setPopoverAnchorEl(event.currentTarget);
        }
        else {
            onClick(item.id);
            item.onClick?.(item.id);
        }
    }, [expanded, item, onClick, open]);
    const onClickSetSubSelectedItem = useCallback((item, closePopover = false) => (id) => {
        if (closePopover)
            setPopoverAnchorEl(null);
        setSubSelected(id);
        onClick(item.id);
    }, [onClick]);
    const onClosePopover = useCallback(() => {
        setPopoverAnchorEl(null);
    }, []);
    return (_jsxs(Box, { ref: containerElementRef, role: "listitem", className: classes.join(" "), ...props, sx: { minWidth: 0, width: "100%", maxWidth: "100%" }, children: [_jsx(Tooltip, { title: !open ? (item.tooltipText ?? item.text) : "", placement: "right", arrow: true, children: _jsxs(NavRailListItemButton, { sx: sx, onClick: onClickListItem, disabled: item.disabled, selected: selected === item.id, ...(item.slots ? { component: item.slots.ListItemButton } : {}), ...(item.slotProps ? item.slotProps.ListItemButton : {}), ...item.listItemButtonProps, children: [_jsx(ListItemIcon, { children: item.icon }), _jsx(ListItemText, { sx: open ? {} : { opacity: 0 }, primary: item.text }), !!item.items?.length &&
                            (open ? (_jsx(IconMaterialSymbolsKeyboardArrowDown, {})) : (_jsx(IconMaterialSymbolsArrowDropDown, {})))] }) }), _jsx(Popover, { open: popoverOpen, anchorEl: anchorEl, onClose: onClosePopover, anchorOrigin: {
                    vertical: "top",
                    horizontal: "right",
                }, transformOrigin: {
                    horizontal: -8,
                    vertical: "top",
                }, elevation: 0, slotProps: {
                    paper: {
                        elevation: 0,
                        sx: {
                            boxShadow: "0px 4px 30px rgba(157, 167, 181, 0.2)",
                        },
                    },
                }, children: _jsx(List, { component: "div", children: item.items?.map((subItem) => (_jsx(NavRailListItem, { item: subItem, open: true, selected: selectedItemId, onClick: onClickSetSubSelectedItem(item, true), sx: { paddingInline: 2 }, className: "Mui-NavRailItem-secondLevel", ...(subItem.slots
                            ? { component: subItem.slots.ListItemButton }
                            : {}), ...(subItem.slotProps ? subItem.slotProps.ListItemButton : {}) }, `sub-menu-${subItem.id}`))) }) }), open && (_jsx(Collapse, { in: expanded, timeout: "auto", children: _jsx(List, { component: "div", disablePadding: true, children: item.items?.map((subItem) => (_jsx(NavRailListItem, { sx: { pl: 3 }, item: subItem, open: open, selected: selectedItemId, onClick: onClickSetSubSelectedItem(item), className: "Mui-NavRailItem-secondLevel" }, `popover-item-${subItem.id}`))) }) }))] }));
}
/**
 * Navigation rail list item button height, a number in
 * [Material UI theme spacing](https://mui.com/material-ui/customization/spacing)
 * units (not pixels).
 */
const navigationRailListItemButtonHeight = 6;
const NavRailListItemButton = styled(ListItemButton)(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    minWidth: 0,
    borderRadius: theme.spacing(0.75),
    height: theme.spacing(navigationRailListItemButtonHeight),
    padding: theme.spacing(0.5),
    "& .MuiListItemIcon-root": {
        minWidth: 0,
        padding: theme.spacing(1.5),
    },
    "&:hover": {
        color: theme.vars.palette.primary.main,
    },
    "&:hover .MuiSvgIcon-root": {
        color: theme.vars.palette.primary.main,
    },
    "&.Mui-focusVisible": {
        color: theme.vars.palette.primary.main,
    },
    "&.Mui-focusVisible .MuiSvgIcon-root": {
        color: theme.vars.palette.primary.main,
    },
    ".Mui-NavRailItem-popover-open &": {
        backgroundColor: theme.vars.palette.action.hover,
    },
    ".Mui-NavRailItem-popover-open & .MuiSvgIcon-root": {
        color: theme.vars.palette.primary.main,
    },
    "& > .MuiSvgIcon-root": {
        position: "absolute",
        right: theme.spacing(1.5),
        color: theme.vars.palette.action.active,
        opacity: 1,
        transform: "translateX(var(--navrail-chevron-translateX, 0%)) translateY(var(--navrail-chevron-translateY, 80%)) rotate(var(--navrail-chevron-rotate, -90deg))",
        transition: "opacity .2s linear, transform .1s linear",
    },
    ".MuiList-root:not(.Mui-NavRail-open) & > .MuiSvgIcon-root": {
        "--navrail-chevron-rotate": "0deg",
        "--navrail-chevron-translateY": "80%",
        "--navrail-chevron-translateX": "80%",
        filter: "grayscale(100%)",
    },
    ".MuiList-root.Mui-NavRail-open & > .MuiSvgIcon-root": {
        "--navrail-chevron-translateY": "0%",
    },
    ".MuiList-root:not(.Mui-NavRail-open) &.Mui-selected > .MuiSvgIcon-root": {
        opacity: 0,
    },
    ".Mui-NavRail-open & > .MuiSvgIcon-root": {
        "--navrail-chevron-rotate": "-90deg",
    },
    ".Mui-NavRailItem-expanded & > .MuiSvgIcon-root": {
        "--navrail-chevron-rotate": "0deg",
    },
    "& .MuiTypography-root": {
        ...theme.typography.subtitle2,
        textOverflow: "ellipsis",
        overflow: "hidden",
    },
    ".Mui-NavRailItem-firstLevel > &::after": {
        content: '""',
        position: "absolute",
        right: theme.spacing(0.5),
        borderRadius: theme.spacing(0.75),
        width: theme.spacing(0.25),
        height: theme.spacing(2.75),
        background: theme.vars.palette.primary.main,
        opacity: 0,
        pointerEvents: "none",
        transition: "opacity 0s linear 0s",
    },
    "&.Mui-selected": {
        color: theme.vars.palette.primary.main,
        backgroundColor: theme.vars.palette.action.selected,
        "&:hover": {
            backgroundColor: theme.vars.palette.aura.activeHover,
        },
        "& svg": {
            color: theme.vars.palette.primary.main,
        },
        "&::after": {
            opacity: 1,
            transition: "opacity .1s linear .2s",
        },
    },
    ".MuiPopover-root &": {
        borderRadius: 0,
        "& > div": {
            padding: theme.spacing(0.5),
        },
    },
    "& + .MuiCollapse-root": {
        "& .MuiList-root": {
            display: "flex",
            flexDirection: "column",
            gap: theme.spacing(1),
            paddingTop: theme.spacing(1),
        },
    },
}));
//# sourceMappingURL=NavRail.js.map