import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a Tosca Commander Checkbox control
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsCheckBox` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsCheckBox.mjs`.
 */
const IconCheckboxOutlined = createSvgIcon(_jsx("path", { d: "M11.1 15.8538L17.8231 9.13078L16.7692 8.07696L11.1 13.7462L8.25001 10.8962L7.19618 11.95L11.1 15.8538ZM5.80773 20.5C5.3026 20.5 4.87503 20.325 4.52503 19.975C4.17503 19.625 4.00003 19.1974 4.00003 18.6923V5.30773C4.00003 4.8026 4.17503 4.37503 4.52503 4.02503C4.87503 3.67503 5.3026 3.50003 5.80773 3.50003H19.1923C19.6974 3.50003 20.125 3.67503 20.475 4.02503C20.825 4.37503 21 4.8026 21 5.30773V18.6923C21 19.1974 20.825 19.625 20.475 19.975C20.125 20.325 19.6974 20.5 19.1923 20.5H5.80773ZM5.80773 19H19.1923C19.2692 19 19.3397 18.968 19.4039 18.9039C19.468 18.8397 19.5 18.7692 19.5 18.6923V5.30773C19.5 5.2308 19.468 5.16027 19.4039 5.09616C19.3397 5.03206 19.2692 5.00001 19.1923 5.00001H5.80773C5.7308 5.00001 5.66027 5.03206 5.59616 5.09616C5.53206 5.16027 5.50001 5.2308 5.50001 5.30773V18.6923C5.50001 18.7692 5.53206 18.8397 5.59616 18.9039C5.66027 18.968 5.7308 19 5.80773 19Z", fill: "currentColor" }), "IconCheckboxOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconCheckboxOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsCheckBox` instead.");
}
export default IconCheckboxOutlined;
//# sourceMappingURL=IconCheckboxOutlined.js.map