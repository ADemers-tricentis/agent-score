import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a chevron up down with outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsUnfoldMore` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsUnfoldMore.mjs`.
 */
const IconChevronUpDownOutlined = createSvgIcon(_jsx("path", { d: "M12 20.6038L7.82697 16.4307L8.91154 15.3461L12 18.4346L15.0885 15.3461L16.1731 16.4307L12 20.6038ZM8.91154 8.65377L7.82697 7.56917L12 3.39612L16.1731 7.56917L15.0885 8.65377L12 5.56529L8.91154 8.65377Z", fill: "currentColor" }), "IconChevronUpDownOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconChevronUpDownOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsUnfoldMore` instead.");
}
export default IconChevronUpDownOutlined;
//# sourceMappingURL=IconChevronUpDownOutlined.js.map