/**
 * React component for an SVG icon of a developer mode symbol with an outline
 * style.
 */
declare const IconDeveloperModeOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDeveloperModeOutlined;
