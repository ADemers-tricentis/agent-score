import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import Badge from "@mui/material/Badge";
import Box from "@mui/material/Box";
import Stack, {} from "@mui/material/Stack";
import { styled } from "@mui/material/styles";
import Typography from "@mui/material/Typography";
/**
 * React component for displaying a notification.
 * @param props Props.
 * @returns React node.
 */
export default function NotificationItem({ body, icon, isRead, onClick, subBody, centerComponent, title, }) {
    return (_jsxs(NotificationContainer, { spacing: centerComponent ? 0 : 3, tabIndex: onClick ? 0 : -1, direction: "row", isRead: isRead, ...(onClick && { onClick, onKeyPress: onClick }), role: "button", children: [_jsx(NotificationIconContainer, { children: _jsx(NotificationIconBadge, { variant: "dot", color: "info", showZero: false, invisible: isRead, anchorOrigin: {
                        horizontal: "right",
                        vertical: "bottom",
                    }, children: icon }) }), _jsx(CenterComponent, { children: centerComponent }), _jsxs(Stack, { spacing: 1, gap: 1, overflow: "hidden", children: [typeof title === "string" ? (_jsx(Typography, { variant: "subtitle2", children: title })) : (title), _jsxs(Box, { display: "contents", color: "text.secondary", children: [body, _jsx(Typography, { variant: "body2", children: subBody })] })] })] }));
}
const NotificationContainer = styled(Stack, {
    shouldForwardProp: (prop) => prop !== "isRead",
})(({ theme, isRead, onClick }) => ({
    alignItems: "start",
    maxHeight: "max-content",
    padding: theme.spacing(2),
    backgroundColor: isRead
        ? theme.vars.palette.background.paper
        : `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})`,
    cursor: onClick ? "pointer" : "auto",
    "&:hover": {
        background: isRead
            ? `rgba(${onClick
                ? theme.vars.palette.primary.mainChannel
                : theme.vars.palette.secondary.mainChannel} / 0.04)`
            : `rgba(${theme.vars.palette.primary.mainChannel} / 0.12)`,
    },
    "&:focus-visible": {
        outline: `2px solid ${theme.vars.palette.primary.main}`,
        outlineOffset: "-2px",
    },
}));
const NotificationIconContainer = styled(Box)({
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
    borderRadius: 40,
    width: 40,
    height: 40,
    backgroundColor: "rgba(0, 0, 0, 0.87)",
    textOverflow: "ellipsis",
    "& svg": {
        color: "white",
    },
});
const NotificationIconBadge = styled(Badge)(({ theme }) => ({
    "& .MuiBadge-badge": {
        right: -2,
        top: 14,
        border: `2px solid ${theme.vars.palette.background.paper}`,
        borderRadius: 12,
        width: 12,
        height: 12,
        paddingTop: 2,
        paddingBottom: 2,
    },
}));
const CenterComponent = styled(Box)({
    "&.MuiIconButton-root:hover": {
        backgroundColor: "transparent",
    },
});
//# sourceMappingURL=NotificationItem.js.map