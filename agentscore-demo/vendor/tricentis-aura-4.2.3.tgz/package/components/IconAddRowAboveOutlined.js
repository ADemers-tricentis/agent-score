import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of adding a row above.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsAddRowAbove` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsAddRowAbove.mjs`.
 */
const IconAddRowAboveOutlined = createSvgIcon(_jsxs(_Fragment, { children: [_jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M3.78011 12C2.79704 12 2.00011 12.7969 2.00011 13.78L2 21L3.5 21L3.50011 19L8.16168 19L8.16168 21L9.66163 21L9.66163 19L14.3136 19L14.3136 21L15.8385 21L15.8385 19L20.5001 19L20.5001 21L22.0001 21L22.0001 13.78C22.0001 12.7969 21.2031 12 20.2201 12L3.78011 12ZM8.16168 13.5L3.82011 13.5C3.64338 13.5 3.50011 13.6432 3.50011 13.82L3.50011 17.5L8.16168 17.5L8.16168 13.5ZM14.3136 13.5L9.66163 13.5L9.66163 17.5L14.3136 17.5L14.3136 13.5ZM15.8385 13.5L20.1801 13.5C20.3568 13.5 20.5001 13.6432 20.5001 13.82L20.5001 17.5L15.8385 17.5L15.8385 13.5Z", fill: "currentColor" }), _jsx("path", { d: "M12.7489 2.25085L12.7598 5.24518L15.7541 5.25606L15.7541 6.74639L12.7598 6.75726L12.7489 9.75159L11.2586 9.75159L11.2477 6.75726L8.25335 6.74639L8.25335 5.25606L11.2477 5.24518L11.2586 2.25085L12.7489 2.25085Z", fill: "currentColor" })] }), "IconAddRowAboveOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconAddRowAboveOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsAddRowAbove` instead.");
}
export default IconAddRowAboveOutlined;
//# sourceMappingURL=IconAddRowAboveOutlined.js.map