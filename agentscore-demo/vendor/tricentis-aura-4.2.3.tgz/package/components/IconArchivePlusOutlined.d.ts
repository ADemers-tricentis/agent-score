/**
 * React component for an SVG icon of archive, box, bin symbol
 * that has a (+) plus with outline style.
 */
declare const IconArchivePlusOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconArchivePlusOutlined;
