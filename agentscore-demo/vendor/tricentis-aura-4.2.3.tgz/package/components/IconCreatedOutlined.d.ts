/**
 * React component for an SVG icon of a create file symbol with outline style.
 */
declare const IconCreatedOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconCreatedOutlined;
