import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a triangle with an exclamation mark at
 * the center with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsWarning` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsWarning.mjs`.
 */
const IconWarningOutlined = createSvgIcon(_jsx("path", { d: "M1.86548 20.7499L12 3.25L22.1346 20.7499H1.86548ZM4.45003 19.2499H19.55L12 6.24993L4.45003 19.2499ZM12 18.0576C12.2289 18.0576 12.4207 17.9802 12.5755 17.8254C12.7303 17.6706 12.8077 17.4788 12.8077 17.2499C12.8077 17.0211 12.7303 16.8293 12.5755 16.6745C12.4207 16.5197 12.2289 16.4423 12 16.4423C11.7712 16.4423 11.5794 16.5197 11.4246 16.6745C11.2698 16.8293 11.1924 17.0211 11.1924 17.2499C11.1924 17.4788 11.2698 17.6706 11.4246 17.8254C11.5794 17.9802 11.7712 18.0576 12 18.0576ZM11.2501 15.4423H12.75V10.4423H11.2501V15.4423Z", fill: "currentColor" }), "IconWarningOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconWarningOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsWarning` instead.");
}
export default IconWarningOutlined;
//# sourceMappingURL=IconWarningOutlined.js.map