import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a wedge pointing down.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsArrowDownward` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsArrowDownward.mjs`.
 */
const IconArrowDownwardsOutlined = createSvgIcon(_jsx("path", { d: "M11.25 4.5V16.6269L5.55383 10.9308L4.5 12L12 19.5L19.5 12L18.4461 10.9308L12.7499 16.6269V4.5H11.25Z", fill: "currentColor" }), "IconArrowDownwardsOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconArrowDownwardsOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsArrowDownward` instead.");
}
export default IconArrowDownwardsOutlined;
//# sourceMappingURL=IconArrowDownwardsOutlined.js.map