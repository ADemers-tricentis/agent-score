import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { styled } from "@mui/material/styles";
/**
 * React component for the Tricentis SeaLights product mark.
 * @param props Props.
 * @returns React node.
 */
export default function ProductMarkSeaLights({ sx, }) {
    return (_jsxs(Svg, { viewBox: "0 0 24 24", className: "ProductMarkSeaLights", "data-testid": "ProductMarkSeaLights", sx: sx, children: [_jsx("path", { className: "ProductMarkSeaLights-background", d: "M0 4a4 4 0 0 1 4-4h16a4 4 0 0 1 4 4v16a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4Z" }), _jsx("path", { className: "ProductMarkSeaLights-text", d: "M13.325 16.125V7.148h2.01v7.055h3.718v1.922h-5.728Zm-4.609.152c-1.045 0-1.888-.304-2.529-.91-.64-.607-.978-1.316-1.011-2.125h2.01c.067.371.236.662.506.873.278.202.62.303 1.024.303.345 0 .624-.071.834-.215.22-.143.329-.337.329-.581 0-.43-.392-.755-1.176-.974l-.872-.227c-.75-.203-1.34-.531-1.77-.987-.43-.455-.65-1.024-.658-1.707 0-.834.278-1.496.835-1.985.564-.497 1.315-.746 2.25-.746.944 0 1.711.287 2.301.86.59.565.902 1.214.936 1.947H9.727c-.092-.328-.253-.569-.48-.72a1.338 1.338 0 0 0-.759-.228c-.312 0-.565.063-.758.19a.64.64 0 0 0-.304.543.696.696 0 0 0 .253.582c.185.152.464.278.834.38l1.025.265c.75.202 1.331.535 1.745.999.42.463.632 1.045.632 1.744 0 .776-.295 1.425-.885 1.948-.59.514-1.362.77-2.314.77Z" })] }));
}
const Svg = styled("svg")(({ theme }) => ({
    "&.ProductMarkSeaLights": {
        "& .ProductMarkSeaLights-background": {
            fill: theme.vars.palette.aura.brand,
        },
        "& .ProductMarkSeaLights-text": {
            fill: theme.vars.palette.aura.brandInverted,
        },
    },
}));
//# sourceMappingURL=ProductMarkSeaLights.js.map