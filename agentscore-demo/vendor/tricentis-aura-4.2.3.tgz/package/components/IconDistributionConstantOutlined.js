import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon used in Neoload that represents a
 * distribution constant with an outlined style.
 */
const IconDistributionConstantOutlined = createSvgIcon(_jsxs(_Fragment, { children: [_jsx("path", { d: "M4 20H20", stroke: "currentColor", strokeWidth: "1.4", strokeLinecap: "round" }), _jsx("path", { d: "M19 11.5L16 8.5M19 11.5L16 14.5M19 11.5H5", stroke: "currentColor", strokeWidth: "1.4", strokeLinecap: "round", strokeLinejoin: "round" })] }), "IconDistributionConstantOutlined");
export default IconDistributionConstantOutlined;
//# sourceMappingURL=IconDistributionConstantOutlined.js.map