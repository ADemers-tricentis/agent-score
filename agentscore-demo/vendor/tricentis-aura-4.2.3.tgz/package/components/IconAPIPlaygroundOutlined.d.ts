/**
 * React component for an SVG icon of a cloud with code
 * symbol, using an outline style.
 */
declare const IconAPIPlaygroundOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconAPIPlaygroundOutlined;
