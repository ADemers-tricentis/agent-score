/**
 * React component for an SVG icon of block, obstruct, restrict with an outlined
 * style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsBlock` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsBlock.mjs`.
 */
declare const IconBlockOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconBlockOutlined;
