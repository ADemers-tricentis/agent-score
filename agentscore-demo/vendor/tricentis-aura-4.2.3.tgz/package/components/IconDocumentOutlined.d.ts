/**
 * React component for an SVG icon of a document with an outlined style.  *
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsDraft` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDraft.mjs`.
 */
declare const IconDocumentOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconDocumentOutlined;
