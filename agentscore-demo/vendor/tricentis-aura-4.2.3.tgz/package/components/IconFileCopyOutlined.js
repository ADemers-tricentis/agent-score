import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of a L-shaped corner ruler next to a file
 * with an outlined style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFileCopy` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFileCopy.mjs`.
 */
const IconFileCopyOutlined = createSvgIcon(_jsx("path", { d: "M19.1923 18.5H8.8077C8.30257 18.5 7.875 18.325 7.525 17.975C7.175 17.625 7 17.1974 7 16.6923V3.3077C7 2.80257 7.175 2.375 7.525 2.025C7.875 1.675 8.30257 1.5 8.8077 1.5H15.75L21 6.74995V16.6923C21 17.1974 20.825 17.625 20.475 17.975C20.125 18.325 19.6974 18.5 19.1923 18.5ZM15 7.49995V2.99998H8.8077C8.73077 2.99998 8.66024 3.03203 8.59613 3.09613C8.53203 3.16024 8.49998 3.23077 8.49998 3.3077V16.6923C8.49998 16.7692 8.53203 16.8397 8.59613 16.9038C8.66024 16.9679 8.73077 17 8.8077 17H19.1923C19.2692 17 19.3397 16.9679 19.4038 16.9038C19.4679 16.8397 19.5 16.7692 19.5 16.6923V7.49995H15ZM4.8077 22.5C4.30257 22.5 3.875 22.325 3.525 21.975C3.175 21.625 3 21.1974 3 20.6923V7.5H4.49998V20.6923C4.49998 20.7692 4.53202 20.8397 4.59613 20.9038C4.66024 20.9679 4.73077 21 4.8077 21H15V22.4999H4.8077V22.5Z", fill: "currentColor" }), "IconFileCopyOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconFileCopyOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFileCopy` instead.");
}
export default IconFileCopyOutlined;
//# sourceMappingURL=IconFileCopyOutlined.js.map