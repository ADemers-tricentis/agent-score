import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
import checkIsInternalImport from "../utils/private/isInternalImport.js";
// ignore unused exports default
/**
 * React component for an SVG icon of a circle with an
 * attached line in an outlined style
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsSearch` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsSearch.mjs`.
 */
const IconSearchOutlined = createSvgIcon(_jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M15.4075 9.97776C15.4075 12.9765 12.9765 15.4075 9.97775 15.4075C6.97897 15.4075 4.54798 12.9765 4.54798 9.97776C4.54798 6.97899 6.97897 4.548 9.97775 4.548C12.9765 4.548 15.4075 6.97899 15.4075 9.97776ZM14.3508 15.4821C13.1504 16.437 11.6307 17.0075 9.97775 17.0075C6.09531 17.0075 2.94798 13.8602 2.94798 9.97776C2.94798 6.09533 6.09531 2.948 9.97775 2.948C13.8602 2.948 17.0075 6.09533 17.0075 9.97776C17.0075 11.6307 16.437 13.1505 15.4821 14.3508L20.8177 19.6863C21.1301 19.9988 21.1301 20.5053 20.8177 20.8177C20.5053 21.1301 19.9987 21.1301 19.6863 20.8177L14.3508 15.4821Z", fill: "currentColor" }), "IconSearchOutlined");
if (process.env.NODE_ENV === "development" && !checkIsInternalImport()) {
    console.warn("`IconSearchOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsSearch` instead.");
}
export default IconSearchOutlined;
//# sourceMappingURL=IconSearchOutlined.js.map