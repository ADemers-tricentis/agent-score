/**
 * React component for an SVG icon of a paper showing left and right
 * chevrons.
 */
declare const IconFileCodeOutlined: import("@mui/material/OverridableComponent").OverridableComponent<import("@mui/material/SvgIcon").SvgIconTypeMap<{}, "svg">> & {
    muiName: string;
};
export default IconFileCodeOutlined;
