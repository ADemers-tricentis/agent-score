import { jsx as _jsx } from "react/jsx-runtime";
import { createSvgIcon } from "@mui/material/utils";
/**
 * React component for an SVG icon of an arrow pointing down and turning to
 * the right.
 */
const IconBranchRightFilled = createSvgIcon(_jsx("path", { d: "M10.8 3V7.25C11.1167 8.3 11.6708 9.10833 12.4625 9.675C13.2542 10.2417 14.125 10.525 15.075 10.525C15.4583 10.525 15.8333 10.5 16.2 10.45C16.5667 10.4 16.8833 10.3333 17.15 10.25L14.9 8L15.95 6.95L20 11L15.95 15.05L14.9 14L17.15 11.75C16.8333 11.8333 16.4917 11.9 16.125 11.95C15.7583 12 15.4417 12.025 15.175 12.025C14.1417 12.025 13.2792 11.85 12.5875 11.5C11.8958 11.15 11.3 10.7 10.8 10.15V18.15L13.05 15.9L14.1 16.95L10.05 21L6 16.95L7.05 15.9L9.3 18.15V3H10.8Z", fill: "currentColor" }), "IconBranchRightFilled");
export default IconBranchRightFilled;
//# sourceMappingURL=IconBranchRightFilled.js.map