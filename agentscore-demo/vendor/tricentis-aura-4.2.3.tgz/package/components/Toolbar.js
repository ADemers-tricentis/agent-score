import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import Badge from "@mui/material/Badge";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import Divider from "@mui/material/Divider";
import IconButton, {} from "@mui/material/IconButton";
import Popover from "@mui/material/Popover";
import { styled } from "@mui/material/styles";
import Switch from "@mui/material/Switch";
import Tooltip, {} from "@mui/material/Tooltip";
import Typography from "@mui/material/Typography";
import { capitalize } from "@mui/material/utils";
import { gridColumnLookupSelector, gridDensitySelector, GridLogicOperator, useGridApiContext, useGridEvent, useGridSelector, } from "@mui/x-data-grid-pro";
import IconMaterialSymbolsDensityLarge from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDensityLarge.mjs";
import IconMaterialSymbolsDensitySmall from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsDensitySmall.mjs";
import IconMaterialSymbolsFilterAlt from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFilterAlt.mjs";
import IconMaterialSymbolsSearch from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsSearch.mjs";
import IconMaterialSymbolsTableRows from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsTableRows.mjs";
import IconMaterialSymbolsViewColumn from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsViewColumn.mjs";
import { useCallback, useEffect, useRef, useState, } from "react";
import withTooltip from "../utils/withTooltip.js";
import ChipGroup from "./ChipGroup.js";
import FilterRemoveOutlinedIcon from "./IconFilterRemoveOutlined.js";
import TextFieldCollapsible from "./TextFieldCollapsible.js";
const gridDensityOptions = {
    compact: "compact",
    standard: "standard",
    comfortable: "comfortable",
};
/**
 * React component for rendering a Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) toolbar that
 * may contain:
 *
 * - Secondary action button groups.
 * - Collapsible search field.
 * - Filter options.
 * - Column options.
 * - Density options.
 *
 * For use with the Material UI component
 * [`DataGridPro`](https://mui.com/x/api/data-grid/data-grid-pro) props
 * `slots.toolbar` and `slotProps.toolbar`.
 * @param props Props.
 * @returns React node.
 */
export default function Toolbar({ defaultFilters = DATA_GRID_TOOLBAR_FILTERS_DEFAULT, defaultFiltersOperator, displayColumnOptions = true, displayDensityOptions = false, displaySearchBox = true, hideColumnsFromColumnOptions = [], hideFiltersIcon = false, initialFilterItems = DATA_GRID_TOOLBAR_FILTERS_DEFAULT, labels, onFiltersChange, secondaryActions = [[]], syncLocalStorage = {
    isSyncEnabled: false,
    datagridId: "",
}, testIdAttribute = "data-testid", testIds = {
    clearFilters: "dgtb-button-clear-filters",
    manageColumns: "dgtb-button-manage-columns",
    searchIconButton: "dgtb-iconbutton-search",
    searchInput: "dgtb-search-input",
    showFiltersPanel: "dgtb-button-show-filters",
}, removeFilterChipOnDelete = false, }) {
    const mergedLabels = { ...DEFAULT_TOOLBAR_LABELS, ...labels };
    return (_jsxs(_Fragment, { children: [_jsx(DataGridToolbarContainer, { children: _jsxs(DataGridToolbarRow, { children: [_jsx(DataGridToolbarCellGrow, { children: _jsx(DataGridToolbarFiltersOptions, { defaultFilters: defaultFilters, displaySearchBox: displaySearchBox, hideFiltersIcon: hideFiltersIcon, initialFilterItems: initialFilterItems, labels: mergedLabels, onFiltersChange: onFiltersChange, operator: defaultFiltersOperator, syncLocalStorage: syncLocalStorage, testIdAttribute: testIdAttribute, testIds: testIds, removeFilterChipOnDelete: removeFilterChipOnDelete }) }), _jsxs(DataGridToolbarCell, { children: [_jsx(_Fragment, { children: (Array.isArray(secondaryActions[0])
                                        ? secondaryActions
                                        : [secondaryActions]).map((secondaryActionGroup, groupIndex, secondaryActionGroups) => {
                                        if (secondaryActionGroup.length === 0)
                                            return null;
                                        const buttonsGroup = secondaryActionGroup.map(({ dataTestId, ...buttonProps }, index) => (_jsx(DataGridToolbarSecondaryButtonWithTooltip, { size: "small", "data-testid": dataTestId, ...buttonProps }, `${groupIndex}-${index}`)));
                                        return !displayColumnOptions &&
                                            groupIndex + 1 === secondaryActionGroups.length
                                            ? buttonsGroup
                                            : [
                                                ...buttonsGroup,
                                                _jsx(Divider, { orientation: "vertical" }, `divider-${groupIndex}`),
                                            ];
                                    }) }), displayDensityOptions && _jsx(DataGridToolbarDensityOptions, {}), displayColumnOptions && (_jsx(DataGridToolbarColumnOptions, { hideColumnsFromColumnOptions: hideColumnsFromColumnOptions, testIdAttribute: testIdAttribute, testIds: testIds }))] })] }) }), _jsx(Divider, {})] }));
}
/**
 * React component for the data grid toolbar column options.
 * @param props Props.
 * @returns React node.
 */
function DataGridToolbarColumnOptions({ hideColumnsFromColumnOptions, testIdAttribute, testIds, }) {
    const gridApiRef = useGridApiContext();
    const columnsLabel = gridApiRef.current.getLocaleText("toolbarColumnsLabel");
    const columnsDefinitions = gridApiRef.current.getAllColumns();
    const [visibleColumnFields, setVisibleColumnFields] = useState(() => new Set(gridApiRef.current.getVisibleColumns().map((c) => c.field)));
    const [isPopoverOpen, setIsPopoverOpen] = useState(false);
    const manageColumnsIconButtonRef = useRef(null);
    const openPopover = useCallback(() => {
        setIsPopoverOpen(true);
    }, []);
    const closePopover = useCallback(() => {
        setIsPopoverOpen(false);
    }, []);
    useGridEvent(gridApiRef, "columnVisibilityModelChange", useCallback(() => {
        setVisibleColumnFields(new Set(gridApiRef.current.getVisibleColumns().map((c) => c.field)));
    }, [gridApiRef]));
    return (_jsxs(_Fragment, { children: [_jsx(Tooltip, { arrow: true, title: columnsLabel, children: _jsx(IconButton, { ref: manageColumnsIconButtonRef, [testIdAttribute]: testIds.manageColumns, onClick: openPopover, "aria-label": columnsLabel, children: _jsx(IconMaterialSymbolsViewColumn, {}) }) }), _jsx(Popover, { id: "column-options-visibility-selector", open: isPopoverOpen, anchorEl: manageColumnsIconButtonRef.current, anchorOrigin: {
                    horizontal: "left",
                    vertical: "bottom",
                }, onClose: closePopover, children: _jsx(Card, { sx: {
                        px: 2,
                        py: 3,
                    }, children: columnsDefinitions.reduce((accumulator, column) => {
                        if (!column.hideColumnFromColumnOptions &&
                            !hideColumnsFromColumnOptions?.includes(column.field) &&
                            column.headerName) {
                            const checked = visibleColumnFields.has(column.field);
                            accumulator.push(_jsxs(Box, { display: "flex", alignItems: "center", children: [_jsx(Switch, { checked: checked, onChange: () => {
                                            gridApiRef.current.setColumnVisibility(column.field, !checked);
                                        } }), _jsx(Typography, { marginLeft: 5, children: column.headerName })] }, column.field));
                        }
                        return accumulator;
                    }, []) }) })] }));
}
/**
 * React component for the data grid toolbar density options button.
 * @returns React node.
 */
function DataGridToolbarDensityOptions() {
    const gridApiRef = useGridApiContext();
    const densityValue = useGridSelector(gridApiRef, gridDensitySelector);
    const handleDensityUpdate = () => {
        let newDensity;
        switch (densityValue) {
            case gridDensityOptions.compact:
                newDensity = "standard";
                break;
            case gridDensityOptions.standard:
                newDensity = "comfortable";
                break;
            case gridDensityOptions.comfortable:
                newDensity = "compact";
                break;
            default:
                newDensity = "standard";
        }
        gridApiRef.current.setDensity(newDensity);
    };
    return (_jsx(IconButton, { onClick: handleDensityUpdate, children: densityValue === gridDensityOptions.compact ? (_jsx(IconMaterialSymbolsDensitySmall, {})) : densityValue === gridDensityOptions.comfortable ? (_jsx(IconMaterialSymbolsDensityLarge, {})) : (_jsx(IconMaterialSymbolsTableRows, {})) }));
}
/**
 * React component for the data grid toolbar filters options.
 * @param props Props.
 * @returns React node.
 */
function DataGridToolbarFiltersOptions({ defaultFilters, displaySearchBox, hideFiltersIcon, initialFilterItems, labels, onFiltersChange, operator, syncLocalStorage, testIdAttribute, testIds, removeFilterChipOnDelete, }) {
    const [currentFilters, setCurrentFilters] = useState([]);
    const gridApiRef = useGridApiContext();
    const handleFiltersChange = (filters, evt) => {
        const newCurrentFilters = [...currentFilters];
        filters.items.forEach((f) => {
            if (!f.id)
                return;
            const filter = f;
            const existingFilter = newCurrentFilters.find(({ filter: item }) => item.id === filter.id);
            if (!existingFilter) {
                // Adding a new created filter.
                newCurrentFilters.push({
                    filter,
                    active: true,
                    default: false,
                    deleted: false,
                });
            }
            else {
                // Updating a filter.
                existingFilter.filter = filter;
            }
        });
        let newCurrentFilterList = newCurrentFilters;
        if (removeFilterChipOnDelete) {
            // removing deleted filters
            newCurrentFilterList = newCurrentFilters.filter((currentFilter) => filters.items.findIndex((item) => item.id === currentFilter.filter.id) >= 0);
        }
        else {
            newCurrentFilterList.forEach((currentFilter) => {
                const isDeleted = filters.items.findIndex((item) => item.id === currentFilter.filter.id) === -1;
                // deactivating deleted filters
                currentFilter.active = !isDeleted;
                currentFilter.deleted = isDeleted;
            });
        }
        setCurrentFilters(newCurrentFilterList);
        if (evt.reason !== "restoreState") {
            onFiltersChange?.({
                filters: newCurrentFilters,
                reason: "filterModelChange",
            });
            if (syncLocalStorage?.isSyncEnabled && syncLocalStorage.datagridId) {
                localStorageFiltersSave(syncLocalStorage.datagridId, {
                    items: newCurrentFilters,
                    logicOperator: filters.logicOperator,
                });
            }
        }
    };
    useGridEvent(gridApiRef, "filterModelChange", handleFiltersChange);
    useEffect(() => {
        let localFilters = null;
        if (syncLocalStorage?.isSyncEnabled && syncLocalStorage.datagridId)
            localFilters = localStorageFiltersLoad(syncLocalStorage.datagridId, defaultFilters, initialFilterItems);
        // set the initial active and default filters filters in DataGrid
        const initialFilterModel = {
            items: (localFilters
                ? localFilters.items
                : defaultFilters.concat(initialFilterItems))
                .filter((f) => f.active)
                .map((f) => f.filter),
            logicOperator: localFilters?.logicOperator || operator,
        };
        gridApiRef.current.setFilterModel(initialFilterModel, "restoreState");
        // save the default and initial filters
        const newCurrentFilters = localFilters
            ? localFilters.items
            : [
                ...defaultFilters.map((filter) => ({
                    ...filter,
                    default: true,
                })),
                ...initialFilterItems.map((filter) => ({
                    ...filter,
                    default: false,
                })),
            ];
        setCurrentFilters(newCurrentFilters);
        onFiltersChange?.({
            filters: newCurrentFilters,
            reason: "setInitialFilterModel",
        });
    }, [
        gridApiRef,
        defaultFilters,
        operator,
        initialFilterItems,
        onFiltersChange,
        syncLocalStorage?.isSyncEnabled,
        syncLocalStorage?.datagridId,
    ]);
    const showFilterPanel = useCallback(() => {
        gridApiRef.current.showFilterPanel();
    }, [gridApiRef]);
    const clearFilters = useCallback(() => {
        gridApiRef.current.setFilterModel({
            items: [],
        });
    }, [gridApiRef]);
    const setQuickFilter = useCallback((value = "") => {
        gridApiRef.current.setQuickFilterValues(value.trim().split(" "));
    }, [gridApiRef]);
    const onDeleteFilter = useCallback((filter) => {
        gridApiRef.current.deleteFilterItem(filter);
        const remainingFilters = currentFilters.filter((item) => item.filter.id !== filter.id);
        setCurrentFilters(remainingFilters);
        onFiltersChange?.({ filters: remainingFilters, reason: "onDelete" });
        if (syncLocalStorage?.isSyncEnabled && syncLocalStorage.datagridId)
            localStorageFiltersSave(syncLocalStorage.datagridId, {
                items: remainingFilters,
            });
    }, [gridApiRef, currentFilters, onFiltersChange, syncLocalStorage]);
    const onClickFilter = useCallback((filter, isActiveFilter) => {
        gridApiRef.current[isActiveFilter ? "deleteFilterItem" : "upsertFilterItem"](filter);
        if (removeFilterChipOnDelete) {
            const filterChanged = currentFilters.find((item) => item.filter.id === filter.id);
            if (filterChanged) {
                filterChanged.active = !isActiveFilter;
            }
        }
        onFiltersChange?.({
            filters: currentFilters,
            reason: "filterModelChange",
        });
    }, [gridApiRef, currentFilters, onFiltersChange, removeFilterChipOnDelete]);
    const columns = gridApiRef.current.getAllColumns();
    const filtersList = currentFilters.map((item) => ({
        ...item,
        column: columns.find((col) => col.field === item.filter.field),
        onDeleteFilter,
        onClickFilter,
    }));
    const activeFiltersNumber = filtersList.filter((filter) => filter.active).length;
    const onQuickFilterChange = useCallback((event) => {
        setQuickFilter(event.target.value || "");
    }, [setQuickFilter]);
    const apiRef = useGridApiContext();
    const lookup = useGridSelector(apiRef, gridColumnLookupSelector);
    const getOperatorLabel = (item) => {
        const operator = lookup[item.field].filterOperators?.find((operator) => operator.value === item.operator);
        // Return operator label if found
        if (operator?.label) {
            return operator.label;
        }
        // Fallback to localized text
        try {
            const translationKey = `filterOperator${capitalize(item.operator)}`;
            const localeText = apiRef.current.getLocaleText(translationKey);
            return typeof localeText === "string" ? localeText : "";
        }
        catch {
            // Return empty string if translation fails
            return "";
        }
    };
    const getFilterItemValue = (item) => {
        const operator = lookup[item.field].filterOperators?.find((operator) => operator.value === item.operator);
        if (operator?.getValueAsString) {
            return operator.getValueAsString(item.value);
        }
        return item.value != null ? String(item.value) : "";
    };
    return (_jsxs(_Fragment, { children: [displaySearchBox && (_jsxs(_Fragment, { children: [_jsx(TextFieldCollapsible, { icon: _jsx(IconMaterialSymbolsSearch, {}), IconButtonProps: testIdAttribute && testIds.searchIconButton
                            ? { [testIdAttribute]: testIds.searchIconButton }
                            : {}, size: "small", tooltipTitle: gridApiRef.current.getLocaleText("toolbarQuickFilterLabel"), inputFocusDelay: 150, onChange: onQuickFilterChange, slotProps: {
                            htmlInput: {
                                "data-testid": testIds.searchInput,
                            },
                        } }), !hideFiltersIcon && _jsx(Divider, { orientation: "vertical" })] })), !hideFiltersIcon ? (_jsx(DataGridToolbarFiltersBadge, { badgeContent: activeFiltersNumber, color: "primary", children: _jsx(Tooltip, { title: gridApiRef.current.getLocaleText("toolbarFilters"), arrow: true, placement: "bottom", children: _jsx(IconButton, { [testIdAttribute]: testIds.showFiltersPanel, size: "small", "aria-label": gridApiRef.current.getLocaleText("toolbarFiltersLabel"), color: activeFiltersNumber > 0 ? "primary" : undefined, onClick: showFilterPanel, children: _jsx(IconMaterialSymbolsFilterAlt, {}) }) }) })) : null, _jsx(DataGridToolbarFilters, { children: _jsx(ChipGroup, { chips: filtersList.map(({ filter, column, active, onClickFilter, onDeleteFilter, default: isDefault, }) => {
                        const labelParts = [
                            column?.headerName || filter.field,
                            getOperatorLabel(filter),
                            getFilterItemValue(filter),
                        ];
                        return {
                            label: labelParts.join(" "),
                            color: active ? "primary" : undefined,
                            onClick: () => {
                                onClickFilter(filter, active);
                            },
                            onDelete: !isDefault
                                ? () => {
                                    onDeleteFilter(filter);
                                }
                                : undefined,
                        };
                    }), children: activeFiltersNumber !== 0 && (_jsxs(_Fragment, { children: [_jsx(Divider, { orientation: "vertical" }), _jsx(Tooltip, { title: labels.clearFiltersTooltip, arrow: true, children: _jsx(IconButton, { [testIdAttribute]: testIds.clearFilters, onClick: clearFilters, "aria-label": labels.clearFilters, size: "small", children: _jsx(FilterRemoveOutlinedIcon, {}) }) })] })) }) })] }));
}
const DataGridToolbarContainer = styled("div")(({ theme }) => ({
    margin: theme.spacing(2),
    display: "flex",
    alignItems: "center",
    flexDirection: "column",
    gap: theme.spacing(2),
}));
const DataGridToolbarRow = styled("div")(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
    height: theme.spacing(4),
    gap: theme.spacing(1),
    maxWidth: "100%",
}));
const DataGridToolbarCell = styled("div")(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    height: "100%",
    gap: theme.spacing(1),
}));
const DataGridToolbarCellGrow = styled("div")(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    height: "100%",
    gap: theme.spacing(1),
    flex: 1,
    maxWidth: "100%",
    minWidth: 0,
}));
const DataGridToolbarFiltersBadge = styled(Badge)({
    ".MuiBadge-badge": {
        top: 4,
        right: 8,
    },
});
const DataGridToolbarFilters = styled("div")(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    height: "100%",
    gap: theme.spacing(1),
    flex: 1,
    minWidth: 0,
}));
const DataGridToolbarSecondaryButtonWithTooltip = withTooltip(IconButton);
/**
 * Saves data grid filters in local storage.
 * @param dataGridId Data grid ID.
 * @param filters Data grid filters to save.
 */
function localStorageFiltersSave(dataGridId, filters) {
    // Save the filters directly to local storage
    localStorage.setItem(dataGridId, JSON.stringify(filters));
}
/**
 * Type guard to check if the filters are in the old format.
 * @param filters Filters to check.
 * @returns True if the filters are in the old format, false otherwise.
 */
function isOldFormat(filters) {
    return (filters.items.length > 0 &&
        ("columnField" in filters.items[0].filter ||
            "operatorValue" in filters.items[0].filter));
}
/**
 * Converts old filter format to the new format.
 * @param filters Old filters in the old format.
 * @returns Filters in the new format.
 */
function convertOldFormatToNew(filters) {
    if (isOldFormat(filters)) {
        return {
            items: filters.items.map((item) => ({
                filter: {
                    field: item.filter.columnField,
                    operator: item.filter.operatorValue,
                    id: item.filter.id,
                    value: Array.isArray(item.filter.value)
                        ? item.filter.value
                        : [item.filter.value],
                },
                active: item.active,
                default: item.default,
                deleted: !item.active,
            })),
            logicOperator: filters.linkOperator,
        };
    }
    return filters;
}
/**
 * Loads data grid filters from local storage.
 * @param dataGridId Data grid ID.
 * @param defaultFilters Default data grid filters.
 * @param initialFilters Initial data grid filters.
 * @returns Loaded data grid filters.
 */
function localStorageFiltersLoad(dataGridId, defaultFilters, initialFilters) {
    const data = localStorage.getItem(dataGridId);
    if (data) {
        let filters = JSON.parse(data);
        filters = convertOldFormatToNew(filters);
        defaultFilters
            .map((filter) => ({ ...filter, default: true }))
            .concat(initialFilters.map((filter) => ({ ...filter, default: false })))
            .forEach((f) => {
            const saved = filters.items.find((item) => item.filter.id === f.filter.id);
            if (saved) {
                // Already exists, so update values.
                saved.filter.field = f.filter.field;
                saved.filter.operator = f.filter.operator;
                saved.filter.value = f.filter.value;
            }
            else {
                // Is new, so add.
                filters.items.push(f);
            }
        });
        return filters;
    }
    return null;
}
/** Default data grid toolbar filters. */
const DATA_GRID_TOOLBAR_FILTERS_DEFAULT = [];
const DEFAULT_TOOLBAR_LABELS = {
    clearFilters: "Clear filters",
    clearFiltersTooltip: "Turn off all active filters",
};
//# sourceMappingURL=Toolbar.js.map