import { jsx as _jsx } from "react/jsx-runtime";
// ignore unused exports default
import { createSvgIcon } from "@mui/material/utils";
// ignore unused exports default
/**
 * React component for an SVG icon of edit with
 * outline style.
 * @deprecated  This component is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025).
 *
 * Instead use `IconMaterialSymbolsFontDownload` from
 * `@tricentis/mui-icons/material-symbols/IconMaterialSymbolsFontDownload.mjs`.
 */
const IconEditBoxOutlined = createSvgIcon(_jsx("path", { d: "M7.45408 17.1792H8.86841L9.83542 14.4674H14.1646L15.1316 17.1792H16.5459L12.6641 6.71759H11.3359L7.45408 17.1792ZM10.2518 13.263L11.9553 8.45545H12.0447L13.7482 13.263H10.2518ZM5.11742 20.5C4.66546 20.5 4.2829 20.3434 3.96974 20.0303C3.65658 19.7171 3.5 19.3345 3.5 18.8826V5.11742C3.5 4.66546 3.65658 4.2829 3.96974 3.96974C4.2829 3.65658 4.66546 3.5 5.11742 3.5H18.8826C19.3345 3.5 19.7171 3.65658 20.0303 3.96974C20.3434 4.2829 20.5 4.66546 20.5 5.11742V18.8826C20.5 19.3345 20.3434 19.7171 20.0303 20.0303C19.7171 20.3434 19.3345 20.5 18.8826 20.5H5.11742ZM5.11742 19.1579H18.8826C18.9514 19.1579 19.0145 19.1292 19.0719 19.0719C19.1292 19.0145 19.1579 18.9514 19.1579 18.8826V5.11742C19.1579 5.04859 19.1292 4.98548 19.0719 4.92812C19.0145 4.87076 18.9514 4.84209 18.8826 4.84209H5.11742C5.04858 4.84209 4.98548 4.87076 4.92812 4.92812C4.87076 4.98548 4.84209 5.04859 4.84209 5.11742V18.8826C4.84209 18.9514 4.87076 19.0145 4.92812 19.0719C4.98548 19.1292 5.04858 19.1579 5.11742 19.1579Z", fill: "currentColor" }), "IconEditBoxOutlined");
if (process.env.NODE_ENV === "development") {
    console.warn("`IconEditBoxOutlined` is deprecated and will be removed in v4.0.0. (tentatively 31 October, 2025). Use `IconMaterialSymbolsFontDownload` instead.");
}
export default IconEditBoxOutlined;
//# sourceMappingURL=IconEditBoxOutlined.js.map