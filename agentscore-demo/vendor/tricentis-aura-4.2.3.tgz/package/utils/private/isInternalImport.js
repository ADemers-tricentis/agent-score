/**
 * Determines if the current module is being imported from an internal Aura
 * path.
 *
 * Internal paths include:
 * - `src/components/` (Aura React components)
 * - `src/constants/` (Aura constants)
 * - `src/utils/private/` (internal utilities)
 *
 * This is used to suppress deprecation warnings for internal usage while
 * showing warnings for external consumers.
 *
 * Uses Error.stack to detect the caller's import path, similar to how React
 * and Next.js detect internal vs external usage.
 * @returns Whether the import is from an internal path.
 * @internal
 */
// Match stack frames that clearly reference an Aura icon file path, for
// example:
// - ".../components/IconSearchOutlined.tsx:12:5"
// - "\\components\\IconStarFilled.js:8:3"
const ICON_FILE_STACK_PATTERN = /Icon[A-Z]\w*[^ )]*\.(?:c|m)?(?:ts|tsx|js|jsx|mjs|cjs)\b/;
// Match stack frames that only reference the icon symbol name (common in
// bundled code), for example:
// - "at IconSearchOutlined (...)"
// - "at IconStarFilled_tsx_default (...)"
const ICON_SYMBOL_STACK_PATTERN = /\bIcon[A-Z]\w+(?:_(?:ts|tsx|js|jsx|mjs|cjs|default|tsx_default))*\b/;
/**
 * Internal implementation for checking whether the current call stack suggests
 * the module is used by another Aura component (and not directly by consumers).
 * @returns Whether the import appears to be from an internal Aura usage.
 */
function isInternalImport() {
    // In ESM, we check the call stack to see if we're being imported
    // from an internal Aura path.
    try {
        const stack = new Error().stack;
        if (!stack) {
            return false;
        }
        // Check if any stack frame contains internal source paths
        // This matches patterns like:
        // - /path/to/src/components/Component.tsx
        // - /path/to/src/constants/constant.ts
        // - /path/to/src/utils/private/util.ts
        const internalSourcePathPatterns = [
            /[\\/]src[\\/]components[\\/]/,
            /[\\/]src[\\/]constants[\\/]/,
            /[\\/]src[\\/]utils[\\/]private[\\/]/,
        ];
        // If imported from internal source paths, suppress warnings
        if (internalSourcePathPatterns.some((pattern) => pattern.test(stack))) {
            return true;
        }
        // Check if imported by another Aura component (even if in node_modules)
        // This handles the case where external consumers import Aura components
        // (e.g., DrawerCloser) which internally use deprecated icons.
        // We suppress warnings when icons are used by other Aura components,
        // but show warnings when consumers directly import deprecated icons.
        const stackLines = stack.split("\n");
        // Check each stack line for Aura component references (exclude icon files)
        for (const line of stackLines) {
            // Skip lines that reference icon files themselves (Icon*.tsx, Icon*.js)
            // or only reference the icon symbol. This prevents matching the icon
            // module being checked.
            if (ICON_FILE_STACK_PATTERN.test(line) ||
                ICON_SYMBOL_STACK_PATTERN.test(line)) {
                continue;
            }
            // Match explicit Aura package paths for non-icon components/constants
            // This works for both source and built code in node_modules
            if (/[\\/]@tricentis[\\/]aura[\\/](?:components|constants)[\\/]/.test(line) &&
                !/Icon[A-Z]/.test(line)) {
                return true;
            }
            // Match common Aura component names in stack traces (non-icon components)
            // These indicate the icon is being used by an Aura component.
            // This works even when paths are obfuscated by bundlers.
            if (/(?:Toolbar|DrawerCloser|LazyInput|NavRail|SelectSpace|themeOptions|MuiChip)/.test(line)) {
                return true;
            }
            // Fallback: Check for non-icon component file references in bundled code
            // This is a heuristic that works when path-based detection fails due to
            // bundling/minification. We look for component names that don't start
            // with "Icon" in the components/ directory.
            if (/[\\/](?:components|constants)[\\/]/.test(line) &&
                !/Icon[A-Z]/.test(line) &&
                !/[\\/]node_modules[\\/](?![\\/]@tricentis[\\/]aura)/.test(line)) {
                // Found a non-icon component reference, likely internal usage
                return true;
            }
        }
        return false;
    }
    catch {
        // If stack trace is unavailable, default to showing warnings
        return false;
    }
}
/**
 * Checks if the current module is being imported from an internal Aura path.
 *
 * Note: We don't cache the result because the same icon module might be imported
 * both internally (by Aura components) and externally (by consumers). We need
 * to check the stack trace each time to determine the actual import context.
 * @returns Whether the import is from an internal path.
 * @internal
 */
export default function checkIsInternalImport() {
    return isInternalImport();
}
//# sourceMappingURL=isInternalImport.js.map