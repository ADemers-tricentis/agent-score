/**
 * Converts a pixel string (e.g. `"8px"`) to a number (e.g. `8`). Useful for
 * converting a Material UI theme `spacing` pixel string value to a number so it
 * can be used in calculations, see
 * [mui/material-ui#29086](https://github.com/mui/material-ui/issues/29086).
 * @param pxString Pixel string consisting of a number followed by `px`.
 * @returns Number of pixels.
 */
export default function pxStringToNumber(pxString) {
    return Number(pxString.replace(/px$/u, ""));
}
//# sourceMappingURL=pxStringToNumber.js.map