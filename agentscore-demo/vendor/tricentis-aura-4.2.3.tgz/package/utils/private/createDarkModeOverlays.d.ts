/**
 * Creates the dark mode overlays array for MUI theme.
 *
 * This replaces MUI's default logarithmic white overlay system with a hybrid
 * approach using our discrete surface tokens at known elevations.
 *
 * ## Background
 *
 * MUI's default dark mode uses white overlays on Paper to indicate elevation:
 * `opacity = (4.5 × ln(elevation + 1) + 2) / 100`
 *
 * We replace this with:
 * - **Known elevations** (used by MUI components): Solid HSLA surface colors
 * - **Other elevations**: Interpolated white overlay percentages
 *
 * ## Surface Token Mapping
 *
 * | Elevation | Component         | Surface Tier |
 * |-----------|-------------------|--------------|
 * | 0         | (none)            | none         |
 * | 1         | Card, Accordion   | raised       |
 * | 6         | SnackbarContent   | overlay      |
 * | 8         | Menu, Popover     | overlay      |
 * | 16        | Drawer            | modal        |
 * | 24        | Dialog            | modal        |
 *
 * ## Math for Interpolated Values
 *
 * Base: `background.paper` = 10% lightness (SURFACE_DARK_RAISED)
 * Target: `overlay/modal` = 16% lightness
 *
 * To calculate white overlay % needed to reach a target lightness:
 * `target = base + overlay% × (100 - base)`
 * `overlay% = (target - base) / (100 - base)`
 *
 * For 16% lightness target on 10% base:
 * `overlay% = (16 - 10) / (100 - 10) = 6 / 90 ≈ 6.67%`
 *
 * For interpolation between anchors, we use logarithmic interpolation:
 * `t = ln(current - lower + 1) / ln(upper - lower + 1)`
 * `value = lowerValue + t × (upperValue - lowerValue)`
 */
/**
 * MUI Overlays tuple type - exactly 25 elements (0-24).
 */
type Overlays = [
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string,
    string
];
/**
 * Pre-computed overlays array for use in themeOptions.
 *
 * | Elev | Type         | Value                    |
 * |------|--------------|--------------------------|
 * | 0    | none         | none                     |
 * | 1    | none         | none                     |
 * | 2    | interpolated | ~2.73% white             |
 * | 3    | interpolated | ~4.32% white             |
 * | 4    | interpolated | ~5.47% white             |
 * | 5    | interpolated | ~6.26% white             |
 * | 6    | solid        | hsla(240, 4%, 16%, 1)    |
 * | 7    | interpolated | ~6.67% white             |
 * | 8    | solid        | hsla(240, 4%, 16%, 1)    |
 * | 9-15 | interpolated | ~6.67% white             |
 * | 16   | solid        | hsla(240, 4%, 16%, 1)    |
 * | 17-23| interpolated | ~6.67% white             |
 * | 24   | solid        | hsla(240, 4%, 16%, 1)    |
 */
declare const DARK_MODE_OVERLAYS: Overlays;
export default DARK_MODE_OVERLAYS;
