/**
 * Checks if a value is an array.
 * @see https://github.com/microsoft/TypeScript/issues/33700
 * @param value Value to check.
 * @returns Is the value an array.
 */
const isArray = Array.isArray;
export default isArray;
//# sourceMappingURL=isArray.js.map