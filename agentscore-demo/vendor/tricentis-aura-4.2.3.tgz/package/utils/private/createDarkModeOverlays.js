/**
 * Creates the dark mode overlays array for MUI theme.
 *
 * This replaces MUI's default logarithmic white overlay system with a hybrid
 * approach using our discrete surface tokens at known elevations.
 *
 * ## Background
 *
 * MUI's default dark mode uses white overlays on Paper to indicate elevation:
 * `opacity = (4.5 × ln(elevation + 1) + 2) / 100`
 *
 * We replace this with:
 * - **Known elevations** (used by MUI components): Solid HSLA surface colors
 * - **Other elevations**: Interpolated white overlay percentages
 *
 * ## Surface Token Mapping
 *
 * | Elevation | Component         | Surface Tier |
 * |-----------|-------------------|--------------|
 * | 0         | (none)            | none         |
 * | 1         | Card, Accordion   | raised       |
 * | 6         | SnackbarContent   | overlay      |
 * | 8         | Menu, Popover     | overlay      |
 * | 16        | Drawer            | modal        |
 * | 24        | Dialog            | modal        |
 *
 * ## Math for Interpolated Values
 *
 * Base: `background.paper` = 10% lightness (SURFACE_DARK_RAISED)
 * Target: `overlay/modal` = 16% lightness
 *
 * To calculate white overlay % needed to reach a target lightness:
 * `target = base + overlay% × (100 - base)`
 * `overlay% = (target - base) / (100 - base)`
 *
 * For 16% lightness target on 10% base:
 * `overlay% = (16 - 10) / (100 - 10) = 6 / 90 ≈ 6.67%`
 *
 * For interpolation between anchors, we use logarithmic interpolation:
 * `t = ln(current - lower + 1) / ln(upper - lower + 1)`
 * `value = lowerValue + t × (upperValue - lowerValue)`
 */
// Surface colors (must match themeOptions.tsx constants)
const SURFACE_DARK_OVERLAY = "hsla(240, 4%, 16%, 1)";
const SURFACE_DARK_MODAL = "hsla(240, 4%, 16%, 1)";
const ANCHORS = [
    { elevation: 0, type: "none" },
    { elevation: 1, type: "none" }, // raised = background.paper
    { elevation: 6, type: "solid", value: SURFACE_DARK_OVERLAY },
    { elevation: 8, type: "solid", value: SURFACE_DARK_OVERLAY },
    { elevation: 16, type: "solid", value: SURFACE_DARK_MODAL },
    { elevation: 24, type: "solid", value: SURFACE_DARK_MODAL },
];
// Target white overlay % for overlay/modal tier: (16 - 10) / (100 - 10) ≈ 6.67%
const MAX_OVERLAY_PERCENT = 6.67;
/**
 * Calculates interpolated white overlay % using logarithmic curve.
 * @param elevation - The elevation level (0-24)
 * @returns The white overlay percentage
 */
function getInterpolatedPercent(elevation) {
    if (elevation <= 1)
        return 0;
    if (elevation >= 6)
        return MAX_OVERLAY_PERCENT;
    // Logarithmic interpolation between elevation 1 and 6
    const lower = 1;
    const upper = 6;
    const t = Math.log(elevation - lower + 1) / Math.log(upper - lower + 1);
    return t * MAX_OVERLAY_PERCENT;
}
/**
 * Formats white overlay % as linear-gradient string.
 * @param percent - The white overlay percentage
 * @returns CSS linear-gradient string
 */
function formatWhiteOverlay(percent) {
    const opacity = (percent / 100).toFixed(4);
    return `linear-gradient(rgba(255 255 255 / ${opacity}), rgba(255 255 255 / ${opacity}))`;
}
/**
 * Formats solid HSLA color as linear-gradient string.
 * @param hsla - The HSLA color string
 * @returns CSS linear-gradient string
 */
function formatSolidOverlay(hsla) {
    return `linear-gradient(${hsla}, ${hsla})`;
}
/**
 * Creates the overlays array for dark mode (25 elements, indices 0-24).
 * @returns The overlays tuple for MUI theme
 */
function createDarkModeOverlays() {
    const anchorMap = new Map(ANCHORS.map((a) => [a.elevation, a]));
    const overlays = Array.from({ length: 25 }, (_, elevation) => {
        const anchor = anchorMap.get(elevation);
        if (anchor) {
            switch (anchor.type) {
                case "none":
                    return "none";
                case "solid":
                    return formatSolidOverlay(anchor.value);
                case "percent":
                    return formatWhiteOverlay(anchor.value);
            }
        }
        // Interpolated value for unknown elevations
        const percent = getInterpolatedPercent(elevation);
        return formatWhiteOverlay(percent);
    });
    return overlays;
}
/**
 * Pre-computed overlays array for use in themeOptions.
 *
 * | Elev | Type         | Value                    |
 * |------|--------------|--------------------------|
 * | 0    | none         | none                     |
 * | 1    | none         | none                     |
 * | 2    | interpolated | ~2.73% white             |
 * | 3    | interpolated | ~4.32% white             |
 * | 4    | interpolated | ~5.47% white             |
 * | 5    | interpolated | ~6.26% white             |
 * | 6    | solid        | hsla(240, 4%, 16%, 1)    |
 * | 7    | interpolated | ~6.67% white             |
 * | 8    | solid        | hsla(240, 4%, 16%, 1)    |
 * | 9-15 | interpolated | ~6.67% white             |
 * | 16   | solid        | hsla(240, 4%, 16%, 1)    |
 * | 17-23| interpolated | ~6.67% white             |
 * | 24   | solid        | hsla(240, 4%, 16%, 1)    |
 */
const DARK_MODE_OVERLAYS = createDarkModeOverlays();
export default DARK_MODE_OVERLAYS;
//# sourceMappingURL=createDarkModeOverlays.js.map