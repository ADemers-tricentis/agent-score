import { jsx as _jsx } from "react/jsx-runtime";
import Tooltip from "../components/Tooltip.js";
/**
 * Creates a React higher order component that wraps a given component with a
 * span and the Aura React component {@linkcode Tooltip}, that still works if
 * the given component has a native HTML attribute `disabled` that would
 * normally disable a tooltip.
 * @see https://mui.com/material-ui/react-tooltip/#disabled-elements
 * @param Component React component.
 * @returns React component that wraps the given component with a span and a
 *   tooltip.
 */
export default function withTooltip(Component) {
    return function WithTooltip({ tooltipProps, ...componentProps }) {
        return tooltipProps ? (_jsx(Tooltip, { ...tooltipProps, children: _jsx("span", { children: _jsx(Component, { ...componentProps }) }) })) : (_jsx(Component, { ...componentProps }));
    };
}
//# sourceMappingURL=withTooltip.js.map