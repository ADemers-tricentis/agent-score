// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`airline_stops`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:airline_stops:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M449.62-280q-9-134.31-98.27-230.08-89.27-95.77-218.89-108.08-13.38-1.23-22.92-10.15Q100-637.23%20100-650q0-12.77%209.31-21.38%209.31-8.62%2022.46-7%20118.54%209.84%20212.12%2082Q437.46-524.23%20480-411.84q34.54-87.93%2099.42-154.66%2064.89-66.73%20147.27-113.5H595.77q-12.77%200-21.39-8.62-8.61-8.61-8.61-21.38t8.61-21.38Q583-740%20595.77-740h188.07q15.47%200%2025.81%2010.35Q820-719.31%20820-703.84v188.07q0%2012.77-8.62%2021.39-8.61%208.61-21.38%208.61t-21.38-8.61Q760-503%20760-515.77v-114.31q-100.69%2057-171.54%20146.58-70.85%2089.58-78.85%20203.5h47.31q12.77%200%2021.39%208.62%208.61%208.61%208.61%2021.38t-8.61%2021.38q-8.62%208.62-21.39%208.62h-155q-12.77%200-21.38-8.62-8.62-8.61-8.62-21.38t8.62-21.38q8.61-8.62%2021.38-8.62h47.7Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAirlineStopsFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M449.62-280q-9-134.31-98.27-230.08-89.27-95.77-218.89-108.08-13.38-1.23-22.92-10.15Q100-637.23 100-650q0-12.77 9.31-21.38 9.31-8.62 22.46-7 118.54 9.84 212.12 82Q437.46-524.23 480-411.84q34.54-87.93 99.42-154.66 64.89-66.73 147.27-113.5H595.77q-12.77 0-21.39-8.62-8.61-8.61-8.61-21.38t8.61-21.38Q583-740 595.77-740h188.07q15.47 0 25.81 10.35Q820-719.31 820-703.84v188.07q0 12.77-8.62 21.39-8.61 8.61-21.38 8.61t-21.38-8.61Q760-503 760-515.77v-114.31q-100.69 57-171.54 146.58-70.85 89.58-78.85 203.5h47.31q12.77 0 21.39 8.62 8.61 8.61 8.61 21.38t-8.61 21.38q-8.62 8.62-21.39 8.62h-155q-12.77 0-21.38-8.62-8.62-8.61-8.62-21.38t8.62-21.38q8.61-8.62 21.38-8.62h47.7Z",
    }),
  }),
  "IconMaterialSymbolsAirlineStopsFill",
);

export default IconMaterialSymbolsAirlineStopsFill;
