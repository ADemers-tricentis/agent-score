// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`add_to_queue`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:add_to_queue:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M450-490v90q0%2012.75%208.63%2021.37%208.63%208.63%2021.38%208.63%2012.76%200%2021.37-8.63Q510-387.25%20510-400v-90h90q12.75%200%2021.37-8.63%208.63-8.63%208.63-21.38%200-12.76-8.63-21.37Q612.75-550%20600-550h-90v-90q0-12.75-8.63-21.37-8.63-8.63-21.38-8.63-12.76%200-21.37%208.63Q450-652.75%20450-640v90h-90q-12.75%200-21.37%208.63-8.63%208.63-8.63%2021.38%200%2012.76%208.63%2021.37Q347.25-490%20360-490h90ZM172.31-220Q142-220%20121-241q-21-21-21-51.31v-455.38Q100-778%20121-799q21-21%2051.31-21h615.38Q818-820%20839-799q21%2021%2021%2051.31v455.38Q860-262%20839-241q-21%2021-51.31%2021H620v43.84q0%2015.37-10.4%2025.76-10.39%2010.4-25.76%2010.4H376.16q-15.37%200-25.76-10.4-10.4-10.39-10.4-25.76V-220H172.31Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAddToQueueFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M450-490v90q0 12.75 8.63 21.37 8.63 8.63 21.38 8.63 12.76 0 21.37-8.63Q510-387.25 510-400v-90h90q12.75 0 21.37-8.63 8.63-8.63 8.63-21.38 0-12.76-8.63-21.37Q612.75-550 600-550h-90v-90q0-12.75-8.63-21.37-8.63-8.63-21.38-8.63-12.76 0-21.37 8.63Q450-652.75 450-640v90h-90q-12.75 0-21.37 8.63-8.63 8.63-8.63 21.38 0 12.76 8.63 21.37Q347.25-490 360-490h90ZM172.31-220Q142-220 121-241q-21-21-21-51.31v-455.38Q100-778 121-799q21-21 51.31-21h615.38Q818-820 839-799q21 21 21 51.31v455.38Q860-262 839-241q-21 21-51.31 21H620v43.84q0 15.37-10.4 25.76-10.39 10.4-25.76 10.4H376.16q-15.37 0-25.76-10.4-10.4-10.39-10.4-25.76V-220H172.31Z",
    }),
  }),
  "IconMaterialSymbolsAddToQueueFill",
);

export default IconMaterialSymbolsAddToQueueFill;
