// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`airline_seat_flat_angled`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:airline_seat_flat_angled:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22m387.54-497.85%2049.23-134.23q8.69-23.69%2031.19-34.42t46.19-2.04l261.08%2095.23q54.92%2019.93%2079.65%2072.12%2024.73%2052.19%204.43%20107.11l-22%2060q-5.62%2014.08-19.08%2020.69-13.46%206.62-27.54%201L409.23-451.23q-14.46-5.62-20.88-18.89-6.43-13.27-.81-27.73Zm368.84%20295.77L118.62-433.85q-11.77-3.84-16.73-15.19-4.96-11.35-1.12-23.11%203.85-11.77%2015.5-17.04t23.42-.81l637.77%20231.77q11.77%203.84%2016.73%2015.19%204.96%2011.35%201.12%2023.12-3.85%2011.76-15.5%2017.03-11.66%205.27-23.43.81ZM189.73-541.65q-29.8-29.81-29.8-72.12t29.8-72.11q29.81-29.81%2072.12-29.81%2042.3%200%2072.11%2029.81%2029.81%2029.8%2029.81%2072.11t-29.81%2072.12q-29.81%2029.8-72.11%2029.8-42.31%200-72.12-29.8Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAirlineSeatFlatAngledFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "m387.54-497.85 49.23-134.23q8.69-23.69 31.19-34.42t46.19-2.04l261.08 95.23q54.92 19.93 79.65 72.12 24.73 52.19 4.43 107.11l-22 60q-5.62 14.08-19.08 20.69-13.46 6.62-27.54 1L409.23-451.23q-14.46-5.62-20.88-18.89-6.43-13.27-.81-27.73Zm368.84 295.77L118.62-433.85q-11.77-3.84-16.73-15.19-4.96-11.35-1.12-23.11 3.85-11.77 15.5-17.04t23.42-.81l637.77 231.77q11.77 3.84 16.73 15.19 4.96 11.35 1.12 23.12-3.85 11.76-15.5 17.03-11.66 5.27-23.43.81ZM189.73-541.65q-29.8-29.81-29.8-72.12t29.8-72.11q29.81-29.81 72.12-29.81 42.3 0 72.11 29.81 29.81 29.8 29.81 72.11t-29.81 72.12q-29.81 29.8-72.11 29.8-42.31 0-72.12-29.8Z",
    }),
  }),
  "IconMaterialSymbolsAirlineSeatFlatAngledFill",
);

export default IconMaterialSymbolsAirlineSeatFlatAngledFill;
