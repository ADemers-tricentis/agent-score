// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`aod_tablet`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:aod_tablet:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M132.31-180q-29.83%200-51.07-21.24Q60-222.48%2060-252.31v-455.38q0-29.83%2021.24-51.07Q102.48-780%20132.31-780h695.38q29.83%200%2051.07%2021.24Q900-737.52%20900-707.69v455.38q0%2029.83-21.24%2051.07Q857.52-180%20827.69-180H132.31ZM230-240h500v-480H230v480Zm123.85-266.15q-10.34%200-17.09-6.76-6.76-6.75-6.76-17.07%200-10.33%206.76-17.1%206.75-6.77%2017.09-6.77h252.3q10.34%200%2017.09%206.76%206.76%206.75%206.76%2017.07%200%2010.33-6.76%2017.1-6.75%206.77-17.09%206.77h-252.3Zm40%20120q-10.34%200-17.09-6.76-6.76-6.75-6.76-17.07%200-10.33%206.76-17.1%206.75-6.77%2017.09-6.77h172.3q10.34%200%2017.09%206.76%206.76%206.75%206.76%2017.07%200%2010.33-6.76%2017.1-6.75%206.77-17.09%206.77h-172.3Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAodTabletFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M132.31-180q-29.83 0-51.07-21.24Q60-222.48 60-252.31v-455.38q0-29.83 21.24-51.07Q102.48-780 132.31-780h695.38q29.83 0 51.07 21.24Q900-737.52 900-707.69v455.38q0 29.83-21.24 51.07Q857.52-180 827.69-180H132.31ZM230-240h500v-480H230v480Zm123.85-266.15q-10.34 0-17.09-6.76-6.76-6.75-6.76-17.07 0-10.33 6.76-17.1 6.75-6.77 17.09-6.77h252.3q10.34 0 17.09 6.76 6.76 6.75 6.76 17.07 0 10.33-6.76 17.1-6.75 6.77-17.09 6.77h-252.3Zm40 120q-10.34 0-17.09-6.76-6.76-6.75-6.76-17.07 0-10.33 6.76-17.1 6.75-6.77 17.09-6.77h172.3q10.34 0 17.09 6.76 6.76 6.75 6.76 17.07 0 10.33-6.76 17.1-6.75 6.77-17.09 6.77h-172.3Z",
    }),
  }),
  "IconMaterialSymbolsAodTabletFill",
);

export default IconMaterialSymbolsAodTabletFill;
