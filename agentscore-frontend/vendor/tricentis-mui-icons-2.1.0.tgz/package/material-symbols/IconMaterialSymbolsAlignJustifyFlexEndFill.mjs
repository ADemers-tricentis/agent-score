// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_justify_flex_end`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_justify_flex_end:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M808.62-108.63Q800-117.25%20800-130v-700q0-12.75%208.63-21.37%208.63-8.63%2021.38-8.63%2012.76%200%2021.37%208.63Q860-842.75%20860-830v700q0%2012.75-8.63%2021.37-8.63%208.63-21.38%208.63-12.76%200-21.37-8.63ZM606.15-290q-15.36%200-25.76-10.39Q570-310.79%20570-326.15v-307.7q0-15.36%2010.39-25.76Q590.79-670%20606.15-670h27.7q15.36%200%2025.76%2010.39Q670-649.21%20670-633.85v307.7q0%2015.36-10.39%2025.76Q649.21-290%20633.85-290h-27.7Zm-240%200q-15.36%200-25.76-10.39Q330-310.79%20330-326.15v-307.7q0-15.36%2010.39-25.76Q350.79-670%20366.15-670h27.7q15.36%200%2025.76%2010.39Q430-649.21%20430-633.85v307.7q0%2015.36-10.39%2025.76Q409.21-290%20393.85-290h-27.7Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignJustifyFlexEndFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M808.62-108.63Q800-117.25 800-130v-700q0-12.75 8.63-21.37 8.63-8.63 21.38-8.63 12.76 0 21.37 8.63Q860-842.75 860-830v700q0 12.75-8.63 21.37-8.63 8.63-21.38 8.63-12.76 0-21.37-8.63ZM606.15-290q-15.36 0-25.76-10.39Q570-310.79 570-326.15v-307.7q0-15.36 10.39-25.76Q590.79-670 606.15-670h27.7q15.36 0 25.76 10.39Q670-649.21 670-633.85v307.7q0 15.36-10.39 25.76Q649.21-290 633.85-290h-27.7Zm-240 0q-15.36 0-25.76-10.39Q330-310.79 330-326.15v-307.7q0-15.36 10.39-25.76Q350.79-670 366.15-670h27.7q15.36 0 25.76 10.39Q430-649.21 430-633.85v307.7q0 15.36-10.39 25.76Q409.21-290 393.85-290h-27.7Z",
    }),
  }),
  "IconMaterialSymbolsAlignJustifyFlexEndFill",
);

export default IconMaterialSymbolsAlignJustifyFlexEndFill;
