// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`airline_seat_recline_normal`, without fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:airline_seat_recline_normal:FILL@0;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M565-180H327.31Q297-180%20276-201q-21-21-21-51.31V-650q0-12.77%208.62-21.38Q272.23-680%20285-680t21.38%208.62Q315-662.77%20315-650v397.69q0%204.62%203.85%208.46%203.84%203.85%208.46%203.85H565q12.77%200%2021.38%208.62Q595-222.77%20595-210t-8.62%2021.38Q577.77-180%20565-180ZM445-710q-30.69%200-52.27-21.58-21.58-21.57-21.58-52.26%200-30.7%2021.58-52.27%2021.58-21.58%2052.27-21.58%2030.69%200%2052.27%2021.58%2021.57%2021.57%2021.57%2052.27%200%2030.69-21.57%2052.26Q475.69-710%20445-710Zm200%20590v-160H425q-29.15%200-49.58-20.42Q355-320.85%20355-350v-225.38q0-38.16%2025.92-64.08%2025.93-25.92%2064.08-25.92t64.08%2025.92Q535-613.54%20535-575.38V-380h100q29.15%200%2049.58%2020.42Q705-339.15%20705-310v190q0%2012.77-8.62%2021.38Q687.77-90%20675-90t-21.38-8.62Q645-107.23%20645-120Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAirlineSeatReclineNormal = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M565-180H327.31Q297-180 276-201q-21-21-21-51.31V-650q0-12.77 8.62-21.38Q272.23-680 285-680t21.38 8.62Q315-662.77 315-650v397.69q0 4.62 3.85 8.46 3.84 3.85 8.46 3.85H565q12.77 0 21.38 8.62Q595-222.77 595-210t-8.62 21.38Q577.77-180 565-180ZM445-710q-30.69 0-52.27-21.58-21.58-21.57-21.58-52.26 0-30.7 21.58-52.27 21.58-21.58 52.27-21.58 30.69 0 52.27 21.58 21.57 21.57 21.57 52.27 0 30.69-21.57 52.26Q475.69-710 445-710Zm200 590v-160H425q-29.15 0-49.58-20.42Q355-320.85 355-350v-225.38q0-38.16 25.92-64.08 25.93-25.92 64.08-25.92t64.08 25.92Q535-613.54 535-575.38V-380h100q29.15 0 49.58 20.42Q705-339.15 705-310v190q0 12.77-8.62 21.38Q687.77-90 675-90t-21.38-8.62Q645-107.23 645-120Z",
    }),
  }),
  "IconMaterialSymbolsAirlineSeatReclineNormal",
);

export default IconMaterialSymbolsAirlineSeatReclineNormal;
