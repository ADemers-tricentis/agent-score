// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`ad_units`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:ad_units:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M292.31-60q-29.83%200-51.07-21.24Q220-102.48%20220-132.31v-695.38Q220-858%20241-879q21-21%2051.31-21h376.92q29.83%200%2051.07%2021.24%2021.24%2021.24%2021.24%2051.07v126.31q16.46%204.3%2027.46%2017.19%2011%2012.88%2011%2029.96v75.38q0%2017.08-11%2029.97-11%2012.88-27.46%2017.19v399.38q0%2029.83-21.24%2051.07Q699.06-60%20669.23-60H292.31Zm65.38-428.08h246.16q12.75%200%2021.37-8.63%208.63-8.62%208.63-21.38t-8.63-21.37q-8.62-8.62-21.37-8.62H357.69q-12.75%200-21.37%208.63-8.63%208.63-8.63%2021.39%200%2012.75%208.63%2021.37%208.62%208.61%2021.37%208.61Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAdUnitsFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M292.31-60q-29.83 0-51.07-21.24Q220-102.48 220-132.31v-695.38Q220-858 241-879q21-21 51.31-21h376.92q29.83 0 51.07 21.24 21.24 21.24 21.24 51.07v126.31q16.46 4.3 27.46 17.19 11 12.88 11 29.96v75.38q0 17.08-11 29.97-11 12.88-27.46 17.19v399.38q0 29.83-21.24 51.07Q699.06-60 669.23-60H292.31Zm65.38-428.08h246.16q12.75 0 21.37-8.63 8.63-8.62 8.63-21.38t-8.63-21.37q-8.62-8.62-21.37-8.62H357.69q-12.75 0-21.37 8.63-8.63 8.63-8.63 21.39 0 12.75 8.63 21.37 8.62 8.61 21.37 8.61Z",
    }),
  }),
  "IconMaterialSymbolsAdUnitsFill",
);

export default IconMaterialSymbolsAdUnitsFill;
