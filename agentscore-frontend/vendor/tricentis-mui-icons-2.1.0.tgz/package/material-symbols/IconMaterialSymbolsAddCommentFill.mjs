// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`add_comment`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:add_comment:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22m241.54-260-80.08%2080.07q-17.07%2017.08-39.27%207.68-22.19-9.41-22.19-33.6v-581.84Q100-818%20121-839q21-21%2051.31-21h615.38Q818-860%20839-839q21%2021%2021%2051.31v455.38Q860-302%20839-281q-21%2021-51.31%2021H241.54ZM450-530v90q0%2012.75%208.63%2021.37%208.63%208.63%2021.38%208.63%2012.76%200%2021.37-8.63Q510-427.25%20510-440v-90h90q12.75%200%2021.37-8.63%208.63-8.63%208.63-21.38%200-12.76-8.63-21.37Q612.75-590%20600-590h-90v-90q0-12.75-8.63-21.37-8.63-8.63-21.38-8.63-12.76%200-21.37%208.63Q450-692.75%20450-680v90h-90q-12.75%200-21.37%208.63-8.63%208.63-8.63%2021.38%200%2012.76%208.63%2021.37Q347.25-530%20360-530h90Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAddCommentFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "m241.54-260-80.08 80.07q-17.07 17.08-39.27 7.68-22.19-9.41-22.19-33.6v-581.84Q100-818 121-839q21-21 51.31-21h615.38Q818-860 839-839q21 21 21 51.31v455.38Q860-302 839-281q-21 21-51.31 21H241.54ZM450-530v90q0 12.75 8.63 21.37 8.63 8.63 21.38 8.63 12.76 0 21.37-8.63Q510-427.25 510-440v-90h90q12.75 0 21.37-8.63 8.63-8.63 8.63-21.38 0-12.76-8.63-21.37Q612.75-590 600-590h-90v-90q0-12.75-8.63-21.37-8.63-8.63-21.38-8.63-12.76 0-21.37 8.63Q450-692.75 450-680v90h-90q-12.75 0-21.37 8.63-8.63 8.63-8.63 21.38 0 12.76 8.63 21.37Q347.25-530 360-530h90Z",
    }),
  }),
  "IconMaterialSymbolsAddCommentFill",
);

export default IconMaterialSymbolsAddCommentFill;
