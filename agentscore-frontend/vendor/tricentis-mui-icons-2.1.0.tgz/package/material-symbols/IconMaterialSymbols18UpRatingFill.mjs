// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`18_up_rating`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:18_up_rating:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M346.15-546.15V-390q0%2010.33%206.76%2017.09%206.75%206.76%2017.07%206.76%2010.33%200%2017.1-6.76%206.77-6.76%206.77-17.09v-180q0-10.33-6.76-17.09T370-593.85h-60q-10.33%200-17.09%206.76-6.76%206.75-6.76%2017.07%200%2010.33%206.76%2017.1%206.76%206.77%2017.09%206.77h36.15Zm155.39%20180h96.92q15.04%200%2025.21-10.18%2010.18-10.17%2010.18-25.21v-156.92q0-15.04-10.18-25.21-10.17-10.18-25.21-10.18h-96.92q-15.04%200-25.21%2010.18-10.18%2010.17-10.18%2025.21v156.92q0%2015.04%2010.18%2025.21%2010.17%2010.18%2025.21%2010.18Zm12.31-35.39v-60.77h72.3v60.77h-72.3Zm0-96.15v-60.77h72.3v60.77h-72.3ZM212.31-140Q182-140%20161-161q-21-21-21-51.31v-535.38Q140-778%20161-799q21-21%2051.31-21h535.38Q778-820%20799-799q21%2021%2021%2051.31v535.38Q820-182%20799-161q-21%2021-51.31%2021H212.31Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbols18UpRatingFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M346.15-546.15V-390q0 10.33 6.76 17.09 6.75 6.76 17.07 6.76 10.33 0 17.1-6.76 6.77-6.76 6.77-17.09v-180q0-10.33-6.76-17.09T370-593.85h-60q-10.33 0-17.09 6.76-6.76 6.75-6.76 17.07 0 10.33 6.76 17.1 6.76 6.77 17.09 6.77h36.15Zm155.39 180h96.92q15.04 0 25.21-10.18 10.18-10.17 10.18-25.21v-156.92q0-15.04-10.18-25.21-10.17-10.18-25.21-10.18h-96.92q-15.04 0-25.21 10.18-10.18 10.17-10.18 25.21v156.92q0 15.04 10.18 25.21 10.17 10.18 25.21 10.18Zm12.31-35.39v-60.77h72.3v60.77h-72.3Zm0-96.15v-60.77h72.3v60.77h-72.3ZM212.31-140Q182-140 161-161q-21-21-21-51.31v-535.38Q140-778 161-799q21-21 51.31-21h535.38Q778-820 799-799q21 21 21 51.31v535.38Q820-182 799-161q-21 21-51.31 21H212.31Z",
    }),
  }),
  "IconMaterialSymbols18UpRatingFill",
);

export default IconMaterialSymbols18UpRatingFill;
