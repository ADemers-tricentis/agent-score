// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_flex_center`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_flex_center:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M462.46-108.63q-8.61-8.62-8.61-21.37v-300h-287.7q-15.36%200-25.76-10.39Q130-450.79%20130-466.15v-27.7q0-15.36%2010.39-25.76Q150.79-530%20166.15-530h287.7v-300q0-12.75%208.63-21.37%208.62-8.63%2021.38-8.63t21.37%208.63q8.62%208.62%208.62%2021.37v300h280q15.36%200%2025.76%2010.39Q830-509.21%20830-493.85v27.7q0%2015.36-10.39%2025.76Q809.21-430%20793.85-430h-280v300q0%2012.75-8.63%2021.37-8.63%208.63-21.39%208.63-12.75%200-21.37-8.63Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignFlexCenterFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M462.46-108.63q-8.61-8.62-8.61-21.37v-300h-287.7q-15.36 0-25.76-10.39Q130-450.79 130-466.15v-27.7q0-15.36 10.39-25.76Q150.79-530 166.15-530h287.7v-300q0-12.75 8.63-21.37 8.62-8.63 21.38-8.63t21.37 8.63q8.62 8.62 8.62 21.37v300h280q15.36 0 25.76 10.39Q830-509.21 830-493.85v27.7q0 15.36-10.39 25.76Q809.21-430 793.85-430h-280v300q0 12.75-8.63 21.37-8.63 8.63-21.39 8.63-12.75 0-21.37-8.63Z",
    }),
  }),
  "IconMaterialSymbolsAlignFlexCenterFill",
);

export default IconMaterialSymbolsAlignFlexCenterFill;
