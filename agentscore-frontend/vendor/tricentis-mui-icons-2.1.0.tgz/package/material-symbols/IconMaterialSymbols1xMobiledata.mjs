// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`1x_mobiledata`, without fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:1x_mobiledata:FILL@0;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M250-610h-50q-12.75%200-21.37-8.63-8.63-8.63-8.63-21.38%200-12.76%208.63-21.37Q187.25-670%20200-670h80q12.75%200%2021.37%208.63Q310-652.75%20310-640v320q0%2012.75-8.63%2021.37-8.63%208.63-21.38%208.63-12.76%200-21.37-8.63Q250-307.25%20250-320v-290Zm336%20176.77-77.08%20128.84q-3.76%206.82-10.16%2010.6-6.4%203.79-14.68%203.79-17.31%200-25.93-15-8.61-15%20.31-30l93.08-157-80.08-132q-9.31-15.38-.52-30.69Q479.72-670%20497.29-670q8.4%200%2015.47%204.13%207.06%204.12%2010.78%2010.87l63.23%20104.23%2063.69-104.84q3.75-6.82%2010.51-10.6%206.75-3.79%2015-3.79%2017.26%200%2025.88%2015%208.61%2015-.31%2030l-79.08%20133%2092.69%20156q9.31%2015.38.31%2030.69T688.56-290q-8.2%200-15.28-4.13-7.09-4.12-10.82-10.87L586-433.23Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbols1xMobiledata = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M250-610h-50q-12.75 0-21.37-8.63-8.63-8.63-8.63-21.38 0-12.76 8.63-21.37Q187.25-670 200-670h80q12.75 0 21.37 8.63Q310-652.75 310-640v320q0 12.75-8.63 21.37-8.63 8.63-21.38 8.63-12.76 0-21.37-8.63Q250-307.25 250-320v-290Zm336 176.77-77.08 128.84q-3.76 6.82-10.16 10.6-6.4 3.79-14.68 3.79-17.31 0-25.93-15-8.61-15 .31-30l93.08-157-80.08-132q-9.31-15.38-.52-30.69Q479.72-670 497.29-670q8.4 0 15.47 4.13 7.06 4.12 10.78 10.87l63.23 104.23 63.69-104.84q3.75-6.82 10.51-10.6 6.75-3.79 15-3.79 17.26 0 25.88 15 8.61 15-.31 30l-79.08 133 92.69 156q9.31 15.38.31 30.69T688.56-290q-8.2 0-15.28-4.13-7.09-4.12-10.82-10.87L586-433.23Z",
    }),
  }),
  "IconMaterialSymbols1xMobiledata",
);

export default IconMaterialSymbols1xMobiledata;
