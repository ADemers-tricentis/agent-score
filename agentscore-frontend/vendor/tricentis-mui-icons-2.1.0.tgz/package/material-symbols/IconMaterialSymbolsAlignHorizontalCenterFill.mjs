// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_horizontal_center`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_horizontal_center:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M450-130v-163.85H310.39q-20.77%200-35.58-14.8Q260-323.46%20260-344.23q0-20.77%2014.81-35.58%2014.81-14.8%2035.58-14.8H450v-170.78H190.39q-20.77%200-35.58-14.8Q140-595%20140-615.77q0-20.77%2014.81-35.58%2014.81-14.8%2035.58-14.8H450V-830q0-12.77%208.62-21.38Q467.23-860%20480-860t21.38%208.62Q510-842.77%20510-830v163.85h259.61q20.77%200%2035.58%2014.8Q820-636.54%20820-615.77q0%2020.77-14.81%2035.58-14.81%2014.8-35.58%2014.8H510v170.78h139.61q20.77%200%2035.58%2014.8Q700-365%20700-344.23q0%2020.77-14.81%2035.58-14.81%2014.8-35.58%2014.8H510V-130q0%2012.77-8.62%2021.38Q492.77-100%20480-100t-21.38-8.62Q450-117.23%20450-130Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignHorizontalCenterFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M450-130v-163.85H310.39q-20.77 0-35.58-14.8Q260-323.46 260-344.23q0-20.77 14.81-35.58 14.81-14.8 35.58-14.8H450v-170.78H190.39q-20.77 0-35.58-14.8Q140-595 140-615.77q0-20.77 14.81-35.58 14.81-14.8 35.58-14.8H450V-830q0-12.77 8.62-21.38Q467.23-860 480-860t21.38 8.62Q510-842.77 510-830v163.85h259.61q20.77 0 35.58 14.8Q820-636.54 820-615.77q0 20.77-14.81 35.58-14.81 14.8-35.58 14.8H510v170.78h139.61q20.77 0 35.58 14.8Q700-365 700-344.23q0 20.77-14.81 35.58-14.81 14.8-35.58 14.8H510V-130q0 12.77-8.62 21.38Q492.77-100 480-100t-21.38-8.62Q450-117.23 450-130Z",
    }),
  }),
  "IconMaterialSymbolsAlignHorizontalCenterFill",
);

export default IconMaterialSymbolsAlignHorizontalCenterFill;
