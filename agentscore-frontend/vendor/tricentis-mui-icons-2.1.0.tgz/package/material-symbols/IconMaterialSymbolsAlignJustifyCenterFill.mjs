// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_justify_center`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_justify_center:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M458.62-108.63Q450-117.25%20450-130v-700q0-12.75%208.63-21.37%208.63-8.63%2021.38-8.63%2012.76%200%2021.37%208.63Q510-842.75%20510-830v700q0%2012.75-8.63%2021.37-8.63%208.63-21.38%208.63-12.76%200-21.37-8.63ZM630.77-290q-15.37%200-25.76-10.39-10.4-10.4-10.4-25.76v-307.7q0-15.36%2010.4-25.76Q615.4-670%20630.77-670h27.69q15.37%200%2025.76%2010.39%2010.39%2010.4%2010.39%2025.76v307.7q0%2015.36-10.39%2025.76Q673.83-290%20658.46-290h-27.69Zm-329.23%200q-15.37%200-25.76-10.39-10.39-10.4-10.39-25.76v-307.7q0-15.36%2010.39-25.76Q286.17-670%20301.54-670h27.69q15.37%200%2025.76%2010.39%2010.4%2010.4%2010.4%2025.76v307.7q0%2015.36-10.4%2025.76Q344.6-290%20329.23-290h-27.69Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignJustifyCenterFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M458.62-108.63Q450-117.25 450-130v-700q0-12.75 8.63-21.37 8.63-8.63 21.38-8.63 12.76 0 21.37 8.63Q510-842.75 510-830v700q0 12.75-8.63 21.37-8.63 8.63-21.38 8.63-12.76 0-21.37-8.63ZM630.77-290q-15.37 0-25.76-10.39-10.4-10.4-10.4-25.76v-307.7q0-15.36 10.4-25.76Q615.4-670 630.77-670h27.69q15.37 0 25.76 10.39 10.39 10.4 10.39 25.76v307.7q0 15.36-10.39 25.76Q673.83-290 658.46-290h-27.69Zm-329.23 0q-15.37 0-25.76-10.39-10.39-10.4-10.39-25.76v-307.7q0-15.36 10.39-25.76Q286.17-670 301.54-670h27.69q15.37 0 25.76 10.39 10.4 10.4 10.4 25.76v307.7q0 15.36-10.4 25.76Q344.6-290 329.23-290h-27.69Z",
    }),
  }),
  "IconMaterialSymbolsAlignJustifyCenterFill",
);

export default IconMaterialSymbolsAlignJustifyCenterFill;
