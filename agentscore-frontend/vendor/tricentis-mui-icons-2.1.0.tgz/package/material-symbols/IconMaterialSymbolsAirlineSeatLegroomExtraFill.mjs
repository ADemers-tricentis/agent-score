// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`airline_seat_legroom_extra`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:airline_seat_legroom_extra:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M485.39-290h-317.7q-29.92%200-51.11-21.19-21.19-21.2-21.19-51.12V-800q0-12.77%208.61-21.38%208.62-8.62%2021.39-8.62%2012.76%200%2021.38%208.62%208.61%208.61%208.61%2021.38v437.69q0%204.62%203.85%208.46%203.85%203.85%208.46%203.85h317.7q12.76%200%2021.38%208.62%208.61%208.61%208.61%2021.38t-8.61%2021.38q-8.62%208.62-21.38%208.62Zm122.3-100H333.08q-45.77%200-77.89-32.11-32.11-32.12-32.11-77.89v-293.85q0-15.46%2010.34-25.8Q243.77-830%20259.23-830h147.69q15.46%200%2025.81%2010.35%2010.35%2010.34%2010.35%2025.8V-570h138.46q20.31%200%2036.61%2011.16%2016.31%2011.15%2026.16%2029.46l130.61%20267.23%2054.77-24.62q18.39-8.31%2037.08-3.31%2018.69%205%2028%2022.39%209.69%2018.38%202.54%2037.38-7.16%2019-25.93%2027.69l-109.23%2049.7q-13.46%206.23-27.11%201-13.66-5.24-19.89-18.08L607.69-390Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAirlineSeatLegroomExtraFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M485.39-290h-317.7q-29.92 0-51.11-21.19-21.19-21.2-21.19-51.12V-800q0-12.77 8.61-21.38 8.62-8.62 21.39-8.62 12.76 0 21.38 8.62 8.61 8.61 8.61 21.38v437.69q0 4.62 3.85 8.46 3.85 3.85 8.46 3.85h317.7q12.76 0 21.38 8.62 8.61 8.61 8.61 21.38t-8.61 21.38q-8.62 8.62-21.38 8.62Zm122.3-100H333.08q-45.77 0-77.89-32.11-32.11-32.12-32.11-77.89v-293.85q0-15.46 10.34-25.8Q243.77-830 259.23-830h147.69q15.46 0 25.81 10.35 10.35 10.34 10.35 25.8V-570h138.46q20.31 0 36.61 11.16 16.31 11.15 26.16 29.46l130.61 267.23 54.77-24.62q18.39-8.31 37.08-3.31 18.69 5 28 22.39 9.69 18.38 2.54 37.38-7.16 19-25.93 27.69l-109.23 49.7q-13.46 6.23-27.11 1-13.66-5.24-19.89-18.08L607.69-390Z",
    }),
  }),
  "IconMaterialSymbolsAirlineSeatLegroomExtraFill",
);

export default IconMaterialSymbolsAirlineSeatLegroomExtraFill;
