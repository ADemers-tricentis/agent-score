// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`account_box`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:account_box:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M572.08-476.38Q610-514.31%20610-568.46t-37.92-92.08q-37.93-37.92-92.08-37.92t-92.08%2037.92Q350-622.61%20350-568.46t37.92%2092.08q37.93%2037.92%2092.08%2037.92t92.08-37.92ZM212.31-140Q182-140%20161-161q-21-21-21-51.31v-535.38Q140-778%20161-799q21-21%2051.31-21h535.38Q778-820%20799-799q21%2021%2021%2051.31v535.38Q820-182%20799-161q-21%2021-51.31%2021H212.31Zm-3.85-60h543.08q4.23-4.15%205.77-18.58%201.54-14.42%202.69-19.73-54-53-125.5-83.5T480-352.31q-83%200-154.5%2030.5T200-238.31q1.15%205.31%202.69%2019.73%201.54%2014.43%205.77%2018.58Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAccountBoxFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M572.08-476.38Q610-514.31 610-568.46t-37.92-92.08q-37.93-37.92-92.08-37.92t-92.08 37.92Q350-622.61 350-568.46t37.92 92.08q37.93 37.92 92.08 37.92t92.08-37.92ZM212.31-140Q182-140 161-161q-21-21-21-51.31v-535.38Q140-778 161-799q21-21 51.31-21h535.38Q778-820 799-799q21 21 21 51.31v535.38Q820-182 799-161q-21 21-51.31 21H212.31Zm-3.85-60h543.08q4.23-4.15 5.77-18.58 1.54-14.42 2.69-19.73-54-53-125.5-83.5T480-352.31q-83 0-154.5 30.5T200-238.31q1.15 5.31 2.69 19.73 1.54 14.43 5.77 18.58Z",
    }),
  }),
  "IconMaterialSymbolsAccountBoxFill",
);

export default IconMaterialSymbolsAccountBoxFill;
