// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`add_triangle`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:add_triangle:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M154.77-180q-31.54%200-47.19-27.12-15.66-27.11.19-54.42L433-819.23q8.23-13.46%2020.84-20.38%2012.61-6.93%2026.11-6.93%2013.51%200%2026.17%206.93%2012.65%206.92%2020.88%2020.38l325.61%20557.69q15.85%2027.31.2%2054.42Q837.15-180%20805.61-180H154.77ZM450-396.92v48.84q0%2012.75%208.63%2021.38%208.63%208.62%2021.38%208.62%2012.76%200%2021.37-8.62%208.62-8.63%208.62-21.38v-48.84h49.62q12.75%200%2021.37-8.63%208.62-8.63%208.62-21.39%200-12.75-8.62-21.37-8.62-8.61-21.37-8.61H510v-48.47q0-12.74-8.63-21.37-8.63-8.62-21.38-8.62-12.76%200-21.37%208.62-8.62%208.63-8.62%2021.37v48.47h-49.23q-12.75%200-21.38%208.63-8.62%208.62-8.62%2021.38t8.62%2021.37q8.63%208.62%2021.38%208.62H450Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAddTriangleFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M154.77-180q-31.54 0-47.19-27.12-15.66-27.11.19-54.42L433-819.23q8.23-13.46 20.84-20.38 12.61-6.93 26.11-6.93 13.51 0 26.17 6.93 12.65 6.92 20.88 20.38l325.61 557.69q15.85 27.31.2 54.42Q837.15-180 805.61-180H154.77ZM450-396.92v48.84q0 12.75 8.63 21.38 8.63 8.62 21.38 8.62 12.76 0 21.37-8.62 8.62-8.63 8.62-21.38v-48.84h49.62q12.75 0 21.37-8.63 8.62-8.63 8.62-21.39 0-12.75-8.62-21.37-8.62-8.61-21.37-8.61H510v-48.47q0-12.74-8.63-21.37-8.63-8.62-21.38-8.62-12.76 0-21.37 8.62-8.62 8.63-8.62 21.37v48.47h-49.23q-12.75 0-21.38 8.63-8.62 8.62-8.62 21.38t8.62 21.37q8.63 8.62 21.38 8.62H450Z",
    }),
  }),
  "IconMaterialSymbolsAddTriangleFill",
);

export default IconMaterialSymbolsAddTriangleFill;
