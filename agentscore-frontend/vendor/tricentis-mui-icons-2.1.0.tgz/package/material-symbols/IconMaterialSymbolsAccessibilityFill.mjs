// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`accessibility`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:accessibility:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M427.92-746.38q-21.77-21.77-21.77-52.08t21.77-52.08q21.77-21.77%2052.08-21.77t52.08%2021.77q21.77%2021.77%2021.77%2052.08t-21.77%2052.08q-21.77%2021.76-52.08%2021.76t-52.08-21.76ZM376.16-120v-491.54H169.23q-12.75%200-21.37-8.63-8.63-8.63-8.63-21.38%200-12.76%208.63-21.37%208.62-8.62%2021.37-8.62h621.54q12.75%200%2021.37%208.63%208.63%208.63%208.63%2021.38%200%2012.76-8.63%2021.38-8.62%208.61-21.37%208.61H583.84V-120q0%2012.75-8.62%2021.37Q566.59-90%20553.83-90q-12.75%200-21.37-8.63-8.61-8.62-8.61-21.37v-200h-87.7v200q0%2012.77-8.63%2021.38Q418.9-90%20406.14-90q-12.75%200-21.37-8.63-8.61-8.62-8.61-21.37Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAccessibilityFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M427.92-746.38q-21.77-21.77-21.77-52.08t21.77-52.08q21.77-21.77 52.08-21.77t52.08 21.77q21.77 21.77 21.77 52.08t-21.77 52.08q-21.77 21.76-52.08 21.76t-52.08-21.76ZM376.16-120v-491.54H169.23q-12.75 0-21.37-8.63-8.63-8.63-8.63-21.38 0-12.76 8.63-21.37 8.62-8.62 21.37-8.62h621.54q12.75 0 21.37 8.63 8.63 8.63 8.63 21.38 0 12.76-8.63 21.38-8.62 8.61-21.37 8.61H583.84V-120q0 12.75-8.62 21.37Q566.59-90 553.83-90q-12.75 0-21.37-8.63-8.61-8.62-8.61-21.37v-200h-87.7v200q0 12.77-8.63 21.38Q418.9-90 406.14-90q-12.75 0-21.37-8.63-8.61-8.62-8.61-21.37Z",
    }),
  }),
  "IconMaterialSymbolsAccessibilityFill",
);

export default IconMaterialSymbolsAccessibilityFill;
