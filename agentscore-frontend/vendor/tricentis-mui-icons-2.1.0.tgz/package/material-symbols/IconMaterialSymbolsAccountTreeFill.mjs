// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`account_tree`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:account_tree:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M610-190.77V-250h-87.69q-29.92%200-51.12-21.19Q450-292.39%20450-322.31V-650H350v59.23q0%2025.31-17.73%2043.04T289.23-530H150.77q-25.31%200-43.04-17.73T90-590.77v-178.46q0-25.31%2017.73-43.04T150.77-830h138.46q25.31%200%2043.04%2017.73T350-769.23V-710h260v-59.23q0-25.31%2017.73-43.04T670.77-830h138.46q25.31%200%2043.04%2017.73T870-769.23v178.46q0%2025.31-17.73%2043.04T809.23-530H670.77q-25.31%200-43.04-17.73T610-590.77V-650H510v327.69q0%205.39%203.46%208.85t8.85%203.46H610v-59.23q0-25.31%2017.73-43.04T670.77-430h138.46q25.31%200%2043.04%2017.73T870-369.23v178.46q0%2025.31-17.73%2043.04T809.23-130H670.77q-25.31%200-43.04-17.73T610-190.77Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAccountTreeFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M610-190.77V-250h-87.69q-29.92 0-51.12-21.19Q450-292.39 450-322.31V-650H350v59.23q0 25.31-17.73 43.04T289.23-530H150.77q-25.31 0-43.04-17.73T90-590.77v-178.46q0-25.31 17.73-43.04T150.77-830h138.46q25.31 0 43.04 17.73T350-769.23V-710h260v-59.23q0-25.31 17.73-43.04T670.77-830h138.46q25.31 0 43.04 17.73T870-769.23v178.46q0 25.31-17.73 43.04T809.23-530H670.77q-25.31 0-43.04-17.73T610-590.77V-650H510v327.69q0 5.39 3.46 8.85t8.85 3.46H610v-59.23q0-25.31 17.73-43.04T670.77-430h138.46q25.31 0 43.04 17.73T870-369.23v178.46q0 25.31-17.73 43.04T809.23-130H670.77q-25.31 0-43.04-17.73T610-190.77Z",
    }),
  }),
  "IconMaterialSymbolsAccountTreeFill",
);

export default IconMaterialSymbolsAccountTreeFill;
