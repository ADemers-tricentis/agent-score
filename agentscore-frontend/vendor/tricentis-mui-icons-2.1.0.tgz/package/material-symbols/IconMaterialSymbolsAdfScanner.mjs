// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`adf_scanner`, without fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:adf_scanner:FILL@0;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M111.54-233.08v-134.61q0-41.93%2029.04-70.96%2029.04-29.04%2070.96-29.04H260v-254.62q0-25.3%2017.73-43.04%2017.73-17.73%2043.04-17.73h318.46q25.31%200%2043.04%2017.73Q700-747.61%20700-722.31v254.62h48.46q41.92%200%2070.96%2029.04%2029.04%2029.03%2029.04%2070.96v134.61q0%2025.31-17.73%2043.04t-43.04%2017.73H172.31q-25.31%200-43.04-17.73t-17.73-43.04ZM320-467.69h320v-255.39H320v255.39ZM171.54-232.31h616.92v-135.38q0-17-11.5-28.5t-28.5-11.5H211.54q-17%200-28.5%2011.5t-11.5%2028.5v135.38Zm540.77-63.08q17%200%2028.5-11.5t11.5-28.5q0-17-11.5-28.5t-28.5-11.5q-17%200-28.5%2011.5t-11.5%2028.5q0%2017%2011.5%2028.5t28.5%2011.5Zm-540.77-112.3h616.92-616.92Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAdfScanner = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M111.54-233.08v-134.61q0-41.93 29.04-70.96 29.04-29.04 70.96-29.04H260v-254.62q0-25.3 17.73-43.04 17.73-17.73 43.04-17.73h318.46q25.31 0 43.04 17.73Q700-747.61 700-722.31v254.62h48.46q41.92 0 70.96 29.04 29.04 29.03 29.04 70.96v134.61q0 25.31-17.73 43.04t-43.04 17.73H172.31q-25.31 0-43.04-17.73t-17.73-43.04ZM320-467.69h320v-255.39H320v255.39ZM171.54-232.31h616.92v-135.38q0-17-11.5-28.5t-28.5-11.5H211.54q-17 0-28.5 11.5t-11.5 28.5v135.38Zm540.77-63.08q17 0 28.5-11.5t11.5-28.5q0-17-11.5-28.5t-28.5-11.5q-17 0-28.5 11.5t-11.5 28.5q0 17 11.5 28.5t28.5 11.5Zm-540.77-112.3h616.92-616.92Z",
    }),
  }),
  "IconMaterialSymbolsAdfScanner",
);

export default IconMaterialSymbolsAdfScanner;
