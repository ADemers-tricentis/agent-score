// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`adjust`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:adjust:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M550.96-409.04Q580-438.08%20580-480q0-41.92-29.04-70.96Q521.92-580%20480-580q-41.92%200-70.96%2029.04Q380-521.92%20380-480q0%2041.92%2029.04%2070.96Q438.08-380%20480-380q41.92%200%2070.96-29.04ZM480.07-100q-78.84%200-148.21-29.92t-120.68-81.21q-51.31-51.29-81.25-120.63Q100-401.1%20100-479.93q0-78.84%2029.92-148.21t81.21-120.68q51.29-51.31%20120.63-81.25Q401.1-860%20479.93-860q78.84%200%20148.21%2029.92t120.68%2081.21q51.31%2051.29%2081.25%20120.63Q860-558.9%20860-480.07q0%2078.84-29.92%20148.21t-81.21%20120.68q-51.29%2051.31-120.63%2081.25Q558.9-100%20480.07-100Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAdjustFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M550.96-409.04Q580-438.08 580-480q0-41.92-29.04-70.96Q521.92-580 480-580q-41.92 0-70.96 29.04Q380-521.92 380-480q0 41.92 29.04 70.96Q438.08-380 480-380q41.92 0 70.96-29.04ZM480.07-100q-78.84 0-148.21-29.92t-120.68-81.21q-51.31-51.29-81.25-120.63Q100-401.1 100-479.93q0-78.84 29.92-148.21t81.21-120.68q51.29-51.31 120.63-81.25Q401.1-860 479.93-860q78.84 0 148.21 29.92t120.68 81.21q51.31 51.29 81.25 120.63Q860-558.9 860-480.07q0 78.84-29.92 148.21t-81.21 120.68q-51.29 51.31-120.63 81.25Q558.9-100 480.07-100Z",
    }),
  }),
  "IconMaterialSymbolsAdjustFill",
);

export default IconMaterialSymbolsAdjustFill;
