// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`airline_seat_flat`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:airline_seat_flat:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M406.92-420q-15.36%200-25.76-10.4-10.39-10.39-10.39-25.76v-143.07q0-25.31%2017.73-43.04T431.54-660h277.69q57.75%200%2098.87%2041.13%2041.13%2041.12%2041.13%2098.87v63.84q0%2015.37-10.4%2025.76-10.39%2010.4-25.76%2010.4H406.92Zm412.31%20115.38H140.77q-12.75%200-21.37-8.63-8.63-8.62-8.63-21.38T119.4-356q8.62-8.62%2021.37-8.62h678.46q12.75%200%2021.37%208.63%208.63%208.63%208.63%2021.39%200%2012.75-8.63%2021.37-8.62%208.61-21.37%208.61Zm-678.84-145q-29.62-29.61-29.62-72.69%200-43.07%2029.62-72.69%2029.61-29.61%2072.69-29.61%2043.07%200%2072.69%2029.61%2029.61%2029.62%2029.61%2072.69%200%2043.08-29.61%2072.69Q256.15-420%20213.08-420q-43.08%200-72.69-29.62Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAirlineSeatFlatFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M406.92-420q-15.36 0-25.76-10.4-10.39-10.39-10.39-25.76v-143.07q0-25.31 17.73-43.04T431.54-660h277.69q57.75 0 98.87 41.13 41.13 41.12 41.13 98.87v63.84q0 15.37-10.4 25.76-10.39 10.4-25.76 10.4H406.92Zm412.31 115.38H140.77q-12.75 0-21.37-8.63-8.63-8.62-8.63-21.38T119.4-356q8.62-8.62 21.37-8.62h678.46q12.75 0 21.37 8.63 8.63 8.63 8.63 21.39 0 12.75-8.63 21.37-8.62 8.61-21.37 8.61Zm-678.84-145q-29.62-29.61-29.62-72.69 0-43.07 29.62-72.69 29.61-29.61 72.69-29.61 43.07 0 72.69 29.61 29.61 29.62 29.61 72.69 0 43.08-29.61 72.69Q256.15-420 213.08-420q-43.08 0-72.69-29.62Z",
    }),
  }),
  "IconMaterialSymbolsAirlineSeatFlatFill",
);

export default IconMaterialSymbolsAirlineSeatFlatFill;
