// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_justify_space_between`, without fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_justify_space_between:FILL@0;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M808.62-108.63Q800-117.25%20800-130v-160h-63.84q-15.37%200-25.76-10.39-10.4-10.4-10.4-25.76v-307.7q0-15.36%2010.4-25.76Q720.79-670%20736.16-670H800v-160q0-12.75%208.63-21.37%208.63-8.63%2021.38-8.63%2012.76%200%2021.37%208.63Q860-842.75%20860-830v700q0%2012.75-8.63%2021.37-8.63%208.63-21.38%208.63-12.76%200-21.37-8.63ZM129.99-100q-12.76%200-21.37-8.63Q100-117.25%20100-130v-700q0-12.75%208.63-21.37%208.63-8.63%2021.38-8.63%2012.76%200%2021.37%208.63Q160-842.75%20160-830v160h63.84q15.37%200%2025.76%2010.39%2010.4%2010.4%2010.4%2025.76v307.7q0%2015.36-10.4%2025.76Q239.21-290%20223.84-290H160v160q0%2012.75-8.63%2021.37-8.63%208.63-21.38%208.63Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignJustifySpaceBetween = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M808.62-108.63Q800-117.25 800-130v-160h-63.84q-15.37 0-25.76-10.39-10.4-10.4-10.4-25.76v-307.7q0-15.36 10.4-25.76Q720.79-670 736.16-670H800v-160q0-12.75 8.63-21.37 8.63-8.63 21.38-8.63 12.76 0 21.37 8.63Q860-842.75 860-830v700q0 12.75-8.63 21.37-8.63 8.63-21.38 8.63-12.76 0-21.37-8.63ZM129.99-100q-12.76 0-21.37-8.63Q100-117.25 100-130v-700q0-12.75 8.63-21.37 8.63-8.63 21.38-8.63 12.76 0 21.37 8.63Q160-842.75 160-830v160h63.84q15.37 0 25.76 10.39 10.4 10.4 10.4 25.76v307.7q0 15.36-10.4 25.76Q239.21-290 223.84-290H160v160q0 12.75-8.63 21.37-8.63 8.63-21.38 8.63Z",
    }),
  }),
  "IconMaterialSymbolsAlignJustifySpaceBetween",
);

export default IconMaterialSymbolsAlignJustifySpaceBetween;
