// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`ad`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:ad:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M212.31-140Q182-140%20161-161q-21-21-21-51.31v-535.38Q140-778%20161-799q21-21%2051.31-21h535.38Q778-820%20799-799q21%2021%2021%2051.31v535.38Q820-182%20799-161q-21%2021-51.31%2021H212.31Zm0-60h535.38q4.62%200%208.46-3.85%203.85-3.84%203.85-8.46v-424.61H200v424.61q0%204.62%203.85%208.46%203.84%203.85%208.46%203.85Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAdFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M212.31-140Q182-140 161-161q-21-21-21-51.31v-535.38Q140-778 161-799q21-21 51.31-21h535.38Q778-820 799-799q21 21 21 51.31v535.38Q820-182 799-161q-21 21-51.31 21H212.31Zm0-60h535.38q4.62 0 8.46-3.85 3.85-3.84 3.85-8.46v-424.61H200v424.61q0 4.62 3.85 8.46 3.84 3.85 8.46 3.85Z",
    }),
  }),
  "IconMaterialSymbolsAdFill",
);

export default IconMaterialSymbolsAdFill;
