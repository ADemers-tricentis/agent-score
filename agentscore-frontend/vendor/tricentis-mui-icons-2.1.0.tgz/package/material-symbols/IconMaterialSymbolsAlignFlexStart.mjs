// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_flex_start`, without fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_flex_start:FILL@0;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M130-800q-12.75%200-21.37-8.63-8.63-8.63-8.63-21.38%200-12.76%208.63-21.37Q117.25-860%20130-860h700q12.75%200%2021.37%208.63%208.63%208.63%208.63%2021.38%200%2012.76-8.63%2021.37Q842.75-800%20830-800H130Zm336.15%20640q-15.36%200-25.76-10.39Q430-180.79%20430-196.15v-467.69q0-15.37%2010.39-25.76%2010.4-10.4%2025.76-10.4h27.7q15.36%200%2025.76%2010.4Q530-679.21%20530-663.84v467.69q0%2015.36-10.39%2025.76Q509.21-160%20493.85-160h-27.7Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignFlexStart = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M130-800q-12.75 0-21.37-8.63-8.63-8.63-8.63-21.38 0-12.76 8.63-21.37Q117.25-860 130-860h700q12.75 0 21.37 8.63 8.63 8.63 8.63 21.38 0 12.76-8.63 21.37Q842.75-800 830-800H130Zm336.15 640q-15.36 0-25.76-10.39Q430-180.79 430-196.15v-467.69q0-15.37 10.39-25.76 10.4-10.4 25.76-10.4h27.7q15.36 0 25.76 10.4Q530-679.21 530-663.84v467.69q0 15.36-10.39 25.76Q509.21-160 493.85-160h-27.7Z",
    }),
  }),
  "IconMaterialSymbolsAlignFlexStart",
);

export default IconMaterialSymbolsAlignFlexStart;
