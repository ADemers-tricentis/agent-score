// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`agender`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:agender:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M480-140q-91.54%200-155.77-64.23T260-360q0-84.23%2054.81-145.73%2054.81-61.5%20135.19-72.04V-770q0-12.77%208.62-21.38Q467.23-800%20480-800t21.38%208.62Q510-782.77%20510-770v192.23q81.38%2010.54%20135.69%2072.04Q700-444.23%20700-360q0%2091.54-64.23%20155.77T480-140Zm0-60q58.69%200%20102.35-37.08Q626-274.15%20636.54-330H323.46q10.54%2055.85%2054.19%2092.92Q421.31-200%20480-200ZM323.46-390h313.08q-10.54-55.85-54.19-92.92Q538.69-520%20480-520t-102.35%2037.08Q334-445.85%20323.46-390Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAgenderFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M480-140q-91.54 0-155.77-64.23T260-360q0-84.23 54.81-145.73 54.81-61.5 135.19-72.04V-770q0-12.77 8.62-21.38Q467.23-800 480-800t21.38 8.62Q510-782.77 510-770v192.23q81.38 10.54 135.69 72.04Q700-444.23 700-360q0 91.54-64.23 155.77T480-140Zm0-60q58.69 0 102.35-37.08Q626-274.15 636.54-330H323.46q10.54 55.85 54.19 92.92Q421.31-200 480-200ZM323.46-390h313.08q-10.54-55.85-54.19-92.92Q538.69-520 480-520t-102.35 37.08Q334-445.85 323.46-390Z",
    }),
  }),
  "IconMaterialSymbolsAgenderFill",
);

export default IconMaterialSymbolsAgenderFill;
