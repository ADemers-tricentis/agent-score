// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`airline_seat_individual_suite`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:airline_seat_individual_suite:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M120.77-300q-25.31%200-43.04-17.73T60-360.77V-630q0-12.77%208.62-21.38Q77.23-660%2090-660t21.38%208.62Q120-642.77%20120-630v270h330v-239.23q0-25.31%2017.73-43.04T510.77-660H760q57.92%200%2098.96%2041.04Q900-577.92%20900-520v159.23q0%2025.31-17.73%2043.04T839.23-300H120.77ZM352.5-447.5q29.81-29.81%2029.81-72.5t-29.81-72.5q-29.81-29.81-72.5-29.81t-72.5%2029.81q-29.81%2029.81-29.81%2072.5t29.81%2072.5q29.81%2029.81%2072.5%2029.81t72.5-29.81Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAirlineSeatIndividualSuiteFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M120.77-300q-25.31 0-43.04-17.73T60-360.77V-630q0-12.77 8.62-21.38Q77.23-660 90-660t21.38 8.62Q120-642.77 120-630v270h330v-239.23q0-25.31 17.73-43.04T510.77-660H760q57.92 0 98.96 41.04Q900-577.92 900-520v159.23q0 25.31-17.73 43.04T839.23-300H120.77ZM352.5-447.5q29.81-29.81 29.81-72.5t-29.81-72.5q-29.81-29.81-72.5-29.81t-72.5 29.81q-29.81 29.81-29.81 72.5t29.81 72.5q29.81 29.81 72.5 29.81t72.5-29.81Z",
    }),
  }),
  "IconMaterialSymbolsAirlineSeatIndividualSuiteFill",
);

export default IconMaterialSymbolsAirlineSeatIndividualSuiteFill;
