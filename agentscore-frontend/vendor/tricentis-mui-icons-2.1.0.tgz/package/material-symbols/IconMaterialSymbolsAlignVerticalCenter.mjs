// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_vertical_center`, without fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_vertical_center:FILL@0;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M306.73-154.81q-14.81-14.81-14.81-35.58V-450H130q-12.77%200-21.38-8.62Q100-467.23%20100-480t8.62-21.38Q117.23-510%20130-510h161.92v-259.61q0-20.77%2014.81-35.58Q321.54-820%20342.31-820q20.77%200%2035.57%2014.81%2014.81%2014.81%2014.81%2035.58V-510h174.62v-139.61q0-20.77%2014.81-35.58Q596.92-700%20617.69-700t35.58%2014.81q14.81%2014.81%2014.81%2035.58V-510H830q12.77%200%2021.38%208.62Q860-492.77%20860-480t-8.62%2021.38Q842.77-450%20830-450H668.08v139.61q0%2020.77-14.81%2035.58Q638.46-260%20617.69-260q-20.77%200-35.57-14.81-14.81-14.81-14.81-35.58V-450H392.69v259.61q0%2020.77-14.81%2035.58Q363.08-140%20342.31-140t-35.58-14.81Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignVerticalCenter = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M306.73-154.81q-14.81-14.81-14.81-35.58V-450H130q-12.77 0-21.38-8.62Q100-467.23 100-480t8.62-21.38Q117.23-510 130-510h161.92v-259.61q0-20.77 14.81-35.58Q321.54-820 342.31-820q20.77 0 35.57 14.81 14.81 14.81 14.81 35.58V-510h174.62v-139.61q0-20.77 14.81-35.58Q596.92-700 617.69-700t35.58 14.81q14.81 14.81 14.81 35.58V-510H830q12.77 0 21.38 8.62Q860-492.77 860-480t-8.62 21.38Q842.77-450 830-450H668.08v139.61q0 20.77-14.81 35.58Q638.46-260 617.69-260q-20.77 0-35.57-14.81-14.81-14.81-14.81-35.58V-450H392.69v259.61q0 20.77-14.81 35.58Q363.08-140 342.31-140t-35.58-14.81Z",
    }),
  }),
  "IconMaterialSymbolsAlignVerticalCenter",
);

export default IconMaterialSymbolsAlignVerticalCenter;
