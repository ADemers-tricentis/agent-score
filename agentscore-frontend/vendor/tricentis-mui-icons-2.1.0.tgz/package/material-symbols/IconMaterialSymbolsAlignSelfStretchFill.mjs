// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_self_stretch`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_self_stretch:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M130-100q-12.75%200-21.37-8.63-8.63-8.63-8.63-21.38%200-12.76%208.63-21.37Q117.25-160%20130-160h700q12.75%200%2021.37%208.63%208.63%208.63%208.63%2021.38%200%2012.76-8.63%2021.37Q842.75-100%20830-100H130Zm336.15-180q-15.36%200-25.76-10.4Q430-300.79%20430-316.16v-347.6q0-15.55%2010.39-25.89Q450.79-700%20466.15-700h27.7q15.36%200%2025.76%2010.4Q530-679.21%20530-663.84v347.6q0%2015.55-10.39%2025.89Q509.21-280%20493.85-280h-27.7ZM130-800q-12.75%200-21.37-8.63-8.63-8.63-8.63-21.38%200-12.76%208.63-21.37Q117.25-860%20130-860h700q12.75%200%2021.37%208.63%208.63%208.63%208.63%2021.38%200%2012.76-8.63%2021.37Q842.75-800%20830-800H130Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignSelfStretchFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M130-100q-12.75 0-21.37-8.63-8.63-8.63-8.63-21.38 0-12.76 8.63-21.37Q117.25-160 130-160h700q12.75 0 21.37 8.63 8.63 8.63 8.63 21.38 0 12.76-8.63 21.37Q842.75-100 830-100H130Zm336.15-180q-15.36 0-25.76-10.4Q430-300.79 430-316.16v-347.6q0-15.55 10.39-25.89Q450.79-700 466.15-700h27.7q15.36 0 25.76 10.4Q530-679.21 530-663.84v347.6q0 15.55-10.39 25.89Q509.21-280 493.85-280h-27.7ZM130-800q-12.75 0-21.37-8.63-8.63-8.63-8.63-21.38 0-12.76 8.63-21.37Q117.25-860 130-860h700q12.75 0 21.37 8.63 8.63 8.63 8.63 21.38 0 12.76-8.63 21.37Q842.75-800 830-800H130Z",
    }),
  }),
  "IconMaterialSymbolsAlignSelfStretchFill",
);

export default IconMaterialSymbolsAlignSelfStretchFill;
