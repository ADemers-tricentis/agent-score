// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_start`, without fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_start:FILL@0;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M130-800q-12.75%200-21.37-8.63-8.63-8.63-8.63-21.38%200-12.76%208.63-21.37Q117.25-860%20130-860h700q12.75%200%2021.37%208.63%208.63%208.63%208.63%2021.38%200%2012.76-8.63%2021.37Q842.75-800%20830-800H130Zm196.15%20230q-15.36%200-25.76-10.39Q290-590.79%20290-606.15v-27.7q0-15.36%2010.39-25.76Q310.79-670%20326.15-670h307.7q15.36%200%2025.76%2010.39Q670-649.21%20670-633.85v27.7q0%2015.36-10.39%2025.76Q649.21-570%20633.85-570h-307.7Zm0%20240q-15.36%200-25.76-10.39Q290-350.79%20290-366.15v-27.7q0-15.36%2010.39-25.76Q310.79-430%20326.15-430h307.7q15.36%200%2025.76%2010.39Q670-409.21%20670-393.85v27.7q0%2015.36-10.39%2025.76Q649.21-330%20633.85-330h-307.7Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignStart = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M130-800q-12.75 0-21.37-8.63-8.63-8.63-8.63-21.38 0-12.76 8.63-21.37Q117.25-860 130-860h700q12.75 0 21.37 8.63 8.63 8.63 8.63 21.38 0 12.76-8.63 21.37Q842.75-800 830-800H130Zm196.15 230q-15.36 0-25.76-10.39Q290-590.79 290-606.15v-27.7q0-15.36 10.39-25.76Q310.79-670 326.15-670h307.7q15.36 0 25.76 10.39Q670-649.21 670-633.85v27.7q0 15.36-10.39 25.76Q649.21-570 633.85-570h-307.7Zm0 240q-15.36 0-25.76-10.39Q290-350.79 290-366.15v-27.7q0-15.36 10.39-25.76Q310.79-430 326.15-430h307.7q15.36 0 25.76 10.39Q670-409.21 670-393.85v27.7q0 15.36-10.39 25.76Q649.21-330 633.85-330h-307.7Z",
    }),
  }),
  "IconMaterialSymbolsAlignStart",
);

export default IconMaterialSymbolsAlignStart;
