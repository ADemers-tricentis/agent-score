// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`add_card`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:add_card:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M770-210h-90q-12.75%200-21.37-8.63-8.63-8.63-8.63-21.38%200-12.76%208.63-21.37Q667.25-270%20680-270h90v-90q0-12.75%208.63-21.37%208.63-8.63%2021.38-8.63%2012.76%200%2021.37%208.63Q830-372.75%20830-360v90h90q12.75%200%2021.37%208.63%208.63%208.63%208.63%2021.38%200%2012.76-8.63%2021.37Q932.75-210%20920-210h-90v90q0%2012.75-8.63%2021.37Q812.74-90%20799.99-90q-12.76%200-21.37-8.63Q770-107.25%20770-120v-90ZM160-496.16h640v-127.68H160v127.68ZM172.31-180Q142-180%20121-201q-21-21-21-51.31v-455.38Q100-738%20121-759q21-21%2051.31-21h615.38Q818-780%20839-759q21%2021%2021%2051.31v201.54q0%2015.36-10.4%2025.76Q839.21-470%20823.84-470H770q-83%200-141.5%2058.5T570-270v53.84q0%2015.37-10.39%2025.76-10.4%2010.4-25.76%2010.4H172.31Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAddCardFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M770-210h-90q-12.75 0-21.37-8.63-8.63-8.63-8.63-21.38 0-12.76 8.63-21.37Q667.25-270 680-270h90v-90q0-12.75 8.63-21.37 8.63-8.63 21.38-8.63 12.76 0 21.37 8.63Q830-372.75 830-360v90h90q12.75 0 21.37 8.63 8.63 8.63 8.63 21.38 0 12.76-8.63 21.37Q932.75-210 920-210h-90v90q0 12.75-8.63 21.37Q812.74-90 799.99-90q-12.76 0-21.37-8.63Q770-107.25 770-120v-90ZM160-496.16h640v-127.68H160v127.68ZM172.31-180Q142-180 121-201q-21-21-21-51.31v-455.38Q100-738 121-759q21-21 51.31-21h615.38Q818-780 839-759q21 21 21 51.31v201.54q0 15.36-10.4 25.76Q839.21-470 823.84-470H770q-83 0-141.5 58.5T570-270v53.84q0 15.37-10.39 25.76-10.4 10.4-25.76 10.4H172.31Z",
    }),
  }),
  "IconMaterialSymbolsAddCardFill",
);

export default IconMaterialSymbolsAddCardFill;
