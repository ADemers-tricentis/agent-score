// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_vertical_bottom`, without fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_vertical_bottom:FILL@0;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M130-110q-12.77%200-21.38-8.62Q100-127.23%20100-140t8.62-21.39Q117.23-170%20130-170h700q12.77%200%2021.38%208.61Q860-152.77%20860-140q0%2012.77-8.62%2021.38Q842.77-110%20830-110H130Zm178.65-166.35q-14.8-14.81-14.8-35.57V-800q0-20.77%2014.8-35.57%2014.81-14.81%2035.58-14.81%2020.77%200%2035.58%2014.81%2014.8%2014.8%2014.8%2035.57v488.08q0%2020.76-14.8%2035.57-14.81%2014.81-35.58%2014.81-20.77%200-35.58-14.81Zm271.54%200q-14.8-14.81-14.8-35.57V-560q0-20.77%2014.8-35.57%2014.81-14.81%2035.58-14.81%2020.77%200%2035.58%2014.81%2014.8%2014.8%2014.8%2035.57v248.08q0%2020.76-14.8%2035.57-14.81%2014.81-35.58%2014.81-20.77%200-35.58-14.81Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignVerticalBottom = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M130-110q-12.77 0-21.38-8.62Q100-127.23 100-140t8.62-21.39Q117.23-170 130-170h700q12.77 0 21.38 8.61Q860-152.77 860-140q0 12.77-8.62 21.38Q842.77-110 830-110H130Zm178.65-166.35q-14.8-14.81-14.8-35.57V-800q0-20.77 14.8-35.57 14.81-14.81 35.58-14.81 20.77 0 35.58 14.81 14.8 14.8 14.8 35.57v488.08q0 20.76-14.8 35.57-14.81 14.81-35.58 14.81-20.77 0-35.58-14.81Zm271.54 0q-14.8-14.81-14.8-35.57V-560q0-20.77 14.8-35.57 14.81-14.81 35.58-14.81 20.77 0 35.58 14.81 14.8 14.8 14.8 35.57v248.08q0 20.76-14.8 35.57-14.81 14.81-35.58 14.81-20.77 0-35.58-14.81Z",
    }),
  }),
  "IconMaterialSymbolsAlignVerticalBottom",
);

export default IconMaterialSymbolsAlignVerticalBottom;
