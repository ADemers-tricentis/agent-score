// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`airline_seat_legroom_normal`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:airline_seat_legroom_normal:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M638.85-390h-320q-29.16%200-49.58-20.42-20.42-20.42-20.42-49.58v-333.85q0-15.36%2010.34-25.76%2010.35-10.39%2026-10.39H432.5q15.65%200%2026%2010.39%2010.35%2010.4%2010.35%2025.76V-570h196.92q29.15%200%2049.57%2020.43%2020.43%2020.42%2020.43%2049.57v274.62h66.15q21.77%200%2035.5%2013.27%2013.73%2013.28%2013.73%2033.58%200%2020.3-13.73%2033.64-13.73%2013.35-35.5%2013.35H668.85q-12.75%200-21.38-8.62-8.62-8.63-8.62-21.38V-390ZM527.31-290H221.16q-30.31%200-51.31-21-21-21-21-51.31V-800q0-12.75%208.63-21.37%208.63-8.63%2021.38-8.63%2012.76%200%2021.37%208.63%208.62%208.62%208.62%2021.37v437.69q0%204.62%203.84%208.46%203.85%203.85%208.47%203.85h306.15q12.75%200%2021.37%208.63%208.63%208.63%208.63%2021.38%200%2012.76-8.63%2021.37-8.62%208.62-21.37%208.62Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAirlineSeatLegroomNormalFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M638.85-390h-320q-29.16 0-49.58-20.42-20.42-20.42-20.42-49.58v-333.85q0-15.36 10.34-25.76 10.35-10.39 26-10.39H432.5q15.65 0 26 10.39 10.35 10.4 10.35 25.76V-570h196.92q29.15 0 49.57 20.43 20.43 20.42 20.43 49.57v274.62h66.15q21.77 0 35.5 13.27 13.73 13.28 13.73 33.58 0 20.3-13.73 33.64-13.73 13.35-35.5 13.35H668.85q-12.75 0-21.38-8.62-8.62-8.63-8.62-21.38V-390ZM527.31-290H221.16q-30.31 0-51.31-21-21-21-21-51.31V-800q0-12.75 8.63-21.37 8.63-8.63 21.38-8.63 12.76 0 21.37 8.63 8.62 8.62 8.62 21.37v437.69q0 4.62 3.84 8.46 3.85 3.85 8.47 3.85h306.15q12.75 0 21.37 8.63 8.63 8.63 8.63 21.38 0 12.76-8.63 21.37-8.62 8.62-21.37 8.62Z",
    }),
  }),
  "IconMaterialSymbolsAirlineSeatLegroomNormalFill",
);

export default IconMaterialSymbolsAirlineSeatLegroomNormalFill;
