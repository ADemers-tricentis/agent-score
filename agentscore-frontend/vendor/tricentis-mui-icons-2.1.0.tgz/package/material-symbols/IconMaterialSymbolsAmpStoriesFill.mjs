// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`amp_stories`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:amp_stories:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M335.99-180q-15.3%200-25.64-10.4Q300-200.79%20300-216.16v-527.68q0-15.37%2010.35-25.76Q320.7-780%20336-780h288.01q15.3%200%2025.64%2010.4Q660-759.21%20660-743.84v527.68q0%2015.37-10.35%2025.76Q639.3-180%20624-180H335.99ZM152.31-290v-381q0-12.38%208.63-20.69t21.38-8.31q12.76%200%2021.37%208.63%208.62%208.62%208.62%2021.37v381q0%2012.38-8.63%2020.69T182.3-260q-12.76%200-21.37-8.63-8.62-8.62-8.62-21.37Zm595.38%200v-381q0-12.38%208.63-20.69T777.7-700q12.76%200%2021.37%208.63%208.62%208.62%208.62%2021.37v381q0%2012.38-8.63%2020.69T777.68-260q-12.76%200-21.37-8.63-8.62-8.62-8.62-21.37Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAmpStoriesFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M335.99-180q-15.3 0-25.64-10.4Q300-200.79 300-216.16v-527.68q0-15.37 10.35-25.76Q320.7-780 336-780h288.01q15.3 0 25.64 10.4Q660-759.21 660-743.84v527.68q0 15.37-10.35 25.76Q639.3-180 624-180H335.99ZM152.31-290v-381q0-12.38 8.63-20.69t21.38-8.31q12.76 0 21.37 8.63 8.62 8.62 8.62 21.37v381q0 12.38-8.63 20.69T182.3-260q-12.76 0-21.37-8.63-8.62-8.62-8.62-21.37Zm595.38 0v-381q0-12.38 8.63-20.69T777.7-700q12.76 0 21.37 8.63 8.62 8.62 8.62 21.37v381q0 12.38-8.63 20.69T777.68-260q-12.76 0-21.37-8.63-8.62-8.62-8.62-21.37Z",
    }),
  }),
  "IconMaterialSymbolsAmpStoriesFill",
);

export default IconMaterialSymbolsAmpStoriesFill;
