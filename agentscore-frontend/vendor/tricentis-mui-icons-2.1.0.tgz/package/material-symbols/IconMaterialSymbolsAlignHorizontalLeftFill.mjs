// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_horizontal_left`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_horizontal_left:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M145.39-100q-12.77%200-21.39-8.62-8.61-8.61-8.61-21.38v-700q0-12.77%208.61-21.38%208.62-8.62%2021.39-8.62%2012.77%200%2021.38%208.62%208.62%208.61%208.62%2021.38v700q0%2012.77-8.62%2021.38-8.61%208.62-21.38%208.62Zm171.92-193.85q-20.77%200-35.58-14.8-14.8-14.81-14.8-35.58%200-20.77%2014.8-35.58%2014.81-14.8%2035.58-14.8h236.92q20.77%200%2035.58%2014.8%2014.8%2014.81%2014.8%2035.58%200%2020.77-14.8%2035.58-14.81%2014.8-35.58%2014.8H317.31Zm0-271.54q-20.77%200-35.58-14.8-14.8-14.81-14.8-35.58%200-20.77%2014.8-35.58%2014.81-14.8%2035.58-14.8h476.92q20.77%200%2035.58%2014.8%2014.8%2014.81%2014.8%2035.58%200%2020.77-14.8%2035.58-14.81%2014.8-35.58%2014.8H317.31Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignHorizontalLeftFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M145.39-100q-12.77 0-21.39-8.62-8.61-8.61-8.61-21.38v-700q0-12.77 8.61-21.38 8.62-8.62 21.39-8.62 12.77 0 21.38 8.62 8.62 8.61 8.62 21.38v700q0 12.77-8.62 21.38-8.61 8.62-21.38 8.62Zm171.92-193.85q-20.77 0-35.58-14.8-14.8-14.81-14.8-35.58 0-20.77 14.8-35.58 14.81-14.8 35.58-14.8h236.92q20.77 0 35.58 14.8 14.8 14.81 14.8 35.58 0 20.77-14.8 35.58-14.81 14.8-35.58 14.8H317.31Zm0-271.54q-20.77 0-35.58-14.8-14.8-14.81-14.8-35.58 0-20.77 14.8-35.58 14.81-14.8 35.58-14.8h476.92q20.77 0 35.58 14.8 14.8 14.81 14.8 35.58 0 20.77-14.8 35.58-14.81 14.8-35.58 14.8H317.31Z",
    }),
  }),
  "IconMaterialSymbolsAlignHorizontalLeftFill",
);

export default IconMaterialSymbolsAlignHorizontalLeftFill;
