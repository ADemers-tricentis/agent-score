// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`3p`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:3p:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M333.85-417.69h292.3V-432q0-37.85-40.73-61.77T480-517.69q-64.69%200-105.42%2023.92-40.73%2023.92-40.73%2061.77v14.31Zm195.73-172.73Q550-610.85%20550-640t-20.42-49.58Q509.15-710%20480-710t-49.58%2020.42Q410-669.15%20410-640t20.42%2049.58Q450.85-570%20480-570t49.58-20.42ZM241.54-260l-80.08%2080.07q-17.07%2017.08-39.27%207.74Q100-181.54%20100-205.85v-581.84Q100-818%20121-839q21-21%2051.31-21h615.38Q818-860%20839-839q21%2021%2021%2051.31v455.38Q860-302%20839-281q-21%2021-51.31%2021H241.54Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbols3pFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M333.85-417.69h292.3V-432q0-37.85-40.73-61.77T480-517.69q-64.69 0-105.42 23.92-40.73 23.92-40.73 61.77v14.31Zm195.73-172.73Q550-610.85 550-640t-20.42-49.58Q509.15-710 480-710t-49.58 20.42Q410-669.15 410-640t20.42 49.58Q450.85-570 480-570t49.58-20.42ZM241.54-260l-80.08 80.07q-17.07 17.08-39.27 7.74Q100-181.54 100-205.85v-581.84Q100-818 121-839q21-21 51.31-21h615.38Q818-860 839-839q21 21 21 51.31v455.38Q860-302 839-281q-21 21-51.31 21H241.54Z",
    }),
  }),
  "IconMaterialSymbols3pFill",
);

export default IconMaterialSymbols3pFill;
