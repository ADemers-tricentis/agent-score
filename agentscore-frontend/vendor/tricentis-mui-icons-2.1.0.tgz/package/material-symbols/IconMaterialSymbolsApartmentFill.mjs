// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`apartment`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:apartment:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M190.77-136.92q-25.31%200-43.04-17.73Q130-172.39%20130-197.69v-418.47q0-25.3%2017.73-43.03t43.04-17.73H290v-99.24q0-25.3%2017.73-43.03t43.04-17.73h258.46q25.31%200%2043.04%2017.73T670-776.16v259.24h99.23q25.31%200%2043.04%2017.73T830-456.16v258.47q0%2025.3-17.73%2043.04-17.73%2017.73-43.04%2017.73H530v-160H430v160H190.77Zm-.77-60h100v-100H190v100Zm0-160h100v-100H190v100Zm0-160h100v-100H190v100Zm160%20160h100v-100H350v100Zm0-160h100v-100H350v100Zm0-160h100v-100H350v100Zm160%20320h100v-100H510v100Zm0-160h100v-100H510v100Zm0-160h100v-100H510v100Zm160%20480h100v-100H670v100Zm0-160h100v-100H670v100Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsApartmentFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M190.77-136.92q-25.31 0-43.04-17.73Q130-172.39 130-197.69v-418.47q0-25.3 17.73-43.03t43.04-17.73H290v-99.24q0-25.3 17.73-43.03t43.04-17.73h258.46q25.31 0 43.04 17.73T670-776.16v259.24h99.23q25.31 0 43.04 17.73T830-456.16v258.47q0 25.3-17.73 43.04-17.73 17.73-43.04 17.73H530v-160H430v160H190.77Zm-.77-60h100v-100H190v100Zm0-160h100v-100H190v100Zm0-160h100v-100H190v100Zm160 160h100v-100H350v100Zm0-160h100v-100H350v100Zm0-160h100v-100H350v100Zm160 320h100v-100H510v100Zm0-160h100v-100H510v100Zm0-160h100v-100H510v100Zm160 480h100v-100H670v100Zm0-160h100v-100H670v100Z",
    }),
  }),
  "IconMaterialSymbolsApartmentFill",
);

export default IconMaterialSymbolsApartmentFill;
