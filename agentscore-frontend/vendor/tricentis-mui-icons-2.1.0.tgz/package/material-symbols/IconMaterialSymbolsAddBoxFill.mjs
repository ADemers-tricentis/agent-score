// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`add_box`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:add_box:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M450-450v130q0%2012.75%208.63%2021.37%208.63%208.63%2021.38%208.63%2012.76%200%2021.37-8.63Q510-307.25%20510-320v-130h130q12.75%200%2021.37-8.63%208.63-8.63%208.63-21.38%200-12.76-8.63-21.37Q652.75-510%20640-510H510v-130q0-12.75-8.63-21.37-8.63-8.63-21.38-8.63-12.76%200-21.37%208.63Q450-652.75%20450-640v130H320q-12.75%200-21.37%208.63-8.63%208.63-8.63%2021.38%200%2012.76%208.63%2021.37Q307.25-450%20320-450h130ZM212.31-140Q182-140%20161-161q-21-21-21-51.31v-535.38Q140-778%20161-799q21-21%2051.31-21h535.38Q778-820%20799-799q21%2021%2021%2051.31v535.38Q820-182%20799-161q-21%2021-51.31%2021H212.31Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAddBoxFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M450-450v130q0 12.75 8.63 21.37 8.63 8.63 21.38 8.63 12.76 0 21.37-8.63Q510-307.25 510-320v-130h130q12.75 0 21.37-8.63 8.63-8.63 8.63-21.38 0-12.76-8.63-21.37Q652.75-510 640-510H510v-130q0-12.75-8.63-21.37-8.63-8.63-21.38-8.63-12.76 0-21.37 8.63Q450-652.75 450-640v130H320q-12.75 0-21.37 8.63-8.63 8.63-8.63 21.38 0 12.76 8.63 21.37Q307.25-450 320-450h130ZM212.31-140Q182-140 161-161q-21-21-21-51.31v-535.38Q140-778 161-799q21-21 51.31-21h535.38Q778-820 799-799q21 21 21 51.31v535.38Q820-182 799-161q-21 21-51.31 21H212.31Z",
    }),
  }),
  "IconMaterialSymbolsAddBoxFill",
);

export default IconMaterialSymbolsAddBoxFill;
