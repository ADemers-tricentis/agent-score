// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`admin_meds`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:admin_meds:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M335.31-335.92q25.92%2025.92%2061.38%2026.23%2035.46.3%2061.39-25.62l62.54-62.54-122.77-122.77-62.54%2062.54q-25.54%2025.54-25.54%2061.08t25.54%2061.08Zm289.38-288.16q-25.92-24.92-61.38-25.73-35.46-.8-61.39%2025.12L440-562.77%20562.77-440l61.92-61.92q25.92-25.93%2025.42-61.08t-25.42-61.08ZM212.31-140q-29.92%200-51.12-21.19Q140-182.39%20140-212.31v-535.38q0-29.92%2021.19-51.12Q182.39-820%20212.31-820h178q3.77-33.31%2029.08-56.65Q444.69-900%20480-900q35.69%200%2061%2023.35%2025.31%2023.34%2028.69%2056.65h178q29.92%200%2051.12%2021.19Q820-777.61%20820-747.69v535.38q0%2029.92-21.19%2051.12Q777.61-140%20747.69-140H212.31ZM501.5-794.65q8.5-8.5%208.5-21.5t-8.5-21.5q-8.5-8.5-21.5-8.5t-21.5%208.5q-8.5%208.5-8.5%2021.5t8.5%2021.5q8.5%208.5%2021.5%208.5t21.5-8.5Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAdminMedsFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M335.31-335.92q25.92 25.92 61.38 26.23 35.46.3 61.39-25.62l62.54-62.54-122.77-122.77-62.54 62.54q-25.54 25.54-25.54 61.08t25.54 61.08Zm289.38-288.16q-25.92-24.92-61.38-25.73-35.46-.8-61.39 25.12L440-562.77 562.77-440l61.92-61.92q25.92-25.93 25.42-61.08t-25.42-61.08ZM212.31-140q-29.92 0-51.12-21.19Q140-182.39 140-212.31v-535.38q0-29.92 21.19-51.12Q182.39-820 212.31-820h178q3.77-33.31 29.08-56.65Q444.69-900 480-900q35.69 0 61 23.35 25.31 23.34 28.69 56.65h178q29.92 0 51.12 21.19Q820-777.61 820-747.69v535.38q0 29.92-21.19 51.12Q777.61-140 747.69-140H212.31ZM501.5-794.65q8.5-8.5 8.5-21.5t-8.5-21.5q-8.5-8.5-21.5-8.5t-21.5 8.5q-8.5 8.5-8.5 21.5t8.5 21.5q8.5 8.5 21.5 8.5t21.5-8.5Z",
    }),
  }),
  "IconMaterialSymbolsAdminMedsFill",
);

export default IconMaterialSymbolsAdminMedsFill;
