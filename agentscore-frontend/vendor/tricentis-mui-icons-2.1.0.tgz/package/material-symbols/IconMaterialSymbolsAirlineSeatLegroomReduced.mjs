// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`airline_seat_legroom_reduced`, without fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:airline_seat_legroom_reduced:FILL@0;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M610-135.39q-25.85%200-43.35-21.76-17.5-21.77-10.65-46.62L608.46-390H305.38q-29.15%200-49.57-20.42-20.43-20.42-20.43-49.58v-333.85q0-15.46%2010.35-25.8Q256.08-830%20271.54-830h147.69q15.46%200%2025.81%2010.35%2010.34%2010.34%2010.34%2025.8V-570h213.16q36.54%200%2058.23%2029.31%2021.69%2029.31%2011.07%2063.85l-75.53%20247.61h63.38q22%200%2036.23%2012.46%2014.23%2012.46%2014.23%2034.46t-13.23%2034.46q-13.23%2012.46-35.23%2012.46H610ZM207.69-290q-30.3%200-51.3-21-21-21-21-51.31V-800q0-12.77%208.61-21.38%208.62-8.62%2021.39-8.62%2012.76%200%2021.38%208.62%208.61%208.61%208.61%2021.38v437.69q0%204.62%203.85%208.46%203.85%203.85%208.46%203.85h237.7q12.76%200%2021.38%208.62%208.61%208.61%208.61%2021.38t-8.61%2021.38q-8.62%208.62-21.38%208.62h-237.7Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAirlineSeatLegroomReduced = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M610-135.39q-25.85 0-43.35-21.76-17.5-21.77-10.65-46.62L608.46-390H305.38q-29.15 0-49.57-20.42-20.43-20.42-20.43-49.58v-333.85q0-15.46 10.35-25.8Q256.08-830 271.54-830h147.69q15.46 0 25.81 10.35 10.34 10.34 10.34 25.8V-570h213.16q36.54 0 58.23 29.31 21.69 29.31 11.07 63.85l-75.53 247.61h63.38q22 0 36.23 12.46 14.23 12.46 14.23 34.46t-13.23 34.46q-13.23 12.46-35.23 12.46H610ZM207.69-290q-30.3 0-51.3-21-21-21-21-51.31V-800q0-12.77 8.61-21.38 8.62-8.62 21.39-8.62 12.76 0 21.38 8.62 8.61 8.61 8.61 21.38v437.69q0 4.62 3.85 8.46 3.85 3.85 8.46 3.85h237.7q12.76 0 21.38 8.62 8.61 8.61 8.61 21.38t-8.61 21.38q-8.62 8.62-21.38 8.62h-237.7Z",
    }),
  }),
  "IconMaterialSymbolsAirlineSeatLegroomReduced",
);

export default IconMaterialSymbolsAirlineSeatLegroomReduced;
