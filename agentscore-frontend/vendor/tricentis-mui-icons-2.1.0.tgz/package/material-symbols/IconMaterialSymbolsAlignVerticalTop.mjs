// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_vertical_top`, without fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_vertical_top:FILL@0;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M308.65-124.81q-14.8-14.81-14.8-35.58v-488.07q0-20.77%2014.8-35.58%2014.81-14.8%2035.58-14.8%2020.77%200%2035.58%2014.8%2014.8%2014.81%2014.8%2035.58v488.07q0%2020.77-14.8%2035.58Q365-110%20344.23-110q-20.77%200-35.58-14.81Zm271.54-240q-14.8-14.81-14.8-35.58v-248.07q0-20.77%2014.8-35.58%2014.81-14.8%2035.58-14.8%2020.77%200%2035.58%2014.8%2014.8%2014.81%2014.8%2035.58v248.07q0%2020.77-14.8%2035.58Q636.54-350%20615.77-350q-20.77%200-35.58-14.81ZM130-790.38q-12.77%200-21.38-8.62-8.62-8.61-8.62-21.38t8.62-21.39q8.61-8.61%2021.38-8.61h700q12.77%200%2021.38%208.61%208.62%208.62%208.62%2021.39%200%2012.77-8.62%2021.38-8.61%208.62-21.38%208.62H130Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignVerticalTop = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M308.65-124.81q-14.8-14.81-14.8-35.58v-488.07q0-20.77 14.8-35.58 14.81-14.8 35.58-14.8 20.77 0 35.58 14.8 14.8 14.81 14.8 35.58v488.07q0 20.77-14.8 35.58Q365-110 344.23-110q-20.77 0-35.58-14.81Zm271.54-240q-14.8-14.81-14.8-35.58v-248.07q0-20.77 14.8-35.58 14.81-14.8 35.58-14.8 20.77 0 35.58 14.8 14.8 14.81 14.8 35.58v248.07q0 20.77-14.8 35.58Q636.54-350 615.77-350q-20.77 0-35.58-14.81ZM130-790.38q-12.77 0-21.38-8.62-8.62-8.61-8.62-21.38t8.62-21.39q8.61-8.61 21.38-8.61h700q12.77 0 21.38 8.61 8.62 8.62 8.62 21.39 0 12.77-8.62 21.38-8.61 8.62-21.38 8.62H130Z",
    }),
  }),
  "IconMaterialSymbolsAlignVerticalTop",
);

export default IconMaterialSymbolsAlignVerticalTop;
