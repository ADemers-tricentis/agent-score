// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`animated_images`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:animated_images:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22m546.23-472.54%20114.92-77.54q16.08-10.84%2016.08-29.92%200-19.08-16.08-29.92l-114.92-77.54q-18.08-12.85-37.15-2Q490-678.61%20490-656.92v153.84q0%2021.69%2019.08%2032.54%2019.07%2010.85%2037.15-2ZM237.62-106.16q-29.93%204.24-53.73-14.15-23.81-18.38-27.43-48.31l-51.07-412.76q-3.62-29.93%2014.65-53.81%2018.27-23.89%2048.19-27.12l42.54-4.46v303.69q0%2062.93%2044.69%20107.62%2044.69%2044.69%20107.62%2044.69h369.69q-2.92%2019-16.88%2033.04-13.97%2014.04-34.2%2016.65l-444.07%2054.92Zm125.46-184.61q-30.31%200-51.31-21-21-21-21-51.31v-424.61q0-30.31%2021-51.31%2021-21%2051.31-21h424.61Q818-860%20839-839q21%2021%2021%2051.31v424.61q0%2030.31-21%2051.31-21%2021-51.31%2021H363.08Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAnimatedImagesFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "m546.23-472.54 114.92-77.54q16.08-10.84 16.08-29.92 0-19.08-16.08-29.92l-114.92-77.54q-18.08-12.85-37.15-2Q490-678.61 490-656.92v153.84q0 21.69 19.08 32.54 19.07 10.85 37.15-2ZM237.62-106.16q-29.93 4.24-53.73-14.15-23.81-18.38-27.43-48.31l-51.07-412.76q-3.62-29.93 14.65-53.81 18.27-23.89 48.19-27.12l42.54-4.46v303.69q0 62.93 44.69 107.62 44.69 44.69 107.62 44.69h369.69q-2.92 19-16.88 33.04-13.97 14.04-34.2 16.65l-444.07 54.92Zm125.46-184.61q-30.31 0-51.31-21-21-21-21-51.31v-424.61q0-30.31 21-51.31 21-21 51.31-21h424.61Q818-860 839-839q21 21 21 51.31v424.61q0 30.31-21 51.31-21 21-51.31 21H363.08Z",
    }),
  }),
  "IconMaterialSymbolsAnimatedImagesFill",
);

export default IconMaterialSymbolsAnimatedImagesFill;
