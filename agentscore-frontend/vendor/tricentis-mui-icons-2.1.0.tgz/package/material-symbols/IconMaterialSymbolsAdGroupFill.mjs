// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`ad_group`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:ad_group:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M322.31-260Q292-260%20271-281q-21-21-21-51.31v-455.38Q250-818%20271-839q21-21%2051.31-21h455.38Q808-860%20829-839q21%2021%2021%2051.31v455.38Q850-302%20829-281q-21%2021-51.31%2021H322.31Zm-140%20140Q152-120%20131-141q-21-21-21-51.31v-485.38q0-12.77%208.62-21.39%208.61-8.61%2021.38-8.61t21.39%208.61q8.61%208.62%208.61%2021.39v485.38q0%204.62%203.85%208.46%203.84%203.85%208.46%203.85h485.38q12.77%200%2021.39%208.61%208.61%208.62%208.61%2021.39%200%2012.77-8.61%2021.38-8.62%208.62-21.39%208.62H182.31ZM310-720h480v-67.69q0-4.62-3.85-8.46-3.84-3.85-8.46-3.85H322.31q-4.62%200-8.46%203.85-3.85%203.84-3.85%208.46V-720Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAdGroupFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M322.31-260Q292-260 271-281q-21-21-21-51.31v-455.38Q250-818 271-839q21-21 51.31-21h455.38Q808-860 829-839q21 21 21 51.31v455.38Q850-302 829-281q-21 21-51.31 21H322.31Zm-140 140Q152-120 131-141q-21-21-21-51.31v-485.38q0-12.77 8.62-21.39 8.61-8.61 21.38-8.61t21.39 8.61q8.61 8.62 8.61 21.39v485.38q0 4.62 3.85 8.46 3.84 3.85 8.46 3.85h485.38q12.77 0 21.39 8.61 8.61 8.62 8.61 21.39 0 12.77-8.61 21.38-8.62 8.62-21.39 8.62H182.31ZM310-720h480v-67.69q0-4.62-3.85-8.46-3.84-3.85-8.46-3.85H322.31q-4.62 0-8.46 3.85-3.85 3.84-3.85 8.46V-720Z",
    }),
  }),
  "IconMaterialSymbolsAdGroupFill",
);

export default IconMaterialSymbolsAdGroupFill;
