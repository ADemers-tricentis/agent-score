// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`account_balance_wallet`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:account_balance_wallet:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M212.31-140Q182-140%20161-161q-21-21-21-51.31v-535.38Q140-778%20161-799q21-21%2051.31-21h535.38Q778-820%20799-799q21%2021%2021%2051.31V-720H532.31q-59.46%200-95.88%2036.43Q400-647.15%20400-587.69v215.38q0%2059.46%2036.43%2095.88Q472.85-240%20532.31-240H820v27.69Q820-182%20799-161q-21%2021-51.31%2021H212.31Zm320-160Q502-300%20481-321q-21-21-21-51.31v-215.38Q460-618%20481-639q21-21%2051.31-21h255.38Q818-660%20839-639q21%2021%2021%2051.31v215.38Q860-342%20839-321q-21%2021-51.31%2021H532.31ZM683-437q17-17%2017-43t-17-43q-17-17-43-17t-43%2017q-17%2017-17%2043t17%2043q17%2017%2043%2017t43-17Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAccountBalanceWalletFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M212.31-140Q182-140 161-161q-21-21-21-51.31v-535.38Q140-778 161-799q21-21 51.31-21h535.38Q778-820 799-799q21 21 21 51.31V-720H532.31q-59.46 0-95.88 36.43Q400-647.15 400-587.69v215.38q0 59.46 36.43 95.88Q472.85-240 532.31-240H820v27.69Q820-182 799-161q-21 21-51.31 21H212.31Zm320-160Q502-300 481-321q-21-21-21-51.31v-215.38Q460-618 481-639q21-21 51.31-21h255.38Q818-660 839-639q21 21 21 51.31v215.38Q860-342 839-321q-21 21-51.31 21H532.31ZM683-437q17-17 17-43t-17-43q-17-17-43-17t-43 17q-17 17-17 43t17 43q17 17 43 17t43-17Z",
    }),
  }),
  "IconMaterialSymbolsAccountBalanceWalletFill",
);

export default IconMaterialSymbolsAccountBalanceWalletFill;
