// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`align_space_between`, without fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:align_space_between:FILL@0;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M130-100q-12.75%200-21.37-8.63-8.63-8.63-8.63-21.38%200-12.76%208.63-21.37Q117.25-160%20130-160h160v-63.84q0-15.37%2010.39-25.76%2010.4-10.4%2025.76-10.4h307.7q15.36%200%2025.76%2010.4Q670-239.21%20670-223.84V-160h160q12.75%200%2021.37%208.63%208.63%208.63%208.63%2021.38%200%2012.76-8.63%2021.37Q842.75-100%20830-100H130Zm196.15-600q-15.36%200-25.76-10.4Q290-720.79%20290-736.16V-800H130q-12.75%200-21.37-8.63-8.63-8.63-8.63-21.38%200-12.76%208.63-21.37Q117.25-860%20130-860h700q12.75%200%2021.37%208.63%208.63%208.63%208.63%2021.38%200%2012.76-8.63%2021.37Q842.75-800%20830-800H670v63.84q0%2015.37-10.39%2025.76-10.4%2010.4-25.76%2010.4h-307.7Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAlignSpaceBetween = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M130-100q-12.75 0-21.37-8.63-8.63-8.63-8.63-21.38 0-12.76 8.63-21.37Q117.25-160 130-160h160v-63.84q0-15.37 10.39-25.76 10.4-10.4 25.76-10.4h307.7q15.36 0 25.76 10.4Q670-239.21 670-223.84V-160h160q12.75 0 21.37 8.63 8.63 8.63 8.63 21.38 0 12.76-8.63 21.37Q842.75-100 830-100H130Zm196.15-600q-15.36 0-25.76-10.4Q290-720.79 290-736.16V-800H130q-12.75 0-21.37-8.63-8.63-8.63-8.63-21.38 0-12.76 8.63-21.37Q117.25-860 130-860h700q12.75 0 21.37 8.63 8.63 8.63 8.63 21.38 0 12.76-8.63 21.37Q842.75-800 830-800H670v63.84q0 15.37-10.39 25.76-10.4 10.4-25.76 10.4h-307.7Z",
    }),
  }),
  "IconMaterialSymbolsAlignSpaceBetween",
);

export default IconMaterialSymbolsAlignSpaceBetween;
