// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`add_comment`, without fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:add_comment:FILL@0;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M450-530v90q0%2012.77%208.62%2021.38Q467.23-410%20480-410t21.38-8.62Q510-427.23%20510-440v-90h90q12.77%200%2021.38-8.62Q630-547.23%20630-560t-8.62-21.38Q612.77-590%20600-590h-90v-90q0-12.77-8.62-21.38Q492.77-710%20480-710t-21.38%208.62Q450-692.77%20450-680v90h-90q-12.77%200-21.38%208.62Q330-572.77%20330-560t8.62%2021.38Q347.23-530%20360-530h90ZM241.54-260l-80.08%2080.07q-17.07%2017.08-39.27%207.74Q100-181.54%20100-205.85v-581.84Q100-818%20121-839q21-21%2051.31-21h615.38Q818-860%20839-839q21%2021%2021%2051.31v455.38Q860-302%20839-281q-21%2021-51.31%2021H241.54ZM216-320h571.69q4.62%200%208.46-3.85%203.85-3.84%203.85-8.46v-455.38q0-4.62-3.85-8.46-3.84-3.85-8.46-3.85H172.31q-4.62%200-8.46%203.85-3.85%203.84-3.85%208.46v523.08L216-320Zm-56%200v-480%20480Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAddComment = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M450-530v90q0 12.77 8.62 21.38Q467.23-410 480-410t21.38-8.62Q510-427.23 510-440v-90h90q12.77 0 21.38-8.62Q630-547.23 630-560t-8.62-21.38Q612.77-590 600-590h-90v-90q0-12.77-8.62-21.38Q492.77-710 480-710t-21.38 8.62Q450-692.77 450-680v90h-90q-12.77 0-21.38 8.62Q330-572.77 330-560t8.62 21.38Q347.23-530 360-530h90ZM241.54-260l-80.08 80.07q-17.07 17.08-39.27 7.74Q100-181.54 100-205.85v-581.84Q100-818 121-839q21-21 51.31-21h615.38Q818-860 839-839q21 21 21 51.31v455.38Q860-302 839-281q-21 21-51.31 21H241.54ZM216-320h571.69q4.62 0 8.46-3.85 3.85-3.84 3.85-8.46v-455.38q0-4.62-3.85-8.46-3.84-3.85-8.46-3.85H172.31q-4.62 0-8.46 3.85-3.85 3.84-3.85 8.46v523.08L216-320Zm-56 0v-480 480Z",
    }),
  }),
  "IconMaterialSymbolsAddComment",
);

export default IconMaterialSymbolsAddComment;
