// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`approval`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:approval:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M252.31-130.77q-29.92%200-51.12-21.2Q180-173.16%20180-203.08V-340q0-30.31%2021-51.31%2021-21%2051.31-21h455.38q30.31%200%2051.31%2021%2021%2021%2021%2051.31v136.92q0%2029.92-21.19%2051.11-21.2%2021.2-51.12%2021.2H252.31Zm24.61-140h406.16q15.84%200%2026.38-10.54T720-307.69v-7.7q0-15.07-10.92-26-10.93-10.92-26-10.92H276.92q-15.07%200-26%2010.92-10.92%2010.93-10.92%2026v7.7q0%2015.84%2010.54%2026.38t26.38%2010.54Zm173.54-182.15-133-183.54q-8.23-11.85-11.73-25.62-3.5-13.76-1.5-28.23%2010.46-67.61%2057.92-110.96%2047.47-43.34%20117.85-43.34t117.85%2043.34q47.46%2043.35%2057.92%20110.96%202%2014.47-1.5%2028.23-3.5%2013.77-11.73%2025.62l-133%20183.54q-10.85%2015.07-29.54%2015.07-18.69%200-29.54-15.07Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsApprovalFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M252.31-130.77q-29.92 0-51.12-21.2Q180-173.16 180-203.08V-340q0-30.31 21-51.31 21-21 51.31-21h455.38q30.31 0 51.31 21 21 21 21 51.31v136.92q0 29.92-21.19 51.11-21.2 21.2-51.12 21.2H252.31Zm24.61-140h406.16q15.84 0 26.38-10.54T720-307.69v-7.7q0-15.07-10.92-26-10.93-10.92-26-10.92H276.92q-15.07 0-26 10.92-10.92 10.93-10.92 26v7.7q0 15.84 10.54 26.38t26.38 10.54Zm173.54-182.15-133-183.54q-8.23-11.85-11.73-25.62-3.5-13.76-1.5-28.23 10.46-67.61 57.92-110.96 47.47-43.34 117.85-43.34t117.85 43.34q47.46 43.35 57.92 110.96 2 14.47-1.5 28.23-3.5 13.77-11.73 25.62l-133 183.54q-10.85 15.07-29.54 15.07-18.69 0-29.54-15.07Z",
    }),
  }),
  "IconMaterialSymbolsApprovalFill",
);

export default IconMaterialSymbolsApprovalFill;
