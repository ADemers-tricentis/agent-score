// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`add_to_home_screen`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:add_to_home_screen:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22M292.31-60q-29.92%200-51.12-21.19Q220-102.39%20220-132.31v-695.38Q220-858%20241-879q21-21%2051.31-21h376.92q29.92%200%2051.11%2021.19%2021.2%2021.2%2021.2%2051.12v126.31q16.46%204.3%2027.46%2017.19%2011%2012.88%2011%2029.96v75.38q0%2017.08-11%2029.97-11%2012.88-27.46%2017.19v399.38q0%2029.92-21.2%2051.12Q699.15-60%20669.23-60H292.31ZM530-488.23v86.31q0%2012.77%208.62%2021.38%208.61%208.62%2021.38%208.62t21.38-8.62q8.62-8.61%208.62-21.38v-152.31q0-15.46-10.35-25.81-10.34-10.34-25.8-10.34H401.54q-12.77%200-21.39%208.61-8.61%208.62-8.61%2021.39%200%2012.76%208.61%2021.38%208.62%208.61%2021.39%208.61h86.69L370.69-413.85q-9.3%208.93-9.3%2021.2t9.3%2021.57q9.31%209.31%2021.39%209.31%2012.07%200%2021.38-9.31L530-488.23Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAddToHomeScreenFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "M292.31-60q-29.92 0-51.12-21.19Q220-102.39 220-132.31v-695.38Q220-858 241-879q21-21 51.31-21h376.92q29.92 0 51.11 21.19 21.2 21.2 21.2 51.12v126.31q16.46 4.3 27.46 17.19 11 12.88 11 29.96v75.38q0 17.08-11 29.97-11 12.88-27.46 17.19v399.38q0 29.92-21.2 51.12Q699.15-60 669.23-60H292.31ZM530-488.23v86.31q0 12.77 8.62 21.38 8.61 8.62 21.38 8.62t21.38-8.62q8.62-8.61 8.62-21.38v-152.31q0-15.46-10.35-25.81-10.34-10.34-25.8-10.34H401.54q-12.77 0-21.39 8.61-8.61 8.62-8.61 21.39 0 12.76 8.61 21.38 8.62 8.61 21.39 8.61h86.69L370.69-413.85q-9.3 8.93-9.3 21.2t9.3 21.57q9.31 9.31 21.39 9.31 12.07 0 21.38-9.31L530-488.23Z",
    }),
  }),
  "IconMaterialSymbolsAddToHomeScreenFill",
);

export default IconMaterialSymbolsAddToHomeScreenFill;
