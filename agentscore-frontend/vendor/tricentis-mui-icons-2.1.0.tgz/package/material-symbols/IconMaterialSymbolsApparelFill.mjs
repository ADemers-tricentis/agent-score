// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`apparel`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:apparel:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22m260-555.46-55.77%2030.84q-12.84%207.23-26.54%203.81-13.69-3.42-20.92-16.27L92.16-650.15q-7.23-12.85-3.81-26.73%203.42-13.89%2016.27-21.12l210-122h59.23q10.15%200%2016.23%206.08%206.07%206.08%206.07%2016.23v13.85q0%2034.15%2024.85%2059Q445.85-700%20480-700t59-24.84q24.85-24.85%2024.85-59v-13.85q0-10.15%206.07-16.23Q576-820%20586.15-820h59.23l210%20122q12.85%207.23%2016.27%2021.12%203.42%2013.88-3.81%2026.73l-64.61%20113.07q-7.23%2012.85-20.62%2015.96-13.38%203.12-26.84-4.11L700-554.85v379.46q0%2015.08-10.16%2025.23Q679.69-140%20664.61-140H295.39q-15.08%200-25.23-10.16Q260-160.31%20260-175.39v-380.07Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsApparelFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "m260-555.46-55.77 30.84q-12.84 7.23-26.54 3.81-13.69-3.42-20.92-16.27L92.16-650.15q-7.23-12.85-3.81-26.73 3.42-13.89 16.27-21.12l210-122h59.23q10.15 0 16.23 6.08 6.07 6.08 6.07 16.23v13.85q0 34.15 24.85 59Q445.85-700 480-700t59-24.84q24.85-24.85 24.85-59v-13.85q0-10.15 6.07-16.23Q576-820 586.15-820h59.23l210 122q12.85 7.23 16.27 21.12 3.42 13.88-3.81 26.73l-64.61 113.07q-7.23 12.85-20.62 15.96-13.38 3.12-26.84-4.11L700-554.85v379.46q0 15.08-10.16 25.23Q679.69-140 664.61-140H295.39q-15.08 0-25.23-10.16Q260-160.31 260-175.39v-380.07Z",
    }),
  }),
  "IconMaterialSymbolsApparelFill",
);

export default IconMaterialSymbolsApparelFill;
