// @ts-check

import { createSvgIcon } from "@mui/material/utils";
import { jsx } from "react/jsx-runtime";

/**
 * React component implementing the Material UI component
 * [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for the Google
 * Material Symbols icon
 * [`airlines`, with fill, rounded, weight 300, grade 0, optical size 24px](https://fonts.google.com/icons?selected=Material+Symbols+Rounded:airlines:FILL@1;wght@300;GRAD@0;opsz@24):
 *
 * ![Preview](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%20-960%20960%20960%22%20style%3D%22background%3Awhite%22%3E%3Cpath%20d%3D%22m120.46-208.31%20383.62-540.92q9.84-14.69%2025.61-22.73%2015.77-8.04%2033.46-8.04h209.7q34.56%200%2055.93%2026.31%2021.37%2026.31%2014.76%2059.84l-93.7%20484.31q-2.61%2012.85-12.55%2021.19-9.94%208.35-22.6%208.35H134.92q-10.79%200-15.74-9.54-4.95-9.54%201.28-18.77Zm455.31-204q36.99%200%2062.53-25.39%2025.54-25.38%2025.54-62.15%200-36.76-25.54-62.3t-62.53-25.54q-36.67%200-61.99%2025.46-25.32%2025.47-25.32%2062.35t25.32%2062.23q25.32%2025.34%2061.99%2025.34Z%22%2F%3E%3C%2Fsvg%3E)
 */
const IconMaterialSymbolsAirlinesFill = createSvgIcon(
  jsx("svg", {
    width: "24px",
    height: "24px",
    viewBox: "0 -960 960 960",
    fill: "currentColor",
    children: jsx("path", {
      d: "m120.46-208.31 383.62-540.92q9.84-14.69 25.61-22.73 15.77-8.04 33.46-8.04h209.7q34.56 0 55.93 26.31 21.37 26.31 14.76 59.84l-93.7 484.31q-2.61 12.85-12.55 21.19-9.94 8.35-22.6 8.35H134.92q-10.79 0-15.74-9.54-4.95-9.54 1.28-18.77Zm455.31-204q36.99 0 62.53-25.39 25.54-25.38 25.54-62.15 0-36.76-25.54-62.3t-62.53-25.54q-36.67 0-61.99 25.46-25.32 25.47-25.32 62.35t25.32 62.23q25.32 25.34 61.99 25.34Z",
    }),
  }),
  "IconMaterialSymbolsAirlinesFill",
);

export default IconMaterialSymbolsAirlinesFill;
