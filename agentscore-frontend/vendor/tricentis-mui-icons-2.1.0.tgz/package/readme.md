# Material UI icons

React components implementing the [Material UI](https://mui.com/material-ui) component [`SvgIcon`](https://mui.com/material-ui/api/svg-icon) for icons the [Tricentis UX](https://github.com/Tricentis-UX) team endorse for Tricentis projects using [Aura](https://github.com/Tricentis-UX/aura-ui), including a variation of [Google Material Symbols](https://fonts.google.com/icons).

## Installation

To install in an existing Node.js, React, and Material UI project:

1. [Install Node.js](https://nodejs.org/en/download/) and [pnpm](https://pnpm.io/installation) versions according to the [_**Requirements**_](#requirements).
2. Follow [these instructions](https://dev.azure.com/tricentis/cloud/_artifacts/feed/TricentisEnterpriseCloud/connect/npm) to configure your [user `.npmrc` file](https://docs.npmjs.com/cli/v10/configuring-npm/npmrc#per-user-config-file) to be able to install private `@tricentis` scoped npm packages. To only use the Tricentis npm registry for `@tricentis` scoped packages, use the prefix:

   ```diff
   - registry=https://pkgs.dev.azure.com/tricentis/_packaging/TricentisEnterpriseCloud/npm/registry/
   + @tricentis:registry=https://pkgs.dev.azure.com/tricentis/_packaging/TricentisEnterpriseCloud/npm/registry/
     always-auth=true
   ```

3. Install the private npm package `@tricentis/mui-icons` using pnpm:

   ```sh
   pnpm add @tricentis/mui-icons
   ```

## Exports

The private npm package `@tricentis/mui-icons` features [optimal JavaScript module design](https://jaydenseric.com/blog/optimal-javascript-module-design). It doesn’t have a main index module, so use deep imports (using the file extension `.mjs`) from the ECMAScript modules that are exported via the [`package.json`](./package.json) field [`exports`](https://nodejs.org/api/packages.html#exports):

- `material-symbols/`: Modules each named `IconMaterialSymbols` + the [Google Material Symbols](https://fonts.google.com/icons) icon name in pascal case + `Fill` (optionally, if the icon has a fill variant) + `.mjs`, default exporting a React component implementing the [Material UI](https://mui.com/material-ui) component [`SvgIcon`](https://mui.com/material-ui/api/svg-icon). Example:

  ```js
  import IconMaterialSymbolsKeyboardArrowDown from "@tricentis/mui-icons/material-symbols/IconMaterialSymbolsKeyboardArrowDown.mjs";
  ```

## Requirements

Supported runtime environments:

- [Node.js](https://nodejs.org) versions `^18.18.0 || ^20.9.0 || >=22.0.0`.
- Browsers matching the [Browserslist](https://browsersl.ist) query [`> 0.5%, not OperaMini all, not dead`](https://browsersl.ist/#q=%3E+0.5%25%2C+not+OperaMini+all%2C+not+dead).

Supported TypeScript versions: v5+.

> [!WARNING]
> While this package has correct [ESM for Node.js and TypeScript](https://www.typescriptlang.org/docs/handbook/modules/theory.html#module-format-detection), the [Material UI dependencies don’t](https://github.com/mui/material-ui/issues/30671). Until this is fixed upstream, instead of the correct TypeScript config of [`compilerOptions.module`](https://www.typescriptlang.org/tsconfig#module) set to [`"nodenext"`](https://www.typescriptlang.org/docs/handbook/modules/reference.html#node16-nodenext), projects must set [`"preserve"`](https://www.typescriptlang.org/docs/handbook/modules/reference.html#preserve), and must use a bundler (e.g. [esbuild](https://esbuild.github.io) or [webpack](https://webpack.js.org)) to consume this package as Node.js and browsers can’t run it directly. Bundlers have to be specially configured to be able to resolve the non standard ESM dependencies.

## Scripts

These CLI scripts are used to install, build, serve, and quality check the project.

### Install script

To install dependencies:

```sh
pnpm install
```

### Prepare script

To prepare build artifacts so the repo can be used as an installed package:

```sh
pnpm run prepare
```

This [npm life cycle script](https://docs.npmjs.com/cli/v10/using-npm/scripts#life-cycle-scripts) is automatically used by the npm CLI in certain situations and isn’t for manual use (instead see [**_Build script_**](#build-script)). It allows the `@tricentis/mui-icons` package to be installed in a project via a [Git repo URL](https://docs.npmjs.com/cli/v10/using-npm/package-spec#git-urls); useful for testing forks or PR branches.

### Download script

To download or update the Google Material Symbols SVG sources from the Google Fonts CDN into the `svg-sources` directory:

```sh
pnpm run download
```

By default, the script reads icon names from `svg-sources/rounded/` and re-downloads them at the configured optical size (24px).

To sync new icons from Google's current Material Symbols set:

```sh
pnpm run download -- --google
```

This adds new icons only. Existing icons are not re-downloaded or removed.

After downloading, review the changes with `git diff svg-sources/` before committing.

### Build script

To clean and build the Google Material Symbols Material UI icon React component modules directory `material-symbols`:

```sh
pnpm run build
```

Run this after SVG sources in `svg-sources/` are updated and commit the changes with a changelog entry documenting the major, minor, or patch consequences.

### Check script

To run all quality checks:

```sh
pnpm run check
```

### Prettier script

To check formatting with [Prettier](https://prettier.io):

```sh
pnpm run prettier
```

### ESLint script

To lint with [ESLint](https://eslint.org):

```sh
pnpm run eslint
```

### Type check script

To type check with [TypeScript](https://typescriptlang.org):

```sh
pnpm run type-check
```

### Find unused exports script

To find unused exports with [`find-unused-exports`](https://npm.im/find-unused-exports):

```sh
pnpm run find-unused-exports
```
